import { useState, useEffect } from 'react';
import { localStorage_storage, type StoredCalculation } from '@/lib/storage';
import { HydrationCalculator, type CalculationParams, type CalculationResult } from '@/lib/hydration-calculator';
import { usePreferences } from './use-preferences';

export function useCalculations() {
  const [calculations, setCalculations] = useState<StoredCalculation[]>([]);
  const [currentResult, setCurrentResult] = useState<CalculationResult | null>(null);
  const [isCalculating, setIsCalculating] = useState(false);
  const { preferences } = usePreferences();

  // Load calculations on mount
  useEffect(() => {
    setCalculations(localStorage_storage.getCalculations());
  }, []);

  const calculate = async (params: CalculationParams, name?: string): Promise<CalculationResult> => {
    setIsCalculating(true);
    
    try {
      // Perform calculation
      let result = HydrationCalculator.calculate(params);
      
      // Apply conservative buffer if enabled
      if (preferences.conservative) {
        result = {
          ...result,
          liters: Math.round(result.liters * 1.1 * 10) / 10,
          ounces: Math.round(result.ounces * 1.1)
        };
      }

      // Save to local storage
      const calculationToSave = {
        name: name || `${params.distance || params.duration} ${params.distance ? (params.isMetric ? 'km' : 'mi') : 'hrs'}`,
        distance: params.distance || null,
        duration: params.duration || null,
        temperature: params.temperature,
        temperatureUnit: params.temperatureUnit,
        pace: params.pace || null,
        elevationGain: params.elevationGain || null,
        humidity: params.humidity || null,
        packWeight: params.packWeight || null,
        resultLiters: result.liters,
        resultOunces: result.ounces,
        isMetric: params.isMetric || false
      };

      const savedCalculation = localStorage_storage.saveCalculation(calculationToSave);
      setCalculations(prev => [savedCalculation, ...prev]);
      setCurrentResult(result);
      
      return result;
    } catch (error) {
      throw error;
    } finally {
      setIsCalculating(false);
    }
  };

  const deleteCalculation = (id: string) => {
    localStorage_storage.deleteCalculation(id);
    setCalculations(prev => prev.filter(calc => calc.id !== id));
  };

  const clearAllCalculations = () => {
    localStorage_storage.clearCalculations();
    setCalculations([]);
  };

  const exportCalculations = (): string => {
    return localStorage_storage.exportData();
  };

  const importCalculations = (jsonData: string) => {
    localStorage_storage.importData(jsonData);
    setCalculations(localStorage_storage.getCalculations());
  };

  // Get recent calculations (last 3)
  const recentCalculations = calculations.slice(0, 3);

  return {
    calculations,
    recentCalculations,
    currentResult,
    isCalculating,
    calculate,
    deleteCalculation,
    clearAllCalculations,
    exportCalculations,
    importCalculations,
    setCurrentResult
  };
}
