import { useState, useEffect } from 'react';
import { localStorage_storage, type StoredPreferences } from '@/lib/storage';

export function usePreferences() {
  const [preferences, setPreferences] = useState<StoredPreferences>(
    localStorage_storage.getPreferences()
  );

  const updatePreferences = (updates: Partial<StoredPreferences>) => {
    const newPreferences = { ...preferences, ...updates };
    setPreferences(newPreferences);
    localStorage_storage.savePreferences(newPreferences);
  };

  const resetPreferences = () => {
    const defaultPreferences: StoredPreferences = {
      units: 'imperial',
      dyslexiaFont: false,
      largeText: false,
      highContrast: false,
      conservative: true
    };
    setPreferences(defaultPreferences);
    localStorage_storage.savePreferences(defaultPreferences);
  };

  // Sync with localStorage changes (for multi-tab support)
  useEffect(() => {
    const handleStorageChange = (e: StorageEvent) => {
      if (e.key === 'hydration-calc-preferences') {
        setPreferences(localStorage_storage.getPreferences());
      }
    };

    window.addEventListener('storage', handleStorageChange);
    return () => window.removeEventListener('storage', handleStorageChange);
  }, []);

  return {
    preferences,
    updatePreferences,
    resetPreferences
  };
}
