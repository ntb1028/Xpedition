
export interface WaterSource {
  id: string;
  name: string;
  type: 'trailhead' | 'seasonal' | 'year_round' | 'emergency' | 'unreliable';
  latitude: number;
  longitude: number;
  trailName: string;
  description: string;
  availability: 'year_round' | 'seasonal' | 'unreliable' | 'closed';
  seasonalDates?: string;
  notes?: string;
  lastUpdated?: string;
}

class WaterSourcesAPI {
  private waterSources: WaterSource[] = [
    // Bright Angel Trail Water Sources
    {
      id: 'bright-angel-trailhead-water',
      name: 'Bright Angel Trailhead',
      type: 'trailhead',
      latitude: 36.0544,
      longitude: -112.1401,
      trailName: 'Bright Angel Trail',
      description: 'Water fountains and restrooms at trailhead',
      availability: 'year_round',
      notes: 'Fill up here before descending - reliable water source'
    },
    {
      id: 'mile-half-resthouse-water',
      name: 'Mile-and-a-Half Resthouse',
      type: 'emergency',
      latitude: 36.0598,
      longitude: -112.1358,
      trailName: 'Bright Angel Trail',
      description: 'Emergency water only - not for general use',
      availability: 'year_round',
      notes: 'Emergency water only - bring your own water'
    },
    {
      id: 'three-mile-resthouse-water',
      name: 'Three-Mile Resthouse',
      type: 'seasonal',
      latitude: 36.0672,
      longitude: -112.1301,
      trailName: 'Bright Angel Trail',
      description: 'Seasonal water available',
      availability: 'seasonal',
      seasonalDates: 'May 1 - September 30',
      notes: 'Turned off in winter - check current status before hiking'
    },
    {
      id: 'indian-garden-water',
      name: 'Indian Garden',
      type: 'year_round',
      latitude: 36.0790,
      longitude: -112.1264,
      trailName: 'Bright Angel Trail',
      description: 'Year-round water at campground',
      availability: 'year_round',
      notes: 'Reliable water source with spigots and restrooms'
    },
    {
      id: 'bright-angel-campground-water',
      name: 'Bright Angel Campground',
      type: 'year_round',
      latitude: 36.1058,
      longitude: -112.0947,
      trailName: 'Bright Angel Trail',
      description: 'Colorado River corridor campground water',
      availability: 'year_round',
      notes: 'End of trail - reliable water and facilities'
    },
    
    // South Kaibab Trail Water Sources (Limited)
    {
      id: 'south-kaibab-trailhead-water',
      name: 'South Kaibab Trailhead',
      type: 'trailhead',
      latitude: 36.0544,
      longitude: -112.0840,
      trailName: 'South Kaibab Trail',
      description: 'Water at trailhead only',
      availability: 'year_round',
      notes: 'NO WATER along trail - carry all water needed'
    },
    
    // Hermit Trail Water Sources
    {
      id: 'hermit-trailhead-water',
      name: 'Hermits Rest',
      type: 'trailhead',
      latitude: 36.0640,
      longitude: -112.1781,
      trailName: 'Hermit Trail',
      description: 'Water fountains at visitor area',
      availability: 'year_round',
      notes: 'Fill up before hiking - limited water on trail'
    },
    {
      id: 'santa-maria-spring-water',
      name: 'Santa Maria Spring',
      type: 'seasonal',
      latitude: 36.0445,
      longitude: -112.1612,
      trailName: 'Hermit Trail',
      description: 'Natural spring water',
      availability: 'seasonal',
      seasonalDates: 'Spring through early fall',
      notes: 'Natural source - filter/purify before drinking'
    },
    {
      id: 'hermit-creek-water',
      name: 'Hermit Creek',
      type: 'year_round',
      latitude: 36.0890,
      longitude: -112.1670,
      trailName: 'Hermit Trail',
      description: 'Creek water at campground',
      availability: 'year_round',
      notes: 'Creek water - must filter and purify before drinking'
    },
    
    // Additional Inner Canyon Sources
    {
      id: 'phantom-ranch-water',
      name: 'Phantom Ranch',
      type: 'year_round',
      latitude: 36.1058,
      longitude: -112.0947,
      trailName: 'Multiple Trails',
      description: 'Lodge and facilities with water',
      availability: 'year_round',
      notes: 'Reliable water source in inner canyon'
    },
    {
      id: 'river-resthouse-water',
      name: 'River Resthouse',
      type: 'seasonal',
      latitude: 36.1025,
      longitude: -112.0968,
      trailName: 'River Trail',
      description: 'Seasonal water near Colorado River',
      availability: 'seasonal',
      seasonalDates: 'May - September',
      notes: 'Check availability before depending on this source'
    }
  ];

  async getWaterSourcesForTrail(trailName: string): Promise<WaterSource[]> {
    return this.waterSources.filter(source => 
      source.trailName === trailName || source.trailName === 'Multiple Trails'
    );
  }

  async getAllWaterSources(): Promise<WaterSource[]> {
    return this.waterSources;
  }

  async getWaterSourcesInArea(bounds: {
    north: number;
    south: number;
    east: number;
    west: number;
  }): Promise<WaterSource[]> {
    return this.waterSources.filter(source => 
      source.latitude <= bounds.north &&
      source.latitude >= bounds.south &&
      source.longitude <= bounds.east &&
      source.longitude >= bounds.west
    );
  }

  getWaterAvailabilityAdvice(month: number): string {
    if (month >= 5 && month <= 9) {
      return "Most seasonal water sources are available. Verify current status before hiking.";
    } else if (month >= 10 && month <= 11) {
      return "Seasonal sources may be turned off. Rely on year-round sources only.";
    } else {
      return "Winter conditions - only year-round sources available. Carry extra water.";
    }
  }

  getWaterCarryRecommendation(trailName: string, season: 'summer' | 'winter' | 'spring' | 'fall'): string {
    const recommendations: { [key: string]: { [key: string]: string } } = {
      'South Kaibab Trail': {
        summer: 'Carry ALL water needed - minimum 1 gallon per person for full descent',
        winter: 'Carry ALL water needed - minimum 0.5 gallon per person for winter hiking',
        spring: 'Carry ALL water needed - minimum 0.75 gallon per person',
        fall: 'Carry ALL water needed - minimum 0.75 gallon per person'
      },
      'Bright Angel Trail': {
        summer: 'Water available at multiple points, but carry backup supply',
        winter: 'Limited seasonal sources - carry extra water between reliable points',
        spring: 'Most sources operational - still carry backup water',
        fall: 'Seasonal sources may close early - verify availability'
      },
      'Hermit Trail': {
        summer: 'Limited water sources - carry most water needed',
        winter: 'Very limited water - carry full supply',
        spring: 'Some seasonal sources available - carry backup',
        fall: 'Seasonal sources unreliable - carry extra water'
      }
    };

    return recommendations[trailName]?.[season] || 'Carry sufficient water for your planned hike';
  }
}

export const waterSourcesAPI = new WaterSourcesAPI();
