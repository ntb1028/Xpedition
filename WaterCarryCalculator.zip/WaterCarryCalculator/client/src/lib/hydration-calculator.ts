export interface CalculationParams {
  distance?: number;
  duration?: number;
  temperature: number;
  temperatureUnit: 'F' | 'C';
  pace?: number;
  elevationGain?: number;
  humidity?: 'low' | 'moderate' | 'high';
  packWeight?: number;
  isMetric?: boolean;
}

export interface CalculationResult {
  liters: number;
  ounces: number;
  rate: number;
  duration: number;
  containers: ContainerSuggestion[];
  isHighVolume: boolean;
}

export interface ContainerSuggestion {
  type: string;
  count: number;
  volume: number;
  icon: string;
}

export class HydrationCalculator {
  // Constants from requirements document
  private static readonly BASE_RATE_L_PER_HR = 0.50;
  private static readonly TEMP_BASELINE_C = 20;
  private static readonly MIN_RATE = 0.30;
  private static readonly HIGH_VOLUME_THRESHOLD = 4.0; // liters

  static calculate(params: CalculationParams): CalculationResult {
    const {
      distance = 0,
      duration = 0,
      temperature,
      temperatureUnit,
      pace = params.isMetric ? 4.8 : 3, // km/h or mph
      elevationGain = 0,
      humidity = 'moderate',
      packWeight = 0,
      isMetric = false
    } = params;

    // Calculate duration if distance provided
    let actualDuration = duration;
    if (distance > 0 && duration === 0) {
      actualDuration = distance / pace;
    }

    if (actualDuration <= 0) {
      throw new Error('Duration must be greater than 0');
    }

    // Convert temperature to Celsius
    const tempC = temperatureUnit === 'C' ? temperature : (temperature - 32) * 5/9;

    // Temperature adjustment (from requirements)
    const tempAdj = Math.max(0, 0.03 * (tempC - this.TEMP_BASELINE_C)) + 
                   Math.max(0, 0.02 * (15 - tempC));

    // Humidity adjustment
    let humidityAdj = 0;
    if (humidity === 'high') {
      humidityAdj = 0.05;
    }

    // Elevation adjustment (convert units if needed)
    const elevationM = isMetric ? elevationGain : elevationGain * 0.3048;
    const elevationAdj = 0.1 * (elevationM / 300);

    // Pack weight adjustment (convert units if needed)
    const packKg = isMetric ? packWeight : packWeight * 0.453592;
    const packAdj = 0.03 * packKg;

    // Calculate final rate (from requirements formula)
    const rate = Math.max(
      this.MIN_RATE,
      this.BASE_RATE_L_PER_HR + tempAdj + humidityAdj + elevationAdj + packAdj
    );

    // Total water needed
    const totalLiters = rate * actualDuration;
    const totalOunces = totalLiters * 33.814; // Convert to fl oz

    // Generate container suggestions
    const containers = this.suggestContainers(totalLiters);

    return {
      liters: Math.round(totalLiters * 10) / 10,
      ounces: Math.round(totalOunces),
      rate: Math.round(rate * 100) / 100,
      duration: Math.round(actualDuration * 10) / 10,
      containers,
      isHighVolume: totalLiters > this.HIGH_VOLUME_THRESHOLD
    };
  }

  private static suggestContainers(totalLiters: number): ContainerSuggestion[] {
    const containers: ContainerSuggestion[] = [];
    let remaining = totalLiters;

    // Priority order: 1L bottles, then larger containers
    if (remaining >= 1) {
      const bottles1L = Math.min(Math.floor(remaining), 3);
      if (bottles1L > 0) {
        containers.push({
          type: bottles1L === 1 ? '1L bottle' : `${bottles1L} × 1L bottles`,
          count: bottles1L,
          volume: bottles1L,
          icon: 'bottle-water'
        });
        remaining -= bottles1L;
      }
    }

    // Add 2L bladders for remaining volume > 1.5L
    if (remaining > 1.5) {
      const bladders2L = Math.floor(remaining / 2);
      if (bladders2L > 0) {
        containers.push({
          type: bladders2L === 1 ? '2L bladder' : `${bladders2L} × 2L bladders`,
          count: bladders2L,
          volume: bladders2L * 2,
          icon: 'prescription-bottle'
        });
        remaining -= bladders2L * 2;
      }
    }

    // Add smaller containers for remaining volume
    if (remaining > 0.3) {
      if (remaining > 1) {
        containers.push({
          type: '1.5L bottle',
          count: 1,
          volume: 1.5,
          icon: 'bottle-water'
        });
        remaining -= 1.5;
      } else if (remaining > 0.4) {
        containers.push({
          type: '500ml bottle',
          count: Math.ceil(remaining / 0.5),
          volume: Math.ceil(remaining / 0.5) * 0.5,
          icon: 'bottle-water'
        });
      }
    }

    return containers;
  }

  static convertUnits(value: number, from: string, to: string): number {
    const conversions: Record<string, Record<string, number>> = {
      temperature: {
        'F_to_C': (f: number) => (f - 32) * 5/9,
        'C_to_F': (c: number) => c * 9/5 + 32
      },
      distance: {
        'mi_to_km': 1.60934,
        'km_to_mi': 0.621371
      },
      weight: {
        'lbs_to_kg': 0.453592,
        'kg_to_lbs': 2.20462
      },
      elevation: {
        'ft_to_m': 0.3048,
        'm_to_ft': 3.28084
      }
    };

    const conversionKey = `${from}_to_${to}`;
    const conversionFactor = conversions[from.split('_')[0]]?.[conversionKey];

    if (typeof conversionFactor === 'function') {
      return conversionFactor(value);
    } else if (typeof conversionFactor === 'number') {
      return value * conversionFactor;
    }

    return value; // No conversion needed
  }
}
