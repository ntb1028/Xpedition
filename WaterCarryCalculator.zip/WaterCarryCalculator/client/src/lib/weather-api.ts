// Weather API service for Grand Canyon temperature data
export interface WeatherData {
  date: string;
  avgTemp: number; // Celsius
  maxTemp: number;
  minTemp: number;
  humidity: number;
  description: string;
}

export interface TemperatureAverages {
  avgDaily: number;
  avgMax: number;
  avgMin: number;
  humidity: 'low' | 'moderate' | 'high';
  unit?: 'C' | 'F';
}

export interface TrailWeatherData {
  position: [number, number];
  elevation: number;
  temperature: {
    min: number;
    max: number;
    avg: number;
  };
  humidity: 'low' | 'moderate' | 'high';
  conditions: string;
  windExposure: 'low' | 'moderate' | 'high';
  pointIndex: number;
  distanceFromStart: number;
  elevationUnit?: 'm' | 'ft';
  temperatureUnit?: 'C' | 'F';
}

class WeatherService {
  // Grand Canyon elevation-based temperature adjustments (degrees C per 100m elevation)
  private elevationLapseRate = 0.65; // Standard atmospheric lapse rate
  
  // Grand Canyon historical temperature averages by month (Celsius)
  private grandCanyonAverages = {
    1: { min: -9, max: 4, avg: -2.5, humidity: 'low' as const }, // January
    2: { min: -6, max: 8, avg: 1, humidity: 'low' as const },    // February
    3: { min: -3, max: 13, avg: 5, humidity: 'low' as const },   // March
    4: { min: 1, max: 18, avg: 9.5, humidity: 'low' as const },  // April
    5: { min: 6, max: 24, avg: 15, humidity: 'low' as const },   // May
    6: { min: 11, max: 29, avg: 20, humidity: 'low' as const },  // June
    7: { min: 14, max: 32, avg: 23, humidity: 'moderate' as const }, // July
    8: { min: 13, max: 30, avg: 21.5, humidity: 'moderate' as const }, // August
    9: { min: 8, max: 26, avg: 17, humidity: 'low' as const },   // September
    10: { min: 2, max: 19, avg: 10.5, humidity: 'low' as const }, // October
    11: { min: -4, max: 11, avg: 3.5, humidity: 'low' as const }, // November
    12: { min: -8, max: 6, avg: -1, humidity: 'low' as const }   // December
  };

  async getTemperatureForDateRange(startDate: string, days: number, options?: { units?: 'metric' | 'imperial' }): Promise<TemperatureAverages> {
    try {
      const start = new Date(startDate);
      const temperatures: number[] = [];
      const maxTemps: number[] = [];
      const minTemps: number[] = [];
      const humidityLevels: string[] = [];

      for (let i = 0; i < days; i++) {
        const currentDate = new Date(start.getTime() + i * 24 * 60 * 60 * 1000);
        const month = currentDate.getMonth() + 1;
        const monthData = this.grandCanyonAverages[month as keyof typeof this.grandCanyonAverages];
        
        temperatures.push(monthData.avg);
        maxTemps.push(monthData.max);
        minTemps.push(monthData.min);
        humidityLevels.push(monthData.humidity);
      }

      const avgDaily = temperatures.reduce((sum, temp) => sum + temp, 0) / temperatures.length;
      const avgMax = maxTemps.reduce((sum, temp) => sum + temp, 0) / maxTemps.length;
      const avgMin = minTemps.reduce((sum, temp) => sum + temp, 0) / minTemps.length;

      // Determine humidity level for the period
      const humidityMap = { low: 0, moderate: 1, high: 2 };
      const avgHumidityLevel = humidityLevels.reduce((sum, level) => sum + humidityMap[level as keyof typeof humidityMap], 0) / humidityLevels.length;
      const humidity: 'low' | 'moderate' | 'high' = avgHumidityLevel < 0.5 ? 'low' : avgHumidityLevel < 1.5 ? 'moderate' : 'high';

      const useImperial = options?.units === 'imperial';
      
      return {
        avgDaily: useImperial ? this.celsiusToFahrenheit(avgDaily) : avgDaily,
        avgMax: useImperial ? this.celsiusToFahrenheit(avgMax) : avgMax,
        avgMin: useImperial ? this.celsiusToFahrenheit(avgMin) : avgMin,
        humidity,
        unit: useImperial ? 'F' : 'C'
      };
    } catch (error) {
      console.error('Error getting temperature data:', error);
      // Fallback to reasonable defaults for Grand Canyon
      const useImperial = options?.units === 'imperial';
      const defaultCelsius = { avgDaily: 15, avgMax: 22, avgMin: 8 };
      
      return {
        avgDaily: useImperial ? this.celsiusToFahrenheit(defaultCelsius.avgDaily) : defaultCelsius.avgDaily,
        avgMax: useImperial ? this.celsiusToFahrenheit(defaultCelsius.avgMax) : defaultCelsius.avgMax,
        avgMin: useImperial ? this.celsiusToFahrenheit(defaultCelsius.avgMin) : defaultCelsius.avgMin,
        humidity: 'low',
        unit: useImperial ? 'F' : 'C'
      };
    }
  }

  async getWeatherAlongTrail(coordinates: [number, number][], startDate: string, options?: { units?: 'metric' | 'imperial' }): Promise<TrailWeatherData[]> {
    const weatherPoints: TrailWeatherData[] = [];
    const month = new Date(startDate).getMonth() + 1;
    const baseWeather = this.grandCanyonAverages[month as keyof typeof this.grandCanyonAverages];
    
    // Estimate elevation for each point based on Grand Canyon topography
    for (let i = 0; i < coordinates.length; i++) {
      const [lat, lng] = coordinates[i];
      const estimatedElevation = this.estimateElevation(lat, lng);
      
      // Adjust temperature based on elevation (cooler at higher elevations)
      const rimElevation = 2134; // South Rim elevation in meters
      const elevationDiff = estimatedElevation - rimElevation;
      const tempAdjustment = (elevationDiff / 100) * this.elevationLapseRate;
      
      const useImperial = options?.units === 'imperial';
      const tempMin = baseWeather.min - tempAdjustment;
      const tempMax = baseWeather.max - tempAdjustment;
      const tempAvg = baseWeather.avg - tempAdjustment;
      
      const pointWeather: TrailWeatherData = {
        position: [lat, lng],
        elevation: useImperial ? this.metersToFeet(estimatedElevation) : estimatedElevation,
        temperature: {
          min: useImperial ? this.celsiusToFahrenheit(tempMin) : tempMin,
          max: useImperial ? this.celsiusToFahrenheit(tempMax) : tempMax,
          avg: useImperial ? this.celsiusToFahrenheit(tempAvg) : tempAvg
        },
        humidity: baseWeather.humidity,
        conditions: this.getConditionsForElevation(estimatedElevation, month),
        windExposure: this.getWindExposure(lat, lng),
        pointIndex: i,
        distanceFromStart: i > 0 ? this.calculateDistance(coordinates[0], coordinates[i]) : 0,
        elevationUnit: useImperial ? 'ft' : 'm',
        temperatureUnit: useImperial ? 'F' : 'C'
      };
      
      weatherPoints.push(pointWeather);
    }
    
    return weatherPoints;
  }
  
  private estimateElevation(lat: number, lng: number): number {
    // Grand Canyon elevation estimation based on known landmarks
    // South Rim: ~2134m, Colorado River: ~700m, North Rim: ~2438m
    
    // River level (bottom of canyon)
    const riverLat = 36.1058;
    const riverLng = -112.0947;
    const riverElevation = 700;
    
    // South Rim
    const southRimLat = 36.0544;
    const southRimLng = -112.1401;
    const southRimElevation = 2134;
    
    // Distance to river (lower = closer to river level)
    const distToRiver = this.calculateDistance([lat, lng], [riverLat, riverLng]);
    const distToSouthRim = this.calculateDistance([lat, lng], [southRimLat, southRimLng]);
    
    // Simple interpolation based on proximity to known elevations
    if (distToRiver < 5) {
      // Close to river
      return riverElevation + (distToRiver / 5) * 500;
    } else if (distToSouthRim < 10) {
      // Close to South Rim
      return southRimElevation - (distToSouthRim / 10) * 400;
    } else {
      // General canyon area - interpolate
      const riverWeight = 1 / (distToRiver + 1);
      const rimWeight = 1 / (distToSouthRim + 1);
      const totalWeight = riverWeight + rimWeight;
      
      return (riverElevation * riverWeight + southRimElevation * rimWeight) / totalWeight;
    }
  }
  
  private calculateDistance(point1: [number, number], point2: [number, number]): number {
    const [lat1, lng1] = point1;
    const [lat2, lng2] = point2;
    
    const R = 6371; // Earth's radius in km
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLng = (lng2 - lng1) * Math.PI / 180;
    const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
              Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
              Math.sin(dLng/2) * Math.sin(dLng/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    return R * c;
  }
  
  private getConditionsForElevation(elevation: number, month: number): string {
    const isWinter = month >= 11 || month <= 3;
    const isSummer = month >= 6 && month <= 8;
    
    if (elevation > 2000) {
      // Rim level
      if (isWinter) return "Cold, possible snow/ice";
      if (isSummer) return "Warm days, cool nights";
      return "Moderate, variable conditions";
    } else if (elevation > 1500) {
      // Mid-canyon
      if (isWinter) return "Cool, less wind";
      if (isSummer) return "Hot, some shade";
      return "Pleasant hiking conditions";
    } else {
      // Inner canyon/river level
      if (isWinter) return "Mild, protected from wind";
      if (isSummer) return "Very hot, seek shade";
      return "Warm, sheltered";
    }
  }
  
  private getWindExposure(lat: number, lng: number): 'low' | 'moderate' | 'high' {
    // South Rim areas are more exposed to wind
    const rimProximity = this.calculateDistance([lat, lng], [36.0544, -112.1401]);
    
    if (rimProximity < 2) return 'high';
    if (rimProximity < 8) return 'moderate';
    return 'low';
  }

  private celsiusToFahrenheit(celsius: number): number {
    return (celsius * 9/5) + 32;
  }
  
  private metersToFeet(meters: number): number {
    return meters * 3.28084;
  }

  getSeasonalAdvice(month: number): string {
    const advice = {
      1: "Winter conditions: Very cold nights, possible snow. Pack warm layers and extra water as sources may be frozen.",
      2: "Late winter: Cold but improving. Ice may still be present on trails. Extra caution needed.",
      3: "Early spring: Variable weather. Days warming but nights still cold. Good hiking season begins.",
      4: "Spring: Excellent hiking weather. Comfortable temperatures, wildflowers possible.",
      5: "Late spring: Warm days, mild nights. Prime hiking season. Water consumption increases.",
      6: "Early summer: Hot days, warm nights. High water consumption essential. Start early.",
      7: "Summer: Very hot. Extreme heat danger. Consider dawn starts or avoid midday hiking.",
      8: "Late summer: Still very hot with monsoon possibility. High water needs, watch weather.",
      9: "Early fall: Cooling but still warm. Good hiking returns. Weather becomes more stable.",
      10: "Fall: Excellent conditions return. Comfortable days, cool nights. Prime season.",
      11: "Late fall: Cool days, cold nights. Good hiking but prepare for temperature swings.",
      12: "Winter: Cold conditions return. Short days, possible snow. Plan accordingly."
    };
    
    return advice[month as keyof typeof advice] || "Check current weather conditions before hiking.";
  }
}

export const weatherService = new WeatherService();