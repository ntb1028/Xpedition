export interface MealCalculationParams {
  dailyDistance: number;
  elevationGain?: number;
  bodyWeight: number;
  packWeight?: number;
  totalDays: number;
  isMetric?: boolean;
  activityFactor?: number;
}

export interface MealCalculationResult {
  dailyCalories: number;
  totalCalories: number;
  bmr: number;
  hikingCalories: number;
  packAdjustment: number;
}

export interface FoodItem {
  id: string;
  name: string;
  category: 'breakfast' | 'lunch' | 'dinner' | 'snack';
  caloriesPer100g: number;
  weight: number; // grams per serving
  calories: number; // calories per serving
  protein: number; // grams per serving
  carbs: number; // grams per serving
  fat: number; // grams per serving
  dietaryTags: string[]; // ['vegan', 'gluten-free', 'nut-free', etc.]
  description: string;
}

export interface MealPlan {
  name: string;
  days: MealDay[];
  totalCalories: number;
  totalWeight: number; // grams
  averageDailyCalories: number;
  averageDailyWeight: number;
}

export interface MealDay {
  day: number;
  meals: {
    breakfast: FoodItem[];
    lunch: FoodItem[];
    dinner: FoodItem[];
    snacks: FoodItem[];
  };
  totalCalories: number;
  totalWeight: number;
}

export class MealCalculator {
  // Constants from requirements document
  private static readonly BMR_MULTIPLIER = 22; // kcal per kg body weight
  private static readonly ENERGY_PER_KM = 1.0; // kcal per kg per km
  private static readonly ELEVATION_FACTOR = 10; // kcal per 100m elevation gain
  private static readonly PACK_PENALTY = 0.05; // factor per kg pack weight per km

  static calculateCalories(params: MealCalculationParams): MealCalculationResult {
    const {
      dailyDistance,
      elevationGain = 0,
      bodyWeight,
      packWeight = 0,
      activityFactor = 1.3,
      isMetric = false
    } = params;

    // Convert to metric if needed
    const bodyWeightKg = isMetric ? bodyWeight : bodyWeight * 0.453592;
    const packWeightKg = isMetric ? packWeight : packWeight * 0.453592;
    const distanceKm = isMetric ? dailyDistance : dailyDistance * 1.60934;
    const elevationM = isMetric ? elevationGain : elevationGain * 0.3048;

    // Step 1: Base metabolic rate (simplified Schofield equation)
    const bmr = MealCalculator.BMR_MULTIPLIER * bodyWeightKg;

    // Step 2: Hiking energy cost
    const hikingEnergy = MealCalculator.ENERGY_PER_KM * bodyWeightKg * distanceKm;
    const elevationAdjustment = MealCalculator.ELEVATION_FACTOR * (elevationM / 100);
    const hikingCalories = hikingEnergy + elevationAdjustment;

    // Step 3: Pack weight penalty
    const packAdjustment = MealCalculator.PACK_PENALTY * packWeightKg * distanceKm;

    // Step 4: Total Daily Energy Expenditure
    const dailyCalories = Math.round((bmr * activityFactor) + hikingCalories + packAdjustment);
    const totalCalories = dailyCalories * params.totalDays;

    return {
      dailyCalories,
      totalCalories,
      bmr: Math.round(bmr),
      hikingCalories: Math.round(hikingCalories),
      packAdjustment: Math.round(packAdjustment)
    };
  }

  static generateMealPlan(
    targetCalories: number,
    days: number,
    dietaryRestrictions: string[] = []
  ): MealPlan {
    const foodDatabase = MealCalculator.getFoodDatabase();
    const filteredFoods = MealCalculator.filterFoodsByDiet(foodDatabase, dietaryRestrictions);
    
    const mealDays: MealDay[] = [];
    let totalCalories = 0;
    let totalWeight = 0;
    const usedMeals = new Set<string>();

    for (let day = 1; day <= days; day++) {
      const dayMeals = MealCalculator.generateDayMeals(targetCalories, filteredFoods, day, usedMeals);
      mealDays.push(dayMeals);
      totalCalories += dayMeals.totalCalories;
      totalWeight += dayMeals.totalWeight;
    }

    return {
      name: `${days}-Day Meal Plan`,
      days: mealDays,
      totalCalories,
      totalWeight,
      averageDailyCalories: Math.round(totalCalories / days),
      averageDailyWeight: Math.round(totalWeight / days)
    };
  }

  private static generateDayMeals(targetCalories: number, foods: FoodItem[], dayNumber: number, usedMeals: Set<string> = new Set()): MealDay {
    const breakfastTarget = Math.round(targetCalories * 0.25);
    const lunchTarget = Math.round(targetCalories * 0.35);
    const dinnerTarget = Math.round(targetCalories * 0.30);
    const snackTarget = Math.round(targetCalories * 0.10);

    const breakfast = MealCalculator.selectMealsForTarget(
      foods.filter(f => f.category === 'breakfast'),
      breakfastTarget,
      usedMeals,
      'breakfast'
    );
    const lunch = MealCalculator.selectMealsForTarget(
      foods.filter(f => f.category === 'lunch'),
      lunchTarget,
      usedMeals,
      'lunch'
    );
    const dinner = MealCalculator.selectMealsForTarget(
      foods.filter(f => f.category === 'dinner'),
      dinnerTarget,
      usedMeals,
      'dinner'
    );
    const snacks = MealCalculator.selectMealsForTarget(
      foods.filter(f => f.category === 'snack'),
      snackTarget,
      usedMeals,
      'snack'
    );

    const allMeals = [...breakfast, ...lunch, ...dinner, ...snacks];
    const totalCalories = allMeals.reduce((sum, item) => sum + item.calories, 0);
    const totalWeight = allMeals.reduce((sum, item) => sum + item.weight, 0);

    return {
      day: dayNumber,
      meals: { breakfast, lunch, dinner, snacks },
      totalCalories,
      totalWeight
    };
  }

  private static selectMealsForTarget(foods: FoodItem[], targetCalories: number, usedMeals: Set<string> = new Set(), mealType: string = ''): FoodItem[] {
    if (foods.length === 0) return [];
    
    const selected: FoodItem[] = [];
    let remainingCalories = targetCalories;
    
    // Sort by calorie density (calories per gram) for efficiency
    const sortedFoods = foods.sort((a, b) => (b.calories / b.weight) - (a.calories / a.weight));
    
    // For lunch and dinner, prioritize variety by avoiding recently used meals
    const availableFoods = (mealType === 'lunch' || mealType === 'dinner') 
      ? sortedFoods.filter(food => !usedMeals.has(`${mealType}-${food.id}`))
      : sortedFoods;
    
    // If we've used all options, reset and use any food
    const foodsToUse = availableFoods.length > 0 ? availableFoods : sortedFoods;
    
    for (const food of foodsToUse) {
      if (remainingCalories <= 0) break;
      if (food.calories <= remainingCalories * 1.2) { // Allow 20% overage
        selected.push(food);
        remainingCalories -= food.calories;
        
        // Mark this meal as used for variety tracking
        if (mealType === 'lunch' || mealType === 'dinner') {
          usedMeals.add(`${mealType}-${food.id}`);
        }
        
        // For main meals, usually just select one primary item
        if ((mealType === 'lunch' || mealType === 'dinner') && selected.length >= 1) {
          break;
        }
      }
    }
    
    return selected;
  }

  private static filterFoodsByDiet(foods: FoodItem[], restrictions: string[]): FoodItem[] {
    if (restrictions.length === 0) return foods;
    
    return foods.filter(food => 
      restrictions.every(restriction => 
        food.dietaryTags.includes(restriction)
      )
    );
  }

  static getFoodDatabase(): FoodItem[] {
    return [
      // Breakfast items
      {
        id: 'oatmeal-instant',
        name: 'Instant Oatmeal',
        category: 'breakfast',
        caloriesPer100g: 380,
        weight: 50,
        calories: 190,
        protein: 5,
        carbs: 32,
        fat: 4,
        dietaryTags: ['vegan', 'gluten-free'],
        description: 'Quick-cooking oats with dried fruit'
      },
      {
        id: 'granola',
        name: 'Trail Granola',
        category: 'breakfast',
        caloriesPer100g: 450,
        weight: 60,
        calories: 270,
        protein: 8,
        carbs: 35,
        fat: 12,
        dietaryTags: ['vegetarian'],
        description: 'Crunchy granola with nuts and seeds'
      },
      {
        id: 'freeze-dried-scramble',
        name: 'Freeze-Dried Scrambled Eggs',
        category: 'breakfast',
        caloriesPer100g: 380,
        weight: 45,
        calories: 171,
        protein: 13,
        carbs: 3,
        fat: 12,
        dietaryTags: ['gluten-free'],
        description: 'Just add hot water'
      },

      // Lunch items
      {
        id: 'trail-mix',
        name: 'Premium Trail Mix',
        category: 'lunch',
        caloriesPer100g: 550,
        weight: 80,
        calories: 440,
        protein: 15,
        carbs: 35,
        fat: 30,
        dietaryTags: ['vegetarian', 'gluten-free'],
        description: 'Nuts, dried fruit, and dark chocolate'
      },
      {
        id: 'peanut-butter-wrap',
        name: 'PB&J Tortilla Wrap',
        category: 'lunch',
        caloriesPer100g: 320,
        weight: 120,
        calories: 384,
        protein: 12,
        carbs: 45,
        fat: 16,
        dietaryTags: ['vegetarian'],
        description: 'Tortilla with peanut butter and jam'
      },
      {
        id: 'jerky-beef',
        name: 'Beef Jerky',
        category: 'lunch',
        caloriesPer100g: 410,
        weight: 35,
        calories: 144,
        protein: 25,
        carbs: 4,
        fat: 4,
        dietaryTags: ['gluten-free'],
        description: 'High-protein dried meat'
      },
      {
        id: 'tuna-crackers',
        name: 'Tuna & Crackers',
        category: 'lunch',
        caloriesPer100g: 380,
        weight: 95,
        calories: 361,
        protein: 18,
        carbs: 28,
        fat: 20,
        dietaryTags: ['gluten-free'],
        description: 'Tuna pouch with whole grain crackers'
      },
      {
        id: 'hummus-pita',
        name: 'Hummus & Pita Chips',
        category: 'lunch',
        caloriesPer100g: 350,
        weight: 110,
        calories: 385,
        protein: 12,
        carbs: 48,
        fat: 16,
        dietaryTags: ['vegan'],
        description: 'Chickpea hummus with baked pita'
      },
      {
        id: 'cheese-salami',
        name: 'Cheese & Salami',
        category: 'lunch',
        caloriesPer100g: 450,
        weight: 85,
        calories: 383,
        protein: 22,
        carbs: 3,
        fat: 32,
        dietaryTags: ['gluten-free'],
        description: 'Hard cheese and cured meat'
      },

      // Dinner items
      {
        id: 'freeze-dried-chili',
        name: 'Freeze-Dried Chili Mac',
        category: 'dinner',
        caloriesPer100g: 450,
        weight: 110,
        calories: 495,
        protein: 20,
        carbs: 65,
        fat: 18,
        dietaryTags: ['gluten-free'],
        description: 'Hearty pasta with beans and spices'
      },
      {
        id: 'dehydrated-curry',
        name: 'Coconut Curry Rice',
        category: 'dinner',
        caloriesPer100g: 380,
        weight: 120,
        calories: 456,
        protein: 15,
        carbs: 70,
        fat: 12,
        dietaryTags: ['vegan', 'gluten-free'],
        description: 'Fragrant rice with vegetables'
      },
      {
        id: 'pasta-marinara',
        name: 'Pasta Marinara',
        category: 'dinner',
        caloriesPer100g: 350,
        weight: 130,
        calories: 455,
        protein: 18,
        carbs: 75,
        fat: 8,
        dietaryTags: ['vegetarian'],
        description: 'Classic pasta with tomato sauce'
      },
      {
        id: 'beef-stroganoff',
        name: 'Beef Stroganoff',
        category: 'dinner',
        caloriesPer100g: 420,
        weight: 115,
        calories: 483,
        protein: 22,
        carbs: 58,
        fat: 16,
        dietaryTags: [],
        description: 'Creamy beef and noodle dish'
      },
      {
        id: 'pad-thai',
        name: 'Pad Thai Noodles',
        category: 'dinner',
        caloriesPer100g: 390,
        weight: 125,
        calories: 488,
        protein: 16,
        carbs: 68,
        fat: 14,
        dietaryTags: ['vegetarian'],
        description: 'Sweet and savory rice noodles'
      },
      {
        id: 'lentil-stew',
        name: 'Moroccan Lentil Stew',
        category: 'dinner',
        caloriesPer100g: 360,
        weight: 135,
        calories: 486,
        protein: 19,
        carbs: 72,
        fat: 9,
        dietaryTags: ['vegan', 'gluten-free'],
        description: 'Spiced lentils with dried fruit'
      },
      {
        id: 'chicken-teriyaki',
        name: 'Teriyaki Chicken Rice',
        category: 'dinner',
        caloriesPer100g: 400,
        weight: 118,
        calories: 472,
        protein: 24,
        carbs: 62,
        fat: 12,
        dietaryTags: ['gluten-free'],
        description: 'Sweet glazed chicken with rice'
      },

      // Snack items
      {
        id: 'energy-bar',
        name: 'Protein Energy Bar',
        category: 'snack',
        caloriesPer100g: 420,
        weight: 65,
        calories: 273,
        protein: 20,
        carbs: 25,
        fat: 12,
        dietaryTags: ['vegetarian', 'gluten-free'],
        description: 'Dense nutrition bar'
      },
      {
        id: 'dried-fruit',
        name: 'Mixed Dried Fruit',
        category: 'snack',
        caloriesPer100g: 320,
        weight: 40,
        calories: 128,
        protein: 2,
        carbs: 32,
        fat: 1,
        dietaryTags: ['vegan', 'gluten-free'],
        description: 'Natural fruit leather and pieces'
      },
      {
        id: 'nuts-almonds',
        name: 'Roasted Almonds',
        category: 'snack',
        caloriesPer100g: 580,
        weight: 30,
        calories: 174,
        protein: 6,
        carbs: 6,
        fat: 15,
        dietaryTags: ['vegan', 'gluten-free'],
        description: 'Lightly salted almonds'
      }
    ];
  }
}