import type { Calculation, UserPreferences } from "@shared/schema";

export interface StoredCalculation extends Omit<Calculation, 'id' | 'createdAt'> {
  id: string;
  createdAt: string;
}

export interface StoredPreferences extends Omit<UserPreferences, 'id'> {}

class LocalStorage {
  private static readonly CALCULATIONS_KEY = 'hydration-calc-calculations';
  private static readonly PREFERENCES_KEY = 'hydration-calc-preferences';
  private static readonly MAX_CALCULATIONS = 50;

  // Calculations
  saveCalculation(calculation: Omit<StoredCalculation, 'id' | 'createdAt'>): StoredCalculation {
    const calculations = this.getCalculations();
    const newCalculation: StoredCalculation = {
      ...calculation,
      id: crypto.randomUUID(),
      createdAt: new Date().toISOString()
    };

    calculations.unshift(newCalculation);
    
    // Keep only the most recent calculations
    if (calculations.length > LocalStorage.MAX_CALCULATIONS) {
      calculations.splice(LocalStorage.MAX_CALCULATIONS);
    }

    localStorage.setItem(LocalStorage.CALCULATIONS_KEY, JSON.stringify(calculations));
    return newCalculation;
  }

  getCalculations(): StoredCalculation[] {
    try {
      const stored = localStorage.getItem(LocalStorage.CALCULATIONS_KEY);
      return stored ? JSON.parse(stored) : [];
    } catch {
      return [];
    }
  }

  deleteCalculation(id: string): void {
    const calculations = this.getCalculations().filter(calc => calc.id !== id);
    localStorage.setItem(LocalStorage.CALCULATIONS_KEY, JSON.stringify(calculations));
  }

  clearCalculations(): void {
    localStorage.removeItem(LocalStorage.CALCULATIONS_KEY);
  }

  // Preferences
  savePreferences(preferences: StoredPreferences): void {
    localStorage.setItem(LocalStorage.PREFERENCES_KEY, JSON.stringify(preferences));
  }

  getPreferences(): StoredPreferences {
    try {
      const stored = localStorage.getItem(LocalStorage.PREFERENCES_KEY);
      return stored ? JSON.parse(stored) : {
        units: 'imperial',
        dyslexiaFont: false,
        largeText: false,
        highContrast: false,
        conservative: true
      };
    } catch {
      return {
        units: 'imperial',
        dyslexiaFont: false,
        largeText: false,
        highContrast: false,
        conservative: true
      };
    }
  }

  // Export/Import functionality
  exportData(): string {
    const data = {
      calculations: this.getCalculations(),
      preferences: this.getPreferences(),
      exportDate: new Date().toISOString()
    };
    return JSON.stringify(data, null, 2);
  }

  importData(jsonData: string): void {
    try {
      const data = JSON.parse(jsonData);
      
      if (data.calculations && Array.isArray(data.calculations)) {
        localStorage.setItem(LocalStorage.CALCULATIONS_KEY, JSON.stringify(data.calculations));
      }
      
      if (data.preferences && typeof data.preferences === 'object') {
        localStorage.setItem(LocalStorage.PREFERENCES_KEY, JSON.stringify(data.preferences));
      }
    } catch (error) {
      throw new Error('Invalid import data format');
    }
  }
}

export const localStorage_storage = new LocalStorage();
