import { useState, useCallback, useEffect } from 'react';
import { MapContainer, TileLayer, Marker, Popup, Polyline, useMapEvents } from 'react-leaflet';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { usePreferences } from '@/hooks/use-preferences';
import { Trash2, Plus, MapPin, Droplets, Mountain, Eye, Tent, Edit2, Check, X, Maximize2, Minimize2, Route } from 'lucide-react';
import { npsApi, NPSTrail, NPSWaypoint } from '@/lib/nps-api';
import { overpassAPI, OSMTrail } from '@/lib/overpass-api';
import { weatherService, TemperatureAverages, TrailWeatherData } from '@/lib/weather-api';
import { waterSourcesAPI, WaterSource } from '@/lib/water-sources-api';
import { HydrationCalculator } from '@/lib/hydration-calculator';
import { MealCalculator } from '@/lib/meal-calculator';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';

// Fix for default markers not showing
delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.3.1/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.3.1/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.3.1/images/marker-shadow.png',
});

interface RoutePoint {
  lat: number;
  lng: number;
  name: string;
  type: 'start' | 'end' | 'waypoint' | 'water' | 'camp' | 'trailhead' | 'viewpoint';
  elevation?: number;
  draggable?: boolean;
  isEditing?: boolean;
}

interface RouteMapProps {
  onRouteChange?: (distance: number, elevationGain: number) => void;
}

function MapClickHandler({ onMapClick }: { onMapClick: (lat: number, lng: number) => void }) {
  useMapEvents({
    click: (e) => {
      onMapClick(e.latlng.lat, e.latlng.lng);
    }
  });
  return null;
}

function MapEventHandler({ onMapMove, onMapReady, isExpanded }: { 
  onMapMove: (center: [number, number], zoom: number) => void;
  onMapReady: (map: any) => void;
  isExpanded: boolean;
}) {
  const map = useMapEvents({
    moveend: () => {
      const center = map.getCenter();
      const zoom = map.getZoom();
      onMapMove([center.lat, center.lng], zoom);
    },
    zoomend: () => {
      const center = map.getCenter();
      const zoom = map.getZoom();
      onMapMove([center.lat, center.lng], zoom);
    }
  });

  useEffect(() => {
    onMapReady(map);
  }, [map, onMapReady]);

  // Invalidate map size when expansion state changes
  useEffect(() => {
    if (map) {
      setTimeout(() => {
        map.invalidateSize();
      }, 100);
    }
  }, [map, isExpanded]);

  return null;
}

export function RouteMapFixed({ onRouteChange }: RouteMapProps) {
  const { preferences, updatePreferences } = usePreferences();
  const [osmTrails, setOsmTrails] = useState<OSMTrail[]>([]);
  const [selectedTrails, setSelectedTrails] = useState<string[]>([]);
  const [routePoints, setRoutePoints] = useState<RoutePoint[]>([]);
  const [isLoadingTrails, setIsLoadingTrails] = useState(false);
  const [showTripPlanning, setShowTripPlanning] = useState(false);
  const [startDate, setStartDate] = useState('');
  const [tripDays, setTripDays] = useState(1);
  const [tripCalculations, setTripCalculations] = useState<{
    water: any;
    food: any;
    distance: number;
    elevation: number;
  } | null>(null);
  const [weatherData, setWeatherData] = useState<TemperatureAverages | null>(null);
  const [trailWeatherData, setTrailWeatherData] = useState<TrailWeatherData[]>([]);
  const [mapCenter, setMapCenter] = useState<[number, number]>([36.1069, -112.1129]);
  const [mapZoom, setMapZoom] = useState(11);
  const [mapInstance, setMapInstance] = useState<any>(null);
  const [waterSources, setWaterSources] = useState<WaterSource[]>([]);
  const [showWaterSources, setShowWaterSources] = useState(true);

  // Grand Canyon center coordinates and zoom
  const center: [number, number] = [36.1069, -112.1129]; // Grand Canyon Village
  const zoom = 11;

  // Generate trail path coordinates for map display
  const getTrailPath = (trail: NPSTrail): [number, number][] => {
    return trail.geometry.coordinates;
  };

  const getOSMTrailPath = (trail: OSMTrail): [number, number][] => {
    // Filter out bridge coordinates that break trail continuity
    // Bridges often have tags or are isolated points that create gaps
    const mainTrail = trail.coordinates.filter((coord, index) => {
      if (index === 0 || index === trail.coordinates.length - 1) return true;

      // Check if this point is too far from adjacent points (likely a bridge)
      const prev = trail.coordinates[index - 1];
      const next = trail.coordinates[index + 1];

      if (!prev || !next) return true;

      // Calculate distance to previous and next points
      const distToPrev = Math.abs(coord[0] - prev[0]) + Math.abs(coord[1] - prev[1]);
      const distToNext = Math.abs(coord[0] - next[0]) + Math.abs(coord[1] - next[1]);

      // If point is significantly far from neighbors, it might be a bridge
      const threshold = 0.002; // Roughly 200m in lat/lng degrees
      return distToPrev < threshold && distToNext < threshold;
    });

    return mainTrail;
  };

  // Handle trail click on map (for multiple trail selection by name)
  const handleTrailClick = useCallback((trailId: string) => {
    const clickedTrail = osmTrails.find(t => t.id === trailId);
    if (!clickedTrail) return;

    // Find all segments with the same trail name
    const sameNameTrails = osmTrails.filter(t => t.name === clickedTrail.name);
    const sameNameIds = sameNameTrails.map(t => t.id);

    setSelectedTrails(prev => {
      // Check if any segment of this trail is already selected
      const hasAnySelected = sameNameIds.some(id => prev.includes(id));

      if (hasAnySelected) {
        // Remove all segments of this trail
        return prev.filter(id => !sameNameIds.includes(id));
      } else {
        // Add all segments of this trail
        return [...prev, ...sameNameIds];
      }
    });
  }, [osmTrails]);

  // Clear all selected trails
  const clearSelectedTrails = useCallback(() => {
    setSelectedTrails([]);
    setSelectedTrail('');
    setHighlightedTrail(null);
    setHighlightedOSMTrail(null);
    setRoutePoints([]);
  }, []);

  const getWaterSourceIcon = (waterSource: WaterSource) => {
    const iconConfig = {
      iconSize: [28, 28] as [number, number],
      iconAnchor: [14, 14] as [number, number],
      popupAnchor: [0, -14] as [number, number],
    };

    const getColor = () => {
      switch (waterSource.availability) {
        case 'year_round': return '#22c55e';
        case 'seasonal': return '#f59e0b';
        case 'unreliable': return '#ef4444';
        case 'closed': return '#6b7280';
        default: return '#3b82f6';
      }
    };

    const getSymbol = () => {
      switch (waterSource.type) {
        case 'trailhead': return '🚰';
        case 'year_round': return '💧';
        case 'seasonal': return '🌊';
        case 'emergency': return '🆘';
        case 'unreliable': return '⚠️';
        default: return '💧';
      }
    };

    return L.divIcon({
      ...iconConfig,
      html: `<div style="background: ${getColor()}; border-radius: 50%; width: 28px; height: 28px; display: flex; align-items: center; justify-content: center; color: white; border: 3px solid white; box-shadow: 0 2px 6px rgba(0,0,0,0.4); font-size: 12px;">${getSymbol()}</div>`,
      className: 'water-source-marker'
    });
  };

  const getMarkerIcon = (type: string) => {
    const iconConfig = {
      iconSize: [25, 25] as [number, number],
      iconAnchor: [12, 12] as [number, number],
      popupAnchor: [0, -12] as [number, number],
    };

    switch (type) {
      case 'start':
        return L.divIcon({
          ...iconConfig,
          html: '<div style="background: #22c55e; border-radius: 50%; width: 25px; height: 25px; display: flex; align-items: center; justify-content: center; color: white; font-weight: bold; border: 2px solid white; box-shadow: 0 2px 4px rgba(0,0,0,0.3);">S</div>',
          className: 'custom-marker'
        });
      case 'end':
        return L.divIcon({
          ...iconConfig,
          html: '<div style="background: #ef4444; border-radius: 50%; width: 25px; height: 25px; display: flex; align-items: center; justify-content: center; color: white; font-weight: bold; border: 2px solid white; box-shadow: 0 2px 4px rgba(0,0,0,0.3);">E</div>',
          className: 'custom-marker'
        });
      case 'water':
        return L.divIcon({
          ...iconConfig,
          html: '<div style="background: #3b82f6; border-radius: 50%; width: 25px; height: 25px; display: flex; align-items: center; justify-content: center; color: white; border: 2px solid white; box-shadow: 0 2px 4px rgba(0,0,0,0.3);">💧</div>',
          className: 'custom-marker'
        });
      case 'camp':
        return L.divIcon({
          ...iconConfig,
          html: '<div style="background: #f59e0b; border-radius: 50%; width: 25px; height: 25px; display: flex; align-items: center; justify-content: center; color: white; border: 2px solid white; box-shadow: 0 2px 4px rgba(0,0,0,0.3);">⛺</div>',
          className: 'custom-marker'
        });
      case 'trailhead':
        return L.divIcon({
          ...iconConfig,
          html: '<div style="background: #8b5cf6; border-radius: 50%; width: 25px; height: 25px; display: flex; align-items: center; justify-content: center; color: white; border: 2px solid white; box-shadow: 0 2px 4px rgba(0,0,0,0.3);">🥾</div>',
          className: 'custom-marker'
        });
      case 'viewpoint':
        return L.divIcon({
          ...iconConfig,
          html: '<div style="background: #06b6d4; border-radius: 50%; width: 25px; height: 25px; display: flex; align-items: center; justify-content: center; color: white; border: 2px solid white; box-shadow: 0 2px 4px rgba(0,0,0,0.3);">👁️</div>',
          className: 'custom-marker'
        });
      default:
        return L.divIcon({
          ...iconConfig,
          html: '<div style="background: #6b7280; border-radius: 50%; width: 25px; height: 25px; display: flex; align-items: center; justify-content: center; color: white; font-weight: bold; border: 2px solid white; box-shadow: 0 2px 4px rgba(0,0,0,0.3);">•</div>',
          className: 'custom-marker'
        });
    }
  };

  const addRoutePoint = useCallback((lat: number, lng: number, type: RoutePoint['type']) => {
    const newPoint: RoutePoint = {
      lat,
      lng,
      name: `${type.charAt(0).toUpperCase() + type.slice(1)} ${routePoints.length + 1}`,
      type,
      draggable: true
    };
    setRoutePoints(prev => [...prev, newPoint]);
  }, [routePoints.length]);

  const updateRoutePoint = useCallback((index: number, updates: Partial<RoutePoint>) => {
    setRoutePoints(prev => prev.map((point, i) => i === index ? { ...point, ...updates } : point));
  }, []);

  const deleteRoutePoint = useCallback((index: number) => {
    setRoutePoints(prev => prev.filter((_, i) => i !== index));
  }, []);

  const clearRoute = useCallback(() => {
    setRoutePoints([]);
    setSelectedTrail('');
    setSelectedTrails([]);
    setHighlightedTrail(null);
    setHighlightedOSMTrail(null);
  }, []);

  // Load trails from both NPS API and OpenStreetMap
  useEffect(() => {
    const loadTrails = async () => {
      setIsLoadingTrails(true);
      try {
        // Load authentic trail geometry from OpenStreetMap
        const osmTrailData = await overpassAPI.getGrandCanyonTrails();
        setOsmTrails(osmTrailData);

        // Load trail metadata from NPS API
        const npsTrailData = await npsApi.getGrandCanyonTrails();
        setNpsTrails(npsTrailData);

        // Load water sources
        const waterSourceData = await waterSourcesAPI.getAllWaterSources();
        setWaterSources(waterSourceData);
      } catch (error) {
        console.error('Failed to load Grand Canyon trails:', error);
      } finally {
        setIsLoadingTrails(false);
      }
    };

    loadTrails();
  }, []);

  // Handle trail selection
  const handleTrailSelection = useCallback((trailNameOrId: string) => {
    if (trailNameOrId === 'custom') {
      setSelectedTrail('');
      setHighlightedTrail(null);
      setHighlightedOSMTrail(null);
      setRoutePoints([]);
      setSelectedTrails([]);
      return;
    }

    // Check if this is a trail name (from dropdown) or trail ID (from map click)
    const isTrailName = !trailNameOrId.startsWith('osm-') && !trailNameOrId.includes('-segment-');

    if (isTrailName) {
      // This is a trail name from the dropdown - add all segments with this name
      const trailSegments = osmTrails.filter(t => t.name === trailNameOrId);
      const segmentIds = trailSegments.map(t => t.id);

      // Check if this trail is already selected
      const isAlreadySelected = segmentIds.some(id => selectedTrails.includes(id));

      if (!isAlreadySelected) {
        // Add new trail segments to existing selection
        setSelectedTrails(prev => [...prev, ...segmentIds]);
        // Update selected trail to show multiple if needed
        const currentTrailNames = new Set();
        [...selectedTrails, ...segmentIds].forEach(trailId => {
          const trail = osmTrails.find(t => t.id === trailId);
          if (trail) currentTrailNames.add(trail.name);
        });
        setSelectedTrail(currentTrailNames.size > 1 ? 'multiple' : trailNameOrId);
      }

      setHighlightedTrail(null);
      setHighlightedOSMTrail(null);
      setRoutePoints([]);
      return;
    }

    // This is a specific trail ID (legacy handling for map clicks)
    // Check OSM trails first for authentic geometry
    const osmTrail = osmTrails.find(t => t.id === trailNameOrId);
    if (osmTrail) {
      // Find all segments with the same trail name
      const allSegments = osmTrails.filter(t => t.name === osmTrail.name);
      const segmentIds = allSegments.map(t => t.id);

      // Check if any segment of this trail is already selected
      const hasAnySelected = segmentIds.some(id => selectedTrails.includes(id));

      if (hasAnySelected) {
        // Remove all segments of this trail
        setSelectedTrails(prev => prev.filter(id => !segmentIds.includes(id)));
      } else {
        // Add all segments of this trail
        setSelectedTrails(prev => [...prev, ...segmentIds]);
      }

      // Update selected trail display
      const remainingTrails = selectedTrails.filter(id => !segmentIds.includes(id));
      const trailNames = new Set();
      if (!hasAnySelected) {
        [...remainingTrails, ...segmentIds].forEach(trailId => {
          const trail = osmTrails.find(t => t.id === trailId);
          if (trail) trailNames.add(trail.name);
        });
      } else {
        remainingTrails.forEach(trailId => {
          const trail = osmTrails.find(t => t.id === trailId);
          if (trail) trailNames.add(trail.name);
        });
      }
      setSelectedTrail(trailNames.size > 1 ? 'multiple' : trailNames.size === 1 ? Array.from(trailNames)[0] : '');

      setHighlightedTrail(null);
      setHighlightedOSMTrail(null);
      setRoutePoints([]);
      return;
    }

    // Fallback to NPS trails if no OSM trail found
    const npsTrail = npsTrails.find(t => t.id === trailNameOrId);
    if (npsTrail) {
      setSelectedTrail(trailNameOrId);
      setHighlightedTrail(npsTrail);
      setHighlightedOSMTrail(null);
      setSelectedTrails([]);
      setRoutePoints([]);
    }
  }, [osmTrails, npsTrails, selectedTrails]);

  // Calculate total distance and elevation gain for selected trails
  useEffect(() => {
    if (selectedTrails.length > 0) {
      let totalDistance = 0;
      let totalElevationGain = 0;

      selectedTrails.forEach(trailId => {
        // Check OSM trails first
        const osmTrail = osmTrails.find(t => t.id === trailId);
        if (osmTrail) {
          // Calculate distance from OSM coordinates
          let trailDistance = 0;
          for (let i = 1; i < osmTrail.coordinates.length; i++) {
            const prev = osmTrail.coordinates[i - 1];
            const curr = osmTrail.coordinates[i];

            // Haversine formula for distance
            const R = 6371; // Earth's radius in km
            const dLat = (curr[0] - prev[0]) * Math.PI / 180;
            const dLng = (curr[1] - prev[1]) * Math.PI / 180;
            const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
                      Math.cos(prev[0] * Math.PI / 180) * Math.cos(curr[0] * Math.PI / 180) *
                      Math.sin(dLng/2) * Math.sin(dLng/2);
            const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
            trailDistance += R * c;
          }
          totalDistance += trailDistance;

          // Use NPS data for elevation if available
          const correspondingNPSTrail = npsTrails.find(t => 
            t.name.toLowerCase().includes(osmTrail.name.toLowerCase().split(' ')[0])
          );
          if (correspondingNPSTrail) {
            const elevation = parseFloat(correspondingNPSTrail.elevationGain.match(/[\d.]+/)?.[0] || '0');
            totalElevationGain += elevation;
          }
        } else {
          // Fallback to NPS trail data
          const npsTrail = npsTrails.find(t => t.id === trailId);
          if (npsTrail) {
            const distance = parseFloat(npsTrail.length.match(/[\d.]+/)?.[0] || '0');
            const elevation = parseFloat(npsTrail.elevationGain.match(/[\d.]+/)?.[0] || '0');
            totalDistance += distance * 1.60934; // Convert miles to km
            totalElevationGain += elevation;
          }
        }
      });

      onRouteChange?.(totalDistance, totalElevationGain * 0.3048); // Convert feet to meters
    } else if (highlightedTrail) {
      // Single trail selection fallback
      const distance = parseFloat(highlightedTrail.length.match(/[\d.]+/)?.[0] || '0');
      const elevation = parseFloat(highlightedTrail.elevationGain.match(/[\d.]+/)?.[0] || '0');
      onRouteChange?.(distance * 1.60934, elevation * 0.3048);
    } else if (routePoints.length >= 2) {
      // Custom route calculation
      let totalDistance = 0;
      let totalElevationGain = 0;

      for (let i = 1; i < routePoints.length; i++) {
        const prev = routePoints[i - 1];
        const curr = routePoints[i];

        const R = 6371;
        const dLat = (curr.lat - prev.lat) * Math.PI / 180;
        const dLng = (curr.lng - prev.lng) * Math.PI / 180;
        const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
                  Math.cos(prev.lat * Math.PI / 180) * Math.cos(curr.lat * Math.PI / 180) *
                  Math.sin(dLng/2) * Math.sin(dLng/2);
        const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
        totalDistance += R * c;

        if (prev.elevation && curr.elevation && curr.elevation > prev.elevation) {
          totalElevationGain += curr.elevation - prev.elevation;
        }
      }

      onRouteChange?.(totalDistance, totalElevationGain * 0.3048);
    }
  }, [selectedTrails, osmTrails, npsTrails, highlightedTrail, routePoints, onRouteChange]);

  // Helper function to get waypoint icon based on NPS type
  const getNPSWaypointIcon = (waypoint: NPSWaypoint) => {
    return getMarkerIcon(waypoint.type === 'campground' ? 'camp' : 
                        waypoint.type === 'water' ? 'water' :
                        waypoint.type === 'trailhead' ? 'trailhead' :
                        waypoint.type === 'viewpoint' ? 'viewpoint' : 'waypoint');
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="text-lg flex items-center gap-2">
          <Mountain className="h-5 w-5" />
          Grand Canyon Trail Planner
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Trail Selection */}
        <div className="space-y-2">
          <label className="text-sm font-medium">Add Trails to My Hike</label>
          <Select value="" onValueChange={handleTrailSelection} disabled={isLoadingTrails}>
            <SelectTrigger>
              <SelectValue placeholder={isLoadingTrails ? "Loading trails..." : "Add a trail to your hike"} />
            </SelectTrigger>
            <SelectContent className="z-[9999]">
              <SelectItem value="custom">Custom Route</SelectItem>
              {(() => {
                // Get unique trail names from OSM trails
                const uniqueTrailNames = [...new Set(osmTrails.map(trail => trail.name))];
                return uniqueTrailNames.map((trailName) => (
                  <SelectItem key={trailName} value={trailName}>
                    {trailName} (Authentic GPS Track)
                  </SelectItem>
                ));
              })()}
            </SelectContent>
          </Select>
        </div>

        {/* My Hike Summary */}
        {selectedTrails.length > 0 && (
          <div className="p-3 bg-green-50 border border-green-200 rounded-lg">
            <div className="flex items-start gap-2">
              <Route className="h-5 w-5 text-green-600 mt-0.5 flex-shrink-0" />
              <div className="space-y-2 flex-1">
                <div className="font-semibold text-green-900">My Hike Plan</div>
                <div className="text-sm text-green-700">
                  {(() => {
                    const uniqueTrailNames = [...new Set(selectedTrails.map(trailId => {
                      const trail = osmTrails.find(t => t.id === trailId) || npsTrails.find(t => t.id === trailId);
                      return trail?.name;
                    }).filter(Boolean))];
                    return `${uniqueTrailNames.length} trail${uniqueTrailNames.length > 1 ? 's' : ''} selected`;
                  })()}
                </div>
                <div className="space-y-1">
                  {(() => {
                    // Group by trail name and show only unique names
                    const trailGroups: { [name: string]: string[] } = {};
                    selectedTrails.forEach(trailId => {
                      const trail = osmTrails.find(t => t.id === trailId) || npsTrails.find(t => t.id === trailId);
                      if (trail) {
                        if (!trailGroups[trail.name]) {
                          trailGroups[trail.name] = [];
                        }
                        trailGroups[trail.name].push(trailId);
                      }
                    });

                    return Object.entries(trailGroups).map(([trailName, trailIds]) => (
                      <div key={trailName} className="flex items-center justify-between text-xs">
                        <span className="text-green-700">
                          {trailName}
                          {trailIds.length > 1 && (
                            <span className="text-green-500 ml-1">({trailIds.length} segments)</span>
                          )}
                        </span>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => handleTrailClick(trailIds[0])} // Click any segment to remove all
                          className="h-4 w-4 p-0 text-green-600 hover:text-red-600"
                        >
                          ×
                        </Button>
                      </div>
                    ));
                  })()}
                </div>
                <div className="flex justify-between items-center pt-2 border-t border-green-200">
                  <Button
                    size="sm"
                    variant="default"
                    onClick={() => setShowTripPlanning(!showTripPlanning)}
                    className="text-xs"
                  >
                    Plan My Trip
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={clearSelectedTrails}
                    className="text-xs"
                  >
                    Clear All
                  </Button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Trip Planning Panel */}
        {showTripPlanning && selectedTrails.length > 0 && (
          <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg">
            <div className="space-y-3">
              <div className="font-semibold text-blue-900">Trip Planning</div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-medium text-blue-700">Start Date</label>
                  <Input
                    type="date"
                    value={startDate}
                    onChange={(e) => setStartDate(e.target.value)}
                    className="text-xs h-8"
                  />
                </div>
                <div>
                  <label className="text-xs font-medium text-blue-700">Trip Duration</label>
                  <Select value={tripDays.toString()} onValueChange={(value) => setTripDays(parseInt(value))}>
                    <SelectTrigger className="text-xs h-8">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {[1,2,3,4,5,6,7,8,9,10,11,12,13,14].map(days => (
                        <SelectItem key={days} value={days.toString()}>
                          {days} day{days > 1 ? 's' : ''}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {startDate && (
                <div className="text-xs text-blue-600 bg-blue-100 p-2 rounded">
                  <div className="font-medium mb-1">Estimated Needs:</div>
                  <div>Trip: {startDate} to {new Date(new Date(startDate).getTime() + (tripDays - 1) * 24 * 60 * 60 * 1000).toISOString().split('T')[0]}</div>
                  <div>Temperature data will be used for calculations</div>
                  <div className="mt-2">
                    <Button 
                      size="sm" 
                      className="text-xs"
                      onClick={async () => {
                        try {
                          // Get weather data for the trip dates
                          const weather = await weatherService.getTemperatureForDateRange(startDate, tripDays, { units: preferences.units });
                          setWeatherData(weather);

                          // Collect all trail coordinates for weather analysis
                          const allTrailCoordinates: [number, number][] = [];
                          selectedTrails.forEach(trailId => {
                            const trail = osmTrails.find(t => t.id === trailId);
                            if (trail) {
                              allTrailCoordinates.push(...trail.coordinates);
                            }
                          });

                          // Get weather data along the trail
                          if (allTrailCoordinates.length > 0) {
                            // Sample points along the trail every mile
                            const samplePoints = [];
                            let totalDistance = 0;
                            const mileInterval = 1.60934; // 1 mile in km

                            samplePoints.push(allTrailCoordinates[0]); // Always include start point

                            for (let i = 1; i < allTrailCoordinates.length; i++) {
                              const prev = allTrailCoordinates[i - 1];
                              const curr = allTrailCoordinates[i];

                              // Calculate distance from previous point
                              const R = 6371;
                              const dLat = (curr[0] - prev[0]) * Math.PI / 180;
                              const dLng = (curr[1] - prev[1]) * Math.PI / 180;
                              const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
                                        Math.cos(prev[0] * Math.PI / 180) * Math.cos(curr[0] * Math.PI / 180) *
                                        Math.sin(dLng/2) * Math.sin(dLng/2);
                              const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
                              const segmentDistance = R * c;

                              totalDistance += segmentDistance;

                              // Add point if we've traveled at least a mile since last sample
                              if (totalDistance >= mileInterval * samplePoints.length) {
                                samplePoints.push(curr);
                              }
                            }

                            // Always include end point if different from last sample
                            const lastCoord = allTrailCoordinates[allTrailCoordinates.length - 1];
                            const lastSample = samplePoints[samplePoints.length - 1];
                            if (lastCoord[0] !== lastSample[0] || lastCoord[1] !== lastSample[1]) {
                              samplePoints.push(lastCoord);
                            }

                            const trailWeather = await weatherService.getWeatherAlongTrail(samplePoints, startDate, { units: preferences.units });
                            setTrailWeatherData(trailWeather);
                          }

                          // Calculate total distance from selected trails
                          const totalDistance = selectedTrails.reduce((acc, trailId) => {
                            const trail = osmTrails.find(t => t.id === trailId);
```text
if (trail) {
                              let trailDistance = 0;
                              for (let i = 1; i < trail.coordinates.length; i++) {
                                const prev = trail.coordinates[i - 1];
                                const curr = trail.coordinates[i];
                                const R = 6371;
                                const dLat = (curr[0] - prev[0]) * Math.PI / 180;
                                const dLng = (curr[1] - prev[1]) * Math.PI / 180;
                                const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
                                          Math.cos(prev[0] * Math.PI / 180) * Math.cos(curr[0] * Math.PI / 180) *
                                          Math.sin(dLng/2) * Math.sin(dLng/2);
                                const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
                                trailDistance += R * c;
                              }
                              return acc + trailDistance;
                            }
                            return acc;
                          }, 0);

                          const dailyDistance = totalDistance / tripDays;
                          const estimatedElevationGain = totalDistance * 150; // Rough estimate: 150m per km

                          // Get water sources for selected trails
                          const relevantWaterSources = await Promise.all(
                            [...new Set(selectedTrails.map(trailId => {
                              const trail = osmTrails.find(t => t.id === trailId);
                              return trail?.name;
                            }))].map(async trailName => {
                              if (trailName) {
                                return await waterSourcesAPI.getWaterSourcesForTrail(trailName);
                              }
                              return [];
                            })
                          );
                          const allWaterSources = relevantWaterSources.flat();

                          // Calculate water needs using authentic weather data
                          const waterCalc = HydrationCalculator.calculate({
                            distance: dailyDistance,
                            temperature: weather.avgDaily,
                            temperatureUnit: 'C',
                            humidity: weather.humidity,
                            elevationGain: estimatedElevationGain / tripDays
                          });

                          // Add water source analysis
                          const waterAdvice = waterSourcesAPI.getWaterAvailabilityAdvice(new Date(startDate).getMonth() + 1);
                          const trailNames = [...new Set(selectedTrails.map(trailId => {
                            const trail = osmTrails.find(t => t.id === trailId);
                            return trail?.name;
                          }).filter(Boolean))];
                          const season = new Date(startDate).getMonth() >= 5 && new Date(startDate).getMonth() <= 9 ? 'summer' : 
                                       new Date(startDate).getMonth() >= 3 && new Date(startDate).getMonth() <= 5 ? 'spring' : 
                                       new Date(startDate).getMonth() >= 9 && new Date(startDate).getMonth() <= 11 ? 'fall' : 'winter';
                          const carryRecommendations = trailNames.map(trailName => 
                            waterSourcesAPI.getWaterCarryRecommendation(trailName, season)
                          );

                          // Calculate food needs
                          const foodCalc = MealCalculator.calculateCalories({
                            dailyDistance: dailyDistance,
                            elevationGain: estimatedElevationGain / tripDays,
                            bodyWeight: 70, // Default 70kg
                            totalDays: tripDays
                          });

                          const mealPlan = MealCalculator.generateMealPlan(
                            foodCalc.dailyCalories,
                            tripDays,
                            []
                          );

                          setTripCalculations({
                            water: { 
                              ...waterCalc, 
                              totalForTrip: waterCalc.liters * tripDays,
                              waterSources: allWaterSources,
                              waterAdvice,
                              carryRecommendations
                            },
                            food: { ...foodCalc, mealPlan },
                            distance: totalDistance,
                            elevation: estimatedElevationGain
                          });

                          // Pass to parent for integration with main calculators
                          onRouteChange?.(totalDistance, estimatedElevationGain);
                        } catch (error) {
                          console.error('Trip calculation error:', error);
                        }
                      }}
                    >
                      Calculate Trip Needs
                    </Button>
                  </div>
                </div>
              )}
              <div className="flex items-center space-x-2">
                <label className="text-xs font-medium text-blue-700">Units:</label>
                <Select
                  value={preferences.units}
                  onValueChange={(value) => updatePreferences({ units: value })}
                >
                  <SelectTrigger className="text-xs h-8">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="metric">Metric</SelectItem>
                    <SelectItem value="imperial">Imperial</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>
        )}

        {/* Trip Calculations Results */}
        {tripCalculations && weatherData && (
          <div className="p-3 bg-amber-50 border border-amber-200 rounded-lg">
            <div className="space-y-3">
              <div className="font-semibold text-amber-900">Trip Resource Plan</div>

              <div className="grid grid-cols-2 gap-3 text-xs">
                <div className="bg-blue-100 p-2 rounded">
                  <div className="font-medium text-blue-800">Water Needs</div>
                  <div className="text-blue-700">Daily: {tripCalculations.water.liters.toFixed(1)}L</div>
                  <div className="text-blue-700">Total Trip: {tripCalculations.water.totalForTrip.toFixed(1)}L</div>
                  <div className="text-blue-600 text-xs mt-1">
                    Based on {weatherData.avgDaily.toFixed(1)}°{weatherData.unit || 'C'} avg temp
                  </div>
                </div>

                <div className="bg-green-100 p-2 rounded">
                  <div className="font-medium text-green-800">Food Needs</div>
                  <div className="text-green-700">Daily: {tripCalculations.food.dailyCalories} cal</div>
                  <div className="text-green-700">Total: {tripCalculations.food.totalCalories} cal</div>
                  <div className="text-green-600 text-xs mt-1">
                    {tripCalculations.food.mealPlan?.days?.length || 0} days planned
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 gap-2">
                <div className="bg-amber-100 p-2 rounded text-xs">
                  <div className="font-medium text-amber-800 mb-1">Weather Analysis</div>
                  <div className="text-amber-700">
                    Overall Avg: {weatherData.avgDaily.toFixed(1)}°{weatherData.unit || 'C'}
                  </div>
                  <div className="text-amber-700">
                    Range: {weatherData.avgMin.toFixed(1)}°{weatherData.unit || 'C'} to {weatherData.avgMax.toFixed(1)}°{weatherData.unit || 'C'}
                  </div>
                  {trailWeatherData.length > 0 && (
                    <div className="text-amber-700 mt-1">
                      Trail conditions: {Math.min(...trailWeatherData.map(w => w.temperature.min)).toFixed(1)}° to {Math.max(...trailWeatherData.map(w => w.temperature.max)).toFixed(1)}°{trailWeatherData[0]?.temperatureUnit || 'C'}
                    </div>
                  )}
                  <div className="text-amber-700">Humidity: {weatherData.humidity}</div>
                  {trailWeatherData.length > 0 && (
                    <div className="text-amber-600 mt-1">
                      Weather data collected from {trailWeatherData.length} points along your route
                    </div>
                  )}
                  <div className="text-amber-600 mt-1">
                    {weatherService.getSeasonalAdvice(new Date(startDate).getMonth() + 1)}
                  </div>
                </div>

                {tripCalculations.water.waterSources && tripCalculations.water.waterSources.length > 0 && (
                  <div className="bg-blue-100 p-2 rounded text-xs">
                    <div className="font-medium text-blue-800 mb-1">Water Sources Analysis</div>
                    <div className="text-blue-700 mb-1">
                      {tripCalculations.water.waterSources.length} water sources found on your route
                    </div>
                    <div className="space-y-1">
                      {tripCalculations.water.waterSources.slice(0, 3).map((source: any) => (
                        <div key={source.id} className="text-blue-600">
                          • {source.name} ({source.availability.replace('_', ' ')})
                        </div>
                      ))}
                      {tripCalculations.water.waterSources.length > 3 && (
                        <div className="text-blue-600">• + {tripCalculations.water.waterSources.length - 3} more sources</div>
                      )}
                    </div>
                    <div className="text-blue-600 mt-1 font-medium">
                      {tripCalculations.water.waterAdvice}
                    </div>
                    {tripCalculations.water.carryRecommendations && tripCalculations.water.carryRecommendations.length > 0 && (
                      <div className="bg-blue-200 p-1 rounded mt-1">
                        <div className="font-medium text-blue-800">Water Carry Tips:</div>
                        {tripCalculations.water.carryRecommendations.map((rec: string, index: number) => (
                          <div key={index} className="text-blue-700 text-xs">• {rec}</div>
                        ))}
                      </div>
                    )}
                  </div>
                )}
              </div>

              <div className="text-xs text-amber-600">
                <div className="font-medium">Route Summary:</div>
                <div>Distance: {tripCalculations.distance.toFixed(1)}km over {tripDays} days</div>
                <div>Daily avg: {(tripCalculations.distance / tripDays).toFixed(1)}km</div>
                <div>Est. elevation gain: {tripCalculations.elevation.toFixed(0)}m</div>
              </div>
            </div>
          </div>
        )}

        {/* Map Controls and Quick Add Buttons */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h4 className="text-sm font-medium">Map Layers</h4>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setShowWaterSources(!showWaterSources)}
              className={`text-xs ${showWaterSources ? 'bg-blue-50 border-blue-200' : ''}`}
            >
              <Droplets className="h-4 w-4 mr-1" />
              Water Sources
            </Button>
          </div>

          <div className="flex flex-wrap gap-2">
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => {
                if (routePoints.length === 0) {
                  addRoutePoint(center[0], center[1], 'start');
                } else {
                  const lastPoint = routePoints[routePoints.length - 1];
                  addRoutePoint(lastPoint.lat + 0.01, lastPoint.lng + 0.01, 'waypoint');
                }
              }}
              disabled={!!selectedTrail}
            >
              <Plus className="h-4 w-4 mr-1" />
              Add Point
            </Button>
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => {
                if (routePoints.length > 0) {
                  const lastPoint = routePoints[routePoints.length - 1];
                  addRoutePoint(lastPoint.lat + 0.005, lastPoint.lng + 0.005, 'water');
                }
              }}
              disabled={!!selectedTrail}
            >
              <Droplets className="h-4 w-4 mr-1" />
              Add Water
            </Button>
            <Button 
              variant="outline" 
              size="sm"
              onClick={clearRoute}
              disabled={routePoints.length === 0}
            >
              <Trash2 className="h-4 w-4 mr-1" />
              Clear
            </Button>
          </div>
        </div>

        {/* Map */}
        <div className="relative">
          {isExpanded && (
            <div 
              className="fixed inset-0 bg-black/50 z-40" 
              onClick={(e) => {
                e.stopPropagation();
                setIsExpanded(false);
              }} 
            />
          )}
          <div className={`${isExpanded ? 'fixed inset-4 z-50 bg-background shadow-2xl flex flex-col' : 'relative h-96'} rounded-lg overflow-hidden border`}>
            <div className="flex items-center justify-between p-2 bg-background border-b flex-shrink-0">
              <h3 className="font-medium text-sm">Grand Canyon Trail Map</h3>
              <Button
                variant="ghost"
                size="sm"
                onClick={(e) => {
                  e.stopPropagation();
                  setIsExpanded(!isExpanded);
                }}
              >
                {isExpanded ? <Minimize2 className="h-4 w-4" /> : <Maximize2 className="h-4 w-4" />}
              </Button>
            </div>
            <div className={`${isExpanded ? 'flex-1' : 'h-full'}`}>
              <MapContainer
                center={mapCenter}
                zoom={mapZoom}
                style={{ 
                  height: isExpanded ? '100%' : '384px', 
                  width: '100%',
                  minHeight: isExpanded ? 'calc(100vh - 160px)' : '384px'
                }}
                key={`map-expanded-${isExpanded}`}
              >
                <MapEventHandler 
                  onMapMove={(center, zoom) => {
                    setMapCenter(center);
                    setMapZoom(zoom);
                  }}
                  onMapReady={(map) => {
                    setMapInstance(map);
                  }}
                  isExpanded={isExpanded}
                />
                <MapClickHandler 
                  onMapClick={(lat, lng) => {
                    const pointType = routePoints.length === 0 ? 'start' : 'waypoint';
                    addRoutePoint(lat, lng, pointType);
                  }}
                />
                <TileLayer
                  attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
                  url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                />

                {/* Authentic Trail Overlays from OpenStreetMap */}
                {osmTrails.map((trail) => (
                  <Polyline
                    key={`osm-trail-${trail.id}`}
                    positions={getOSMTrailPath(trail)}
                    color={selectedTrails.includes(trail.id) ? '#ef4444' : '#3b82f6'}
                    weight={selectedTrails.includes(trail.id) ? 6 : 4}
                    opacity={selectedTrails.includes(trail.id) ? 0.9 : 0.6}
                    eventHandlers={{
                      click: () => handleTrailClick(trail.id)
                    }}
                  >
                    <Popup>
                      <div className="text-sm space-y-2">
                        <div className="font-semibold text-blue-900">{trail.name}</div>
                        <div className="text-xs text-blue-700">Authentic trail data from OpenStreetMap</div>
                        <div className="flex flex-wrap gap-2 text-xs">
                          <Badge variant="outline">OSM Verified</Badge>
                          <Badge variant="outline">{trail.coordinates.length} GPS points</Badge>
                        </div>
                        <Button 
                          size="sm" 
                          onClick={() => handleTrailClick(trail.id)}
                          className="w-full text-xs"
                          variant={selectedTrails.includes(trail.id) ? "destructive" : "default"}
                        >
                          {selectedTrails.includes(trail.id) ? 'Remove from My Hike' : 'Add to My Hike'}
                        </Button>
                      </div>
                    </Popup>
                  </Polyline>
                ))}

                {/* Weather Data Points along Trail */}
                {trailWeatherData.map((weatherPoint, index) => (
                  <Marker
                    key={`weather-${index}`}
                    position={[weatherPoint.position[0], weatherPoint.position[1]]}
                    icon={L.divIcon({
                      html: `<div style="background: ${
                        preferences.units === 'imperial' 
                          ? (weatherPoint.temperature.avg > 77 ? '#ef4444' : weatherPoint.temperature.avg > 59 ? '#f59e0b' : '#3b82f6')
                          : (weatherPoint.temperature.avg > 25 ? '#ef4444' : weatherPoint.temperature.avg > 15 ? '#f59e0b' : '#3b82f6')
                      }; border-radius: 50%; width: 20px; height: 20px; display: flex; align-items: center; justify-content: center; color: white; font-weight: bold; border: 2px solid white; box-shadow: 0 2px 4px rgba(0,0,0,0.3); font-size: 10px;">${Math.round(weatherPoint.temperature.avg)}°</div>`,
                      className: 'weather-marker',
                      iconSize: [20, 20],
                      iconAnchor: [10, 10]
                    })}
                  >
                    <Popup>
                      <div className="text-sm space-y-2">
                        <div className="font-semibold">Weather Conditions</div>
                        <div className="text-xs space-y-1">
                          <div>Elevation: {Math.round(weatherPoint.elevation)}{weatherPoint.elevationUnit || 'm'}</div>
                          <div>Temperature: {Math.round(weatherPoint.temperature.min)}° to {Math.round(weatherPoint.temperature.max)}°{weatherPoint.temperatureUnit || 'C'}</div>
                          <div>Avg: {Math.round(weatherPoint.temperature.avg)}°{weatherPoint.temperatureUnit || 'C'}</div>
                          <div>Humidity: {weatherPoint.humidity}</div>
                          <div>Wind: {weatherPoint.windExposure} exposure</div>
                          <div>Conditions: {weatherPoint.conditions}</div>
                          <div>Distance: {weatherPoint.distanceFromStart.toFixed(1)}km from start</div>
                        </div>
                      </div>
                    </Popup>
                  </Marker>
                ))}

                {/* Water Sources */}
                {showWaterSources && waterSources.map((waterSource) => (
                  <Marker
                    key={`water-${waterSource.id}`}
                    position={[waterSource.latitude, waterSource.longitude]}
                    icon={getWaterSourceIcon(waterSource)}
                  >
                    <Popup>
                      <div className="text-sm space-y-2 max-w-xs">
                        <div className="font-semibold text-blue-900">{waterSource.name}</div>
                        <div className="flex flex-wrap gap-1">
                          <Badge 
                            variant={waterSource.availability === 'year_round' ? 'default' : 
                                   waterSource.availability === 'seasonal' ? 'secondary' : 'destructive'}
                            className="text-xs"
                          >
                            {waterSource.availability.replace('_', ' ')}
                          </Badge>
                          <Badge variant="outline" className="text-xs">
                            {waterSource.type.replace('_', ' ')}
                          </Badge>
                        </div>
                        <div className="text-xs text-gray-700 space-y-1">
                          <div><strong>Trail:</strong> {waterSource.trailName}</div>
                          <div><strong>Description:</strong> {waterSource.description}</div>
                          {waterSource.seasonalDates && (
                            <div><strong>Season:</strong> {waterSource.seasonalDates}</div>
                          )}
                          {waterSource.notes && (
                            <div className="p-2 bg-amber-50 border border-amber-200 rounded text-xs">
                              <strong>Important:</strong> {waterSource.notes}
                            </div>
                          )}
                        </div>
                        <div className="text-xs text-muted-foreground">
                          {waterSource.latitude.toFixed(4)}, {waterSource.longitude.toFixed(4)}
                        </div>
                      </div>
                    </Popup>
                  </Marker>
                ))}



                {/* Custom user route points (only when not using official trail) */}
                {!highlightedTrail && routePoints.map((point, index) => (
                  <Marker
                    key={`route-${index}`}
                    position={[point.lat, point.lng]}
                    icon={getMarkerIcon(point.type)}
                    draggable={point.draggable}
                    eventHandlers={{
                      dragend: (e) => {
                        const marker = e.target;
                        const position = marker.getLatLng();
                        updateRoutePoint(index, { lat: position.lat, lng: position.lng });
                      }
                    }}
                  >
                    <Popup>
                      <div className="text-sm space-y-2">
                        {point.isEditing ? (
                          <div className="flex items-center gap-1">
                            <Input
                              value={point.name}
                              onChange={(e) => updateRoutePoint(index, { name: e.target.value })}
                              className="text-xs h-6"
                            />
                            <Button
                              size="sm"
                              variant="ghost"
                              onClick={() => updateRoutePoint(index, { isEditing: false })}
                              className="h-6 w-6 p-0"
                            >
                              <Check className="h-3 w-3" />
                            </Button>
                          </div>
                        ) : (
                          <div className="flex items-center justify-between gap-2">
                            <div className="font-semibold">{point.name}</div>
                            <Button
                              size="sm"
                              variant="ghost"
                              onClick={() => updateRoutePoint(index, { isEditing: true })}
                              className="h-6 w-6 p-0"
                            >
                              <Edit2 className="h-3 w-3" />
                            </Button>
                          </div>
                        )}
                        <div className="flex items-center justify-between">
                          <Badge variant="secondary" className="text-xs">
                            {point.type}
                          </Badge>
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => deleteRoutePoint(index)}
                            className="h-6 w-6 p-0 text-destructive"
                          >
                            <Trash2 className="h-3 w-3" />
                          </Button>
                        </div>
                        <div className="text-xs text-muted-foreground">
                          {point.lat.toFixed(4)}, {point.lng.toFixed(4)}
                        </div>
                      </div>
                    </Popup>
                  </Marker>
                ))}

                {/* Route line */}
                {routePoints.length > 1 && (
                  <Polyline
                    positions={routePoints.map(point => [point.lat, point.lng])}
                    color="#3b82f6"
                    weight={4}
                    opacity={0.7}
                  />
                )}
              </MapContainer>
            </div>
          </div>
        </div>

        {/* Water Sources Legend */}
        {showWaterSources && (
          <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg">
            <div className="text-sm font-medium text-blue-900 mb-2">Water Sources Legend</div>
            <div className="space-y-2 text-xs">
              <div className="grid grid-cols-2 gap-2">
                <div className="flex items-center gap-1">
                  <div className="w-5 h-5 rounded-full bg-green-500 border-2 border-white flex items-center justify-center text-xs">💧</div>
                  <span className="text-blue-700">Year Round</span>
                </div>
                <div className="flex items-center gap-1">
                  <div className="w-5 h-5 rounded-full bg-amber-500 border-2 border-white flex items-center justify-center text-xs">🌊</div>
                  <span className="text-blue-700">Seasonal</span>
                </div>
                <div className="flex items-center gap-1">
                  <div className="w-5 h-5 rounded-full bg-blue-500 border-2 border-white flex items-center justify-center text-xs">🚰</div>
                  <span className="text-blue-700">Trailhead</span>
                </div>
                <div className="flex items-center gap-1">
                  <div className="w-5 h-5 rounded-full bg-red-500 border-2 border-white flex items-center justify-center text-xs">🆘</div>
                  <span className="text-blue-700">Emergency Only</span>
                </div>
              </div>
              <div className="text-blue-600 bg-blue-100 p-2 rounded text-xs">
                <strong>Important:</strong> Always verify water availability before hiking. Seasonal sources may be turned off without notice.
              </div>
            </div>
          </div>
        )}

        {/* Weather Legend */}
        {trailWeatherData.length > 0 && (
          <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg">
            <div className="text-sm font-medium text-blue-900 mb-2">Weather Data Legend</div>
            <div className="flex items-center gap-4 text-xs">
              <div className="flex items-center gap-1">
                <div className="w-4 h-4 rounded-full bg-blue-500 border-2 border-white flex items-center justify-content text-white text-xs font-bold">C</div>
                <span className="text-blue-700">Cool ({preferences.units === 'imperial' ? '<59°F' : '<15°C'})</span>
              </div>
              <div className="flex items-center gap-1">
                <div className="w-4 h-4 rounded-full bg-amber-500 border-2 border-white flex items-center justify-content text-white text-xs font-bold">M</div>
                <span className="text-blue-700">Mild ({preferences.units === 'imperial' ? '59-77°F' : '15-25°C'})</span>
              </div>
              <div className="flex items-center gap-1">
                <div className="w-4 h-4 rounded-full bg-red-500 border-2 border-white flex items-center justify-content text-white text-xs font-bold">H</div>
                <span className="text-blue-700">Hot ({preferences.units === 'imperial' ? '>77°F' : '>25°C'})</span>
              </div>
            </div>
            <div className="text-xs text-blue-600 mt-1">
              Click weather markers for detailed conditions at each point
            </div>
          </div>
        )}

        {/* Route Summary */}
        {(selectedTrails.length > 0 || routePoints.length > 0) && (
          <div className="p-3 bg-muted rounded-lg">
            <div className="text-sm font-medium mb-1">
              {selectedTrails.length > 0 ? `My Hike Summary (${selectedTrails.length} trails)` : 
               highlightedTrail ? 'Official Trail Route' : 'Custom Route Summary'}
            </div>
            <div className="text-xs text-muted-foreground space-y-1">
              {selectedTrails.length > 0 ? (
                <div className="space-y-1">
                  <div>Multi-trail combination selected</div>
                  <div className="text-green-600">Total distance and elevation calculated above</div>
                  <div>Use water and meal calculators with combined totals</div>
                  {trailWeatherData.length > 0 && (
                    <div className="text-blue-600">Weather data collected from {trailWeatherData.length} points along route</div>
                  )}
                </div>
              ) : routePoints.length > 0 ? (
                <div>{routePoints.length} waypoints • Click map to add points • Drag markers to adjust</div>
              ) : highlightedTrail ? (
                <div className="space-y-1">
                  <div>Distance: {highlightedTrail.length}</div>
                  <div>Elevation Change: {highlightedTrail.elevationGain}</div>
                  <div>Difficulty: {highlightedTrail.difficulty}</div>
                  <div className="text-blue-600">Official NPS trail data</div>
                </div>
              ) : null}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}