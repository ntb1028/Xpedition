import { Droplets, Milk, Package, AlertTriangle } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import type { CalculationResult } from "@/lib/hydration-calculator";

interface ResultsDisplayProps {
  result: CalculationResult | null;
}

export function ResultsDisplay({ result }: ResultsDisplayProps) {
  if (!result) return null;

  return (
    <Card>
      <CardContent className="p-6">
        <div className="text-center">
          <div className="mb-4">
            <Droplets className="h-10 w-10 text-primary mx-auto mb-2" />
            <h2 className="text-lg font-semibold">Water Recommendation</h2>
          </div>
          
          {/* Main Result */}
          <div className="bg-primary/5 rounded-lg p-6 mb-4">
            <div className="text-4xl font-bold text-primary mb-2">
              {result.liters}
            </div>
            <div className="text-lg text-muted-foreground mb-1">liters</div>
            <div className="text-2xl font-semibold mb-0">
              {result.ounces}
            </div>
            <div className="text-sm text-muted-foreground">fluid ounces</div>
          </div>

          {/* Container Suggestions */}
          <div className="border-t pt-4">
            <h3 className="font-medium mb-3">Suggested Containers</h3>
            <div className="space-y-2 text-sm">
              {result.containers.map((container, index) => (
                <div
                  key={index}
                  className="flex items-center justify-between bg-muted/50 rounded-lg p-3"
                >
                  <div className="flex items-center space-x-2">
                    {container.icon === 'bottle-water' ? (
                      <Milk className="h-4 w-4 text-primary" />
                    ) : (
                      <Package className="h-4 w-4 text-primary" />
                    )}
                    <span>{container.type}</span>
                  </div>
                  <span className="text-muted-foreground">
                    {container.volume}L
                  </span>
                </div>
              ))}
            </div>
            <div className="mt-3 text-xs text-muted-foreground">
              Total carry capacity: {result.liters}L
            </div>
          </div>

          {/* Warning for High Volume */}
          {result.isHighVolume && (
            <Alert className="mt-4 bg-orange-50 border-orange-200">
              <AlertTriangle className="h-4 w-4 text-orange-600" />
              <AlertDescription className="text-orange-700 text-xs">
                <strong>High water volume:</strong> Consider planning refill stops or water caches along your route.
              </AlertDescription>
            </Alert>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
