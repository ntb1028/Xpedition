import { formatDistanceToNow } from "date-fns";
import { Trash2, Download } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useCalculations } from "@/hooks/use-calculations";
import { useToast } from "@/hooks/use-toast";

export function TripHistory() {
  const { recentCalculations, deleteCalculation, exportCalculations } = useCalculations();
  const { toast } = useToast();

  const handleExport = () => {
    try {
      const data = exportCalculations();
      const blob = new Blob([data], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `hydration-calculations-${new Date().toISOString().split('T')[0]}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      
      toast({
        title: "Export Complete",
        description: "Your calculations have been exported successfully.",
      });
    } catch (error) {
      toast({
        title: "Export Failed",
        description: "Failed to export calculations.",
        variant: "destructive",
      });
    }
  };

  const handleDelete = (id: string, name: string) => {
    deleteCalculation(id);
    toast({
      title: "Calculation Deleted",
      description: `"${name}" has been removed from your history.`,
    });
  };

  if (recentCalculations.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Recent Calculations</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-6">
            <p className="text-muted-foreground text-sm">
              No calculations yet. Calculate your water needs to see them here.
            </p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
        <CardTitle className="text-lg">Recent Calculations</CardTitle>
        <Button
          variant="ghost"
          size="sm"
          onClick={handleExport}
          className="text-primary hover:text-primary/80"
        >
          <Download className="h-4 w-4 mr-1" />
          Export
        </Button>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {recentCalculations.map((calc) => (
            <div
              key={calc.id}
              className="flex items-center justify-between py-3 border-b last:border-0"
            >
              <div className="flex-1">
                <div className="font-medium text-sm">
                  {calc.name || 'Untitled Calculation'}
                </div>
                <div className="text-xs text-muted-foreground">
                  {calc.distance && `${calc.distance} ${calc.isMetric ? 'km' : 'mi'}`}
                  {calc.duration && !calc.distance && `${calc.duration} hrs`}
                  {calc.distance && calc.duration && ' • '}
                  {calc.duration && calc.distance && `${calc.duration} hrs`}
                  • {calc.temperature}°{calc.temperatureUnit}
                  • {calc.resultLiters}L needed
                </div>
              </div>
              <div className="flex items-center space-x-2">
                <div className="text-right">
                  <div className="text-sm font-medium text-primary">
                    {calc.resultLiters}L
                  </div>
                  <div className="text-xs text-muted-foreground">
                    {formatDistanceToNow(new Date(calc.createdAt), { addSuffix: true })}
                  </div>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => handleDelete(calc.id, calc.name || 'Untitled')}
                  className="text-muted-foreground hover:text-destructive"
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
