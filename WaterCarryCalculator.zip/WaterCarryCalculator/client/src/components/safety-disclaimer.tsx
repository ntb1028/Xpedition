import { AlertTriangle } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";

export function SafetyDisclaimer() {
  return (
    <Alert className="bg-amber-50 border-amber-200 text-amber-800">
      <AlertTriangle className="h-4 w-4 text-amber-600" />
      <AlertDescription className="text-sm">
        <strong>Safety Notice:</strong> This tool provides guidance only. Always consider conditions, personal needs, and local expertise for final hydration decisions.
      </AlertDescription>
    </Alert>
  );
}
