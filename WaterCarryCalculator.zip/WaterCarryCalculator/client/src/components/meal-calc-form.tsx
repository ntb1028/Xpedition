import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Calculator, Users } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Checkbox } from "@/components/ui/checkbox";
import { MealCalculator, type MealCalculationParams } from "@/lib/meal-calculator";
import { usePreferences } from "@/hooks/use-preferences";
import { useToast } from "@/hooks/use-toast";

const mealCalcSchema = z.object({
  dailyDistance: z.string().min(1, "Daily distance is required"),
  elevationGain: z.string().optional(),
  bodyWeight: z.string().min(1, "Body weight is required"),
  packWeight: z.string().optional(),
  totalDays: z.string().min(1, "Number of days is required"),
});

type MealCalcForm = z.infer<typeof mealCalcSchema>;

const dietaryOptions = [
  { id: 'vegan', label: 'Vegan' },
  { id: 'vegetarian', label: 'Vegetarian' },
  { id: 'gluten-free', label: 'Gluten-Free' },
  { id: 'nut-free', label: 'Nut-Free' },
  { id: 'dairy-free', label: 'Dairy-Free' },
];

interface MealCalcFormProps {
  onResult: (result: any) => void;
}

export function MealCalcForm({ onResult }: MealCalcFormProps) {
  const [isCalculating, setIsCalculating] = useState(false);
  const [dietaryRestrictions, setDietaryRestrictions] = useState<string[]>([]);
  const { preferences } = usePreferences();
  const { toast } = useToast();

  const form = useForm<MealCalcForm>({
    resolver: zodResolver(mealCalcSchema),
    defaultValues: {
      dailyDistance: "",
      elevationGain: "",
      bodyWeight: "",
      packWeight: "",
      totalDays: "3",
    },
  });

  const onSubmit = async (data: MealCalcForm) => {
    setIsCalculating(true);
    
    try {
      const params: MealCalculationParams = {
        dailyDistance: parseFloat(data.dailyDistance),
        elevationGain: data.elevationGain ? parseFloat(data.elevationGain) : undefined,
        bodyWeight: parseFloat(data.bodyWeight),
        packWeight: data.packWeight ? parseFloat(data.packWeight) : undefined,
        totalDays: parseInt(data.totalDays),
        isMetric: preferences.units === 'metric'
      };

      // Validate inputs
      if (params.bodyWeight <= 0) {
        toast({
          title: "Invalid Weight",
          description: "Please enter a valid body weight",
          variant: "destructive",
        });
        return;
      }

      if (params.dailyDistance <= 0) {
        toast({
          title: "Invalid Distance",
          description: "Please enter a valid daily distance",
          variant: "destructive",
        });
        return;
      }

      const calorieResult = MealCalculator.calculateCalories(params);
      const mealPlan = MealCalculator.generateMealPlan(
        calorieResult.dailyCalories,
        params.totalDays,
        dietaryRestrictions
      );

      const result = {
        ...calorieResult,
        mealPlan,
        params,
        dietaryRestrictions
      };

      onResult(result);
      
      toast({
        title: "Meal Plan Ready",
        description: `${calorieResult.dailyCalories} calories/day planned for ${params.totalDays} days`,
      });

    } catch (error) {
      toast({
        title: "Calculation Error",
        description: error instanceof Error ? error.message : "Failed to calculate meal plan",
        variant: "destructive",
      });
    } finally {
      setIsCalculating(false);
    }
  };

  const handleDietaryChange = (dietId: string, checked: boolean) => {
    setDietaryRestrictions(prev => 
      checked 
        ? [...prev, dietId]
        : prev.filter(id => id !== dietId)
    );
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg flex items-center space-x-2">
          <Users className="h-5 w-5" />
          <span>Meal Planning Calculator</span>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            
            {/* Daily Distance */}
            <FormField
              control={form.control}
              name="dailyDistance"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Daily Distance</FormLabel>
                  <FormControl>
                    <div className="relative">
                      <Input
                        {...field}
                        type="number"
                        placeholder="15"
                        step="0.1"
                        className="text-lg font-medium pr-12"
                      />
                      <span className="absolute right-3 top-3 text-sm text-muted-foreground">
                        {preferences.units === 'metric' ? 'km' : 'mi'}
                      </span>
                    </div>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Body Weight & Pack Weight */}
            <div className="grid grid-cols-2 gap-3">
              <FormField
                control={form.control}
                name="bodyWeight"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Body Weight</FormLabel>
                    <FormControl>
                      <div className="relative">
                        <Input
                          {...field}
                          type="number"
                          placeholder={preferences.units === 'metric' ? "70" : "155"}
                          step="0.1"
                          className="pr-12"
                        />
                        <span className="absolute right-3 top-3 text-sm text-muted-foreground">
                          {preferences.units === 'metric' ? 'kg' : 'lbs'}
                        </span>
                      </div>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="packWeight"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Pack Weight (optional)</FormLabel>
                    <FormControl>
                      <div className="relative">
                        <Input
                          {...field}
                          type="number"
                          placeholder={preferences.units === 'metric' ? "15" : "35"}
                          step="0.1"
                          className="pr-12"
                        />
                        <span className="absolute right-3 top-3 text-sm text-muted-foreground">
                          {preferences.units === 'metric' ? 'kg' : 'lbs'}
                        </span>
                      </div>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            {/* Elevation Gain & Days */}
            <div className="grid grid-cols-2 gap-3">
              <FormField
                control={form.control}
                name="elevationGain"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Elevation Gain (optional)</FormLabel>
                    <FormControl>
                      <div className="relative">
                        <Input
                          {...field}
                          type="number"
                          placeholder={preferences.units === 'metric' ? "800" : "2500"}
                          step={preferences.units === 'metric' ? "10" : "50"}
                          className="pr-12"
                        />
                        <span className="absolute right-3 top-3 text-sm text-muted-foreground">
                          {preferences.units === 'metric' ? 'm' : 'ft'}
                        </span>
                      </div>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="totalDays"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Number of Days</FormLabel>
                    <FormControl>
                      <Input
                        {...field}
                        type="number"
                        placeholder="3"
                        min="1"
                        max="14"
                        className="text-lg font-medium"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            {/* Dietary Restrictions */}
            <div>
              <Label className="text-sm font-medium mb-3 block">Dietary Preferences</Label>
              <div className="grid grid-cols-2 gap-2">
                {dietaryOptions.map((option) => (
                  <div key={option.id} className="flex items-center space-x-2">
                    <Checkbox
                      id={option.id}
                      checked={dietaryRestrictions.includes(option.id)}
                      onCheckedChange={(checked) => 
                        handleDietaryChange(option.id, checked as boolean)
                      }
                    />
                    <Label htmlFor={option.id} className="text-sm">
                      {option.label}
                    </Label>
                  </div>
                ))}
              </div>
            </div>

            <Button
              type="submit"
              className="w-full py-4 text-lg font-semibold"
              disabled={isCalculating}
            >
              <Calculator className="mr-2 h-5 w-5" />
              {isCalculating ? "Calculating..." : "Generate Meal Plan"}
            </Button>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}