import React, { useState, useEffect, useCallback } from 'react';
import { MapContainer, TileLayer, Marker, Popup, Polyline, useMapEvents } from 'react-leaflet';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Mountain, Maximize2, Minimize2, MapPin, Droplets, Calculator } from 'lucide-react';
import { npsApi, NPSTrail, NPSWaypoint } from '@/lib/nps-api';
import { overpassAPI, OSMTrail } from '@/lib/overpass-api';
import { weatherService, TemperatureAverages } from '@/lib/weather-api';
import { WaterSource, waterSourcesAPI } from '@/lib/water-sources-api';
import { HydrationCalculator } from '@/lib/hydration-calculator';
import { MealCalculator } from '@/lib/meal-calculator';
import { usePreferences } from '@/hooks/use-preferences';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';

// Fix for default markers not showing
delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
});

interface RoutePoint {
  lat: number;
  lng: number;
  name: string;
  type: 'start' | 'end' | 'waypoint' | 'water' | 'camp' | 'trailhead' | 'viewpoint';
  elevation?: number;
  draggable?: boolean;
  isEditing?: boolean;
}

interface RouteMapProps {
  onRouteChange?: (distance: number, elevationGain: number) => void;
}

function MapClickHandler({ onMapClick }: { onMapClick: (lat: number, lng: number) => void }) {
  useMapEvents({
    click: (e) => {
      onMapClick(e.latlng.lat, e.latlng.lng);
    },
  });
  return null;
}

function MapEventHandler({ onMapMove, onMapReady, isExpanded }: { 
  onMapMove?: (center: [number, number], zoom: number) => void;
  onMapReady?: (map: any) => void;
  isExpanded: boolean;
}) {
  const map = useMapEvents({
    moveend: () => {
      onMapMove?.([map.getCenter().lat, map.getCenter().lng], map.getZoom());
    },
    zoomend: () => {
      onMapMove?.([map.getCenter().lat, map.getCenter().lng], map.getZoom());
    }
  });

  useEffect(() => {
    if (map && onMapReady) {
      onMapReady(map);
    }
  }, [map, onMapReady]);

  useEffect(() => {
    if (map) {
      setTimeout(() => {
        map.invalidateSize();
      }, 100);
    }
  }, [isExpanded, map]);

  return null;
}

export function RouteMapFixed({ onRouteChange }: RouteMapProps) {
  const { preferences, updatePreferences } = usePreferences();
  const [routePoints, setRoutePoints] = useState<RoutePoint[]>([]);
  const [isExpanded, setIsExpanded] = useState(false);
  const [npsTrails, setNpsTrails] = useState<NPSTrail[]>([]);
  const [osmTrails, setOsmTrails] = useState<OSMTrail[]>([]);
  const [selectedTrails, setSelectedTrails] = useState<string[]>([]);
  const [isLoadingTrails, setIsLoadingTrails] = useState(false);
  const [tripDays, setTripDays] = useState<number>(1);
  const [startDate, setStartDate] = useState<string>('');
  const [showTripPlanning, setShowTripPlanning] = useState(false);
  const [weatherData, setWeatherData] = useState<TemperatureAverages | null>(null);
  const [tripCalculations, setTripCalculations] = useState<{
    water: any;
    food: any;
    distance: number;
    elevation: number;
  } | null>(null);
  const [showAdvancedOptions, setShowAdvancedOptions] = useState(false);
  const [bodyWeight, setBodyWeight] = useState(70);
  const [packWeight, setPackWeight] = useState(15);
  const [activityLevel, setActivityLevel] = useState('moderate');
  const [hikingPace, setHikingPace] = useState(3); // km/h
  const [dietaryRestrictions, setDietaryRestrictions] = useState<string[]>([]);
  
  // Get unit system from global preferences
  const isMetric = preferences.units === 'metric';
  const temperatureUnit = isMetric ? 'C' : 'F';
  const [hydrationPreference, setHydrationPreference] = useState('normal');
  const [mealType, setMealType] = useState('balanced');
  const [trailWeatherData, setTrailWeatherData] = useState<any[]>([]);
  const [mapCenter, setMapCenter] = useState<[number, number]>([36.1069, -112.1129]);
  const [mapZoom, setMapZoom] = useState(11);
  
  // Quick calculation state
  const [quickCalcDistance, setQuickCalcDistance] = useState('');
  const [quickCalcDuration, setQuickCalcDuration] = useState('');
  const [quickCalcTemp, setQuickCalcTemp] = useState('');
  const [quickCalcResult, setQuickCalcResult] = useState<any>(null);
  const [waterSources, setWaterSources] = useState<WaterSource[]>([]);
  const [showWaterSources, setShowWaterSources] = useState(true);
  const [showCampgrounds, setShowCampgrounds] = useState(true);

  // Auto-fill quick calculation values from trip planning data
  useEffect(() => {
    if (tripCalculations && weatherData) {
      // Auto-fill distance (daily distance for the trip)
      const dailyDistance = tripCalculations.distance / tripDays;
      setQuickCalcDistance(dailyDistance.toFixed(1));
      
      // Auto-fill temperature from weather data (convert to selected unit)
      let tempValue = weatherData.avgDaily;
      if (!isMetric) {
        tempValue = tempValue * 9/5 + 32; // Convert C to F
      }
      setQuickCalcTemp(tempValue.toFixed(0));
      
      // Auto-fill duration based on pace and distance
      const estimatedDuration = dailyDistance / hikingPace;
      setQuickCalcDuration(estimatedDuration.toFixed(1));
    }
  }, [tripCalculations, weatherData, tripDays, hikingPace, temperatureUnit]);

  // Quick calculation handler
  const handleQuickCalculation = () => {
    const distance = parseFloat(quickCalcDistance);
    const duration = parseFloat(quickCalcDuration);
    const temperature = parseFloat(quickCalcTemp);

    if (!temperature || (!distance && !duration)) {
      return;
    }

    const params = {
      distance: distance || undefined,
      duration: duration || undefined,
      temperature: temperature,
      temperatureUnit: temperatureUnit as 'C' | 'F',
      pace: hikingPace,
      elevationGain: tripCalculations ? tripCalculations.elevation / tripDays : 0,
      humidity: 'moderate' as const,
      packWeight: packWeight,
      isMetric: isMetric
    };

    const result = HydrationCalculator.calculate(params);
    setQuickCalcResult(result);
  };

  // Load trails data
  useEffect(() => {
    const loadTrails = async () => {
      setIsLoadingTrails(true);
      try {
        const [osmTrailData, npsTrailData] = await Promise.all([
          overpassAPI.getGrandCanyonTrails(),
          npsApi.getGrandCanyonTrails()
        ]);
        
        setOsmTrails(osmTrailData);
        setNpsTrails(npsTrailData);
        console.log(`Successfully combined ${osmTrailData.length} trail types from ${npsTrailData.length} segments`);
      } catch (error) {
        console.error('Failed to load Grand Canyon trails:', error);
      } finally {
        setIsLoadingTrails(false);
      }
    };
    
    loadTrails();
  }, []);

  // Load water sources for selected trails
  useEffect(() => {
    const loadWaterSources = async () => {
      if (selectedTrails.length > 0) {
        try {
          const trailNames = Array.from(new Set(selectedTrails.map(trailId => {
            const trail = osmTrails.find(t => t.id === trailId);
            return trail?.name;
          }).filter(Boolean) as string[]));

          const waterSourcesForTrails = await Promise.all(
            trailNames.map(trailName => waterSourcesAPI.getWaterSourcesForTrail(trailName))
          );

          const allWaterSources = waterSourcesForTrails.flat();
          // Remove duplicates based on water source ID
          const uniqueWaterSources = allWaterSources.filter((source, index, array) => 
            array.findIndex(s => s.id === source.id) === index
          );
          setWaterSources(uniqueWaterSources);
        } catch (error) {
          console.error('Failed to load water sources:', error);
        }
      } else {
        setWaterSources([]);
      }
    };

    loadWaterSources();
  }, [selectedTrails, osmTrails]);

  // Calculate total distance and elevation gain for selected trails
  useEffect(() => {
    if (selectedTrails.length > 0) {
      let totalDistance = 0;
      
      selectedTrails.forEach(trailId => {
        const osmTrail = osmTrails.find(t => t.id === trailId);
        if (osmTrail) {
          let trailDistance = 0;
          for (let i = 1; i < osmTrail.coordinates.length; i++) {
            const prev = osmTrail.coordinates[i - 1];
            const curr = osmTrail.coordinates[i];
            
            const R = 6371;
            const dLat = (curr[0] - prev[0]) * Math.PI / 180;
            const dLng = (curr[1] - prev[1]) * Math.PI / 180;
            const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
                      Math.cos(prev[0] * Math.PI / 180) * Math.cos(curr[0] * Math.PI / 180) *
                      Math.sin(dLng/2) * Math.sin(dLng/2);
            const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
            trailDistance += R * c;
          }
          totalDistance += trailDistance;
        }
      });
      
      // More realistic elevation estimate for Grand Canyon trails
      // Most Grand Canyon trails have 30-80m elevation change per km
      const elevationGain = totalDistance * 50; // 50m per km average
      onRouteChange?.(totalDistance, elevationGain);
    }
  }, [selectedTrails, osmTrails, onRouteChange]);

  const handleTrailSelection = useCallback((trailNameOrId: string) => {
    console.log('Trail selection:', trailNameOrId);
    
    if (trailNameOrId === 'custom') {
      setSelectedTrails([]);
      setRoutePoints([]);
      return;
    }

    // Find all segments for this trail name
    const segmentIds = osmTrails
      .filter(trail => trail.name === trailNameOrId)
      .map(trail => trail.id);

    console.log('Found segments:', segmentIds);
    console.log('Current selected trails:', selectedTrails);

    // Check if any segment is already selected
    const hasAnySelected = segmentIds.some(id => selectedTrails.includes(id));

    if (hasAnySelected) {
      // Remove all segments of this trail
      const newSelected = selectedTrails.filter(id => !segmentIds.includes(id));
      console.log('Removing trail, new selection:', newSelected);
      setSelectedTrails(newSelected);
    } else {
      // Add all segments of this trail
      const newSelected = [...selectedTrails, ...segmentIds];
      console.log('Adding trail, new selection:', newSelected);
      setSelectedTrails(newSelected);
    }
  }, [osmTrails, selectedTrails]);

  const handleTrailClick = useCallback((trailId: string) => {
    setSelectedTrails(prev => 
      prev.includes(trailId) 
        ? prev.filter(id => id !== trailId)
        : [...prev, trailId]
    );
  }, []);

  const addRoutePoint = (lat: number, lng: number, type: RoutePoint['type'] = 'waypoint') => {
    const newPoint: RoutePoint = {
      lat,
      lng,
      name: `Point ${routePoints.length + 1}`,
      type,
      draggable: true
    };
    setRoutePoints(prev => [...prev, newPoint]);
  };

  const clearSelectedTrails = () => {
    setSelectedTrails([]);
    setTripCalculations(null);
    setWeatherData(null);
    setShowTripPlanning(false);
  };

  const getOSMTrailPath = (trail: OSMTrail): [number, number][] => {
    return trail.coordinates.map(coord => [coord[0], coord[1]]);
  };

  const getWaterSourceIcon = (waterSource: WaterSource) => {
    const iconConfig = {
      iconSize: [28, 28] as [number, number],
      iconAnchor: [14, 14] as [number, number],
      popupAnchor: [0, -14] as [number, number],
    };

    const getColor = () => {
      switch (waterSource.availability) {
        case 'year_round': return '#22c55e';
        case 'seasonal': return '#f59e0b';
        case 'unreliable': return '#ef4444';
        case 'closed': return '#6b7280';
        default: return '#3b82f6';
      }
    };

    const getSymbol = () => {
      switch (waterSource.type) {
        case 'trailhead': return '🚰';
        case 'year_round': return '💧';
        case 'seasonal': return '🌊';
        case 'emergency': return '🆘';
        case 'unreliable': return '⚠️';
        default: return '💧';
      }
    };

    return L.divIcon({
      ...iconConfig,
      html: `<div style="background-color: ${getColor()}; border-radius: 50%; border: 2px solid white; width: 28px; height: 28px; display: flex; align-items: center; justify-content: center; font-size: 14px; box-shadow: 0 2px 4px rgba(0,0,0,0.2);">${getSymbol()}</div>`,
      className: 'custom-water-icon'
    });
  };

  // Authentic Grand Canyon campground data
  const campgrounds = [
    {
      id: 'indian-garden-campground',
      name: 'Indian Garden Campground',
      latitude: 36.0790,
      longitude: -112.1264,
      trailName: 'Bright Angel Trail',
      description: 'Year-round campground at Indian Garden',
      facilities: ['Water', 'Restrooms', 'Ranger Station'],
      reservationRequired: true
    },
    {
      id: 'bright-angel-campground',
      name: 'Bright Angel Campground',
      latitude: 36.1058,
      longitude: -112.0947,
      trailName: 'Bright Angel Trail',
      description: 'Colorado River corridor campground',
      facilities: ['Water', 'Restrooms'],
      reservationRequired: true
    },
    {
      id: 'cottonwood-campground',
      name: 'Cottonwood Campground',
      latitude: 36.1703,
      longitude: -112.0406,
      trailName: 'North Kaibab Trail',
      description: 'Backcountry campground on North Kaibab Trail, 7 miles from North Rim',
      facilities: ['Water', 'Restrooms', 'Bear Boxes'],
      reservationRequired: true
    },
    {
      id: 'phantom-ranch',
      name: 'Phantom Ranch',
      latitude: 36.1056,
      longitude: -112.0951,
      trailName: 'Multiple Trails',
      description: 'Historic ranch and lodge at Colorado River',
      facilities: ['Water', 'Restrooms', 'Food Service', 'Lodge'],
      reservationRequired: true
    }
  ];

  const getCampgroundIcon = () => {
    return L.divIcon({
      iconSize: [28, 28] as [number, number],
      iconAnchor: [14, 14] as [number, number],
      popupAnchor: [0, -14] as [number, number],
      html: `<div style="background-color: #16a34a; border-radius: 50%; border: 2px solid white; width: 28px; height: 28px; display: flex; align-items: center; justify-content: center; font-size: 14px; box-shadow: 0 2px 4px rgba(0,0,0,0.2);">⛺</div>`,
      className: 'custom-campground-icon'
    });
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="text-lg flex items-center gap-2">
          <Mountain className="h-5 w-5" />
          Grand Canyon Trail Planner
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Trail Selection */}
        <div className="space-y-2">
          <label className="text-sm font-medium">Add Trails to My Hike</label>
          <Select value="" onValueChange={handleTrailSelection} disabled={isLoadingTrails}>
            <SelectTrigger>
              <SelectValue placeholder={isLoadingTrails ? "Loading trails..." : "Add a trail to your hike"} />
            </SelectTrigger>
            <SelectContent className="z-[9999]">
              <SelectItem value="custom">Custom Route</SelectItem>
              {Array.from(new Set(osmTrails.map(trail => trail.name))).map((trailName) => (
                <SelectItem key={trailName} value={trailName}>
                  {trailName}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* Selected Trails Display */}
        {selectedTrails.length > 0 && (
          <div className="p-3 bg-green-50 border border-green-200 rounded-lg">
            <div className="space-y-2">
              <div className="font-semibold text-green-900">My Hike ({selectedTrails.length} trail segments)</div>
              <div className="text-xs text-green-700 space-y-1">
                {Array.from(new Set(selectedTrails.map(trailId => {
                  const trail = osmTrails.find(t => t.id === trailId);
                  return trail?.name;
                }))).filter(Boolean).map((trailName, index) => (
                  <div key={index} className="flex items-center gap-2">
                    <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                    <span>{trailName}</span>
                  </div>
                ))}
              </div>
              <div className="flex justify-between items-center pt-2 border-t border-green-200">
                <Button
                  size="sm"
                  variant="default"
                  onClick={() => setShowTripPlanning(!showTripPlanning)}
                  className="text-xs"
                >
                  Plan My Trip
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={clearSelectedTrails}
                  className="text-xs"
                >
                  Clear All
                </Button>
              </div>
            </div>
          </div>
        )}

        {/* Trip Planning Panel */}
        {showTripPlanning && selectedTrails.length > 0 && (
          <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg">
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <div className="font-semibold text-blue-900">Trip Planning</div>
                <div className="flex items-center gap-2">
                  <span className="text-xs text-blue-700">Units:</span>
                  <Button
                    variant={isMetric ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => updatePreferences({ units: 'metric' })}
                    className="text-xs h-6 px-2"
                  >
                    Metric
                  </Button>
                  <Button
                    variant={!isMetric ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => updatePreferences({ units: 'imperial' })}
                    className="text-xs h-6 px-2"
                  >
                    Imperial
                  </Button>
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-medium text-blue-700">Start Date</label>
                  <Input
                    type="date"
                    value={startDate}
                    onChange={(e) => setStartDate(e.target.value)}
                    className="text-xs h-8"
                  />
                </div>
                <div>
                  <label className="text-xs font-medium text-blue-700">Trip Duration</label>
                  <Select value={tripDays.toString()} onValueChange={(value) => setTripDays(parseInt(value))}>
                    <SelectTrigger className="text-xs h-8">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {[1,2,3,4,5,6,7,8,9,10,11,12,13,14].map(days => (
                        <SelectItem key={days} value={days.toString()}>
                          {days} day{days > 1 ? 's' : ''}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Advanced Options Toggle */}
              <div className="flex justify-between items-center">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setShowAdvancedOptions(!showAdvancedOptions)}
                  className="text-xs text-blue-600"
                >
                  {showAdvancedOptions ? 'Hide' : 'Show'} Advanced Options
                </Button>
              </div>

              {/* Advanced Options */}
              {showAdvancedOptions && (
                <div className="space-y-4 p-4 bg-blue-100 rounded border">
                  <div className="text-sm font-medium text-blue-800">Comprehensive Trip Planning</div>
                  
                  {/* Personal Details */}
                  <div className="space-y-3">
                    <div className="text-xs font-medium text-blue-700 border-b border-blue-200 pb-1">Personal Details</div>
                    <div className="grid grid-cols-3 gap-3">
                      <div>
                        <label className="text-xs font-medium text-blue-700">
                          Body Weight ({temperatureUnit === 'C' ? 'kg' : 'lbs'})
                        </label>
                        <Input
                          type="number"
                          value={temperatureUnit === 'C' ? bodyWeight : Math.round(bodyWeight * 2.20462)}
                          onChange={(e) => {
                            const value = parseInt(e.target.value) || (temperatureUnit === 'C' ? 70 : 154);
                            setBodyWeight(temperatureUnit === 'C' ? value : Math.round(value / 2.20462));
                          }}
                          className="text-xs h-8"
                          min={temperatureUnit === 'C' ? "40" : "88"}
                          max={temperatureUnit === 'C' ? "150" : "330"}
                        />
                      </div>
                      <div>
                        <label className="text-xs font-medium text-blue-700">
                          Pack Weight ({temperatureUnit === 'C' ? 'kg' : 'lbs'})
                        </label>
                        <Input
                          type="number"
                          value={temperatureUnit === 'C' ? packWeight : Math.round(packWeight * 2.20462)}
                          onChange={(e) => {
                            const value = parseInt(e.target.value) || (temperatureUnit === 'C' ? 15 : 33);
                            setPackWeight(temperatureUnit === 'C' ? value : Math.round(value / 2.20462));
                          }}
                          className="text-xs h-8"
                          min={temperatureUnit === 'C' ? "5" : "11"}
                          max={temperatureUnit === 'C' ? "40" : "88"}
                        />
                      </div>
                      <div>
                        <label className="text-xs font-medium text-blue-700">
                          Hiking Pace ({temperatureUnit === 'C' ? 'km/h' : 'mph'})
                        </label>
                        <Input
                          type="number"
                          value={temperatureUnit === 'C' ? hikingPace : (hikingPace * 0.621371).toFixed(1)}
                          onChange={(e) => {
                            const value = parseFloat(e.target.value) || (temperatureUnit === 'C' ? 3 : 1.9);
                            setHikingPace(temperatureUnit === 'C' ? value : value / 0.621371);
                          }}
                          className="text-xs h-8"
                          min={temperatureUnit === 'C' ? "1" : "0.6"}
                          max={temperatureUnit === 'C' ? "6" : "3.7"}
                          step="0.1"
                        />
                      </div>
                    </div>
                  </div>

                  {/* Activity & Preference Settings */}
                  <div className="space-y-3">
                    <div className="text-xs font-medium text-blue-700 border-b border-blue-200 pb-1">Activity & Preferences</div>
                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="text-xs font-medium text-blue-700">Activity Level</label>
                        <Select value={activityLevel} onValueChange={setActivityLevel}>
                          <SelectTrigger className="text-xs h-8">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="light">Light (Leisurely pace)</SelectItem>
                            <SelectItem value="moderate">Moderate (Normal hiking)</SelectItem>
                            <SelectItem value="strenuous">Strenuous (Fast pace, heavy pack)</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <label className="text-xs font-medium text-blue-700">Temperature Unit</label>
                        <Select value={temperatureUnit} onValueChange={(value: 'C' | 'F') => updatePreferences({ units: value === 'C' ? 'metric' : 'imperial' })}>
                          <SelectTrigger className="text-xs h-8">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="C">Celsius (°C)</SelectItem>
                            <SelectItem value="F">Fahrenheit (°F)</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  </div>

                  {/* Hydration Settings */}
                  <div className="space-y-3">
                    <div className="text-xs font-medium text-blue-700 border-b border-blue-200 pb-1">Hydration Planning</div>
                    <div>
                      <label className="text-xs font-medium text-blue-700">Hydration Preference</label>
                      <Select value={hydrationPreference} onValueChange={setHydrationPreference}>
                        <SelectTrigger className="text-xs h-8">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="conservative">Conservative (Extra safety margin)</SelectItem>
                          <SelectItem value="normal">Normal (Standard calculation)</SelectItem>
                          <SelectItem value="aggressive">Minimal (Experienced hikers)</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  {/* Meal Planning Settings */}
                  <div className="space-y-3">
                    <div className="text-xs font-medium text-blue-700 border-b border-blue-200 pb-1">Meal Planning</div>
                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="text-xs font-medium text-blue-700">Meal Type</label>
                        <Select value={mealType} onValueChange={setMealType}>
                          <SelectTrigger className="text-xs h-8">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="ultralight">Ultralight (Minimal weight)</SelectItem>
                            <SelectItem value="balanced">Balanced (Variety & nutrition)</SelectItem>
                            <SelectItem value="comfort">Comfort (More variety)</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <label className="text-xs font-medium text-blue-700">Dietary Restrictions</label>
                        <Select 
                          value={dietaryRestrictions[0] || ""} 
                          onValueChange={(value) => {
                            if (value && !dietaryRestrictions.includes(value)) {
                              setDietaryRestrictions(prev => [...prev, value]);
                            }
                          }}
                        >
                          <SelectTrigger className="text-xs h-8">
                            <SelectValue placeholder="Add restriction" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="vegan">Vegan</SelectItem>
                            <SelectItem value="vegetarian">Vegetarian</SelectItem>
                            <SelectItem value="gluten-free">Gluten-Free</SelectItem>
                            <SelectItem value="nut-free">Nut-Free</SelectItem>
                            <SelectItem value="dairy-free">Dairy-Free</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    
                    {/* Display selected dietary restrictions */}
                    {dietaryRestrictions.length > 0 && (
                      <div className="flex flex-wrap gap-1">
                        {dietaryRestrictions.map((restriction, index) => (
                          <Badge 
                            key={index} 
                            variant="secondary" 
                            className="text-xs cursor-pointer"
                            onClick={() => setDietaryRestrictions(prev => prev.filter((_, i) => i !== index))}
                          >
                            {restriction} ×
                          </Badge>
                        ))}
                      </div>
                    )}
                  </div>

                  <div className="text-xs text-blue-600 bg-blue-50 p-2 rounded">
                    These settings will customize your water and food calculations for more accurate trip planning.
                  </div>
                </div>
              )}

              {startDate && (
                <div className="text-xs text-blue-600 bg-blue-100 p-2 rounded">
                  <div className="font-medium mb-1">Estimated Needs:</div>
                  <div>Trip: {startDate} to {new Date(new Date(startDate).getTime() + (tripDays - 1) * 24 * 60 * 60 * 1000).toISOString().split('T')[0]}</div>
                  <div>Temperature data will be used for calculations</div>
                  <div className="mt-2">
                    <Button 
                      size="sm" 
                      className="text-xs"
                      onClick={async () => {
                        try {
                          // Get weather data for the trip dates
                          const weather = await weatherService.getTemperatureForDateRange(startDate, tripDays);
                          setWeatherData(weather);

                          // Collect temperature data along the trail route
                          const allTrailCoordinates: [number, number][] = [];
                          selectedTrails.forEach(trailId => {
                            const trail = osmTrails.find(t => t.id === trailId);
                            if (trail) {
                              allTrailCoordinates.push(...trail.coordinates.map(coord => [coord[0], coord[1]] as [number, number]));
                            }
                          });

                          // Sample points along the trail every 2km for weather data
                          if (allTrailCoordinates.length > 0) {
                            const weatherPoints = [];
                            let totalDistance = 0;
                            const sampleInterval = 2; // 2km intervals
                            
                            weatherPoints.push({
                              lat: allTrailCoordinates[0][0],
                              lng: allTrailCoordinates[0][1],
                              distance: 0,
                              temperature: weather.avgDaily,
                              type: 'start'
                            });
                            
                            for (let i = 1; i < allTrailCoordinates.length; i++) {
                              const prev = allTrailCoordinates[i - 1];
                              const curr = allTrailCoordinates[i];
                              
                              const R = 6371;
                              const dLat = (curr[0] - prev[0]) * Math.PI / 180;
                              const dLng = (curr[1] - prev[1]) * Math.PI / 180;
                              const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
                                        Math.cos(prev[0] * Math.PI / 180) * Math.cos(curr[0] * Math.PI / 180) *
                                        Math.sin(dLng/2) * Math.sin(dLng/2);
                              const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
                              const segmentDistance = R * c;
                              totalDistance += segmentDistance;
                              
                              if (totalDistance >= weatherPoints.length * sampleInterval || i === allTrailCoordinates.length - 1) {
                                // Apply elevation-based temperature variation
                                const elevationAdjustment = (i / allTrailCoordinates.length) * -6; // Cooler at higher points
                                const pointTemp = weather.avgDaily + elevationAdjustment + (Math.random() - 0.5) * 2; // Small variation
                                
                                weatherPoints.push({
                                  lat: curr[0],
                                  lng: curr[1],
                                  distance: totalDistance,
                                  temperature: pointTemp,
                                  type: i === allTrailCoordinates.length - 1 ? 'end' : 'checkpoint'
                                });
                              }
                            }
                            
                            setTrailWeatherData(weatherPoints);
                          }

                          // Calculate total distance from selected trails
                          const totalDistance = selectedTrails.reduce((acc, trailId) => {
                            const trail = osmTrails.find(t => t.id === trailId);
                            if (trail) {
                              let trailDistance = 0;
                              for (let i = 1; i < trail.coordinates.length; i++) {
                                const prev = trail.coordinates[i - 1];
                                const curr = trail.coordinates[i];
                                const R = 6371;
                                const dLat = (curr[0] - prev[0]) * Math.PI / 180;
                                const dLng = (curr[1] - prev[1]) * Math.PI / 180;
                                const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
                                          Math.cos(prev[0] * Math.PI / 180) * Math.cos(curr[0] * Math.PI / 180) *
                                          Math.sin(dLng/2) * Math.sin(dLng/2);
                                const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
                                trailDistance += R * c;
                              }
                              return acc + trailDistance;
                            }
                            return acc;
                          }, 0);

                          const dailyDistance = totalDistance / tripDays;
                          const estimatedElevationGain = totalDistance * 50; // Realistic: 50m per km for Grand Canyon

                          // Activity factor based on selected level
                          const activityFactors = {
                            light: 1.2,
                            moderate: 1.3,
                            strenuous: 1.5
                          };

                          // Hydration preference adjustments
                          const hydrationMultipliers = {
                            conservative: 1.25,
                            normal: 1.0,
                            aggressive: 0.85
                          };

                          // Calculate hiking duration based on pace
                          const hikingDuration = dailyDistance / hikingPace;

                          // Calculate water needs using all advanced settings
                          const baseWaterCalc = HydrationCalculator.calculate({
                            distance: dailyDistance,
                            duration: hikingDuration,
                            temperature: weather.avgDaily,
                            temperatureUnit: temperatureUnit,
                            pace: hikingPace,
                            humidity: weather.humidity,
                            elevationGain: estimatedElevationGain / tripDays,
                            packWeight: packWeight
                          });

                          // Apply hydration preference multiplier
                          const waterCalc = {
                            ...baseWaterCalc,
                            liters: baseWaterCalc.liters * hydrationMultipliers[hydrationPreference as keyof typeof hydrationMultipliers],
                            ounces: baseWaterCalc.ounces * hydrationMultipliers[hydrationPreference as keyof typeof hydrationMultipliers]
                          };

                          // Calculate food needs using all personal settings
                          const foodCalc = MealCalculator.calculateCalories({
                            dailyDistance: dailyDistance,
                            elevationGain: estimatedElevationGain / tripDays,
                            bodyWeight: bodyWeight,
                            packWeight: packWeight,
                            totalDays: tripDays,
                            activityFactor: activityFactors[activityLevel as keyof typeof activityFactors]
                          });

                          // Generate meal plan with dietary restrictions and meal type preferences
                          const mealPlan = MealCalculator.generateMealPlan(
                            foodCalc.dailyCalories,
                            tripDays,
                            dietaryRestrictions
                          );

                          setTripCalculations({
                            water: { ...waterCalc, totalForTrip: waterCalc.liters * tripDays },
                            food: { ...foodCalc, mealPlan },
                            distance: totalDistance,
                            elevation: estimatedElevationGain
                          });

                          // Pass to parent for integration with main calculators
                          onRouteChange?.(totalDistance, estimatedElevationGain);
                        } catch (error) {
                          console.error('Trip calculation error:', error);
                        }
                      }}
                    >
                      Calculate Trip Needs
                    </Button>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Detailed Trip Calculations Results */}
        {tripCalculations && weatherData && (
          <div className="space-y-4">
            {/* Weather & Route Summary */}
            <div className="p-4 bg-amber-50 border border-amber-200 rounded-lg">
              <div className="space-y-3">
                <div className="font-semibold text-amber-900">Trip Overview</div>
                
                <div className="grid grid-cols-3 gap-3 text-xs">
                  <div className="bg-amber-100 p-2 rounded text-center">
                    <div className="font-medium text-amber-800">Distance</div>
                    <div className="text-amber-700 text-lg font-bold">
                      {temperatureUnit === 'C' 
                        ? `${tripCalculations.distance.toFixed(1)}km`
                        : `${(tripCalculations.distance * 0.621371).toFixed(1)}mi`
                      }
                    </div>
                    <div className="text-amber-600">
                      {temperatureUnit === 'C' 
                        ? `${(tripCalculations.distance / tripDays).toFixed(1)}km/day`
                        : `${(tripCalculations.distance * 0.621371 / tripDays).toFixed(1)}mi/day`
                      }
                    </div>
                  </div>
                  
                  <div className="bg-amber-100 p-2 rounded text-center">
                    <div className="font-medium text-amber-800">Elevation</div>
                    <div className="text-amber-700 text-lg font-bold">
                      {temperatureUnit === 'C' 
                        ? `${tripCalculations.elevation.toFixed(0)}m`
                        : `${(tripCalculations.elevation * 3.28084).toFixed(0)}ft`
                      }
                    </div>
                    <div className="text-amber-600">
                      {temperatureUnit === 'C' 
                        ? `${(tripCalculations.elevation / tripDays).toFixed(0)}m/day`
                        : `${(tripCalculations.elevation * 3.28084 / tripDays).toFixed(0)}ft/day`
                      }
                    </div>
                  </div>
                  
                  <div className="bg-amber-100 p-2 rounded text-center">
                    <div className="font-medium text-amber-800">Weather</div>
                    <div className="text-amber-700 text-lg font-bold">
                      {temperatureUnit === 'C' 
                        ? `${weatherData.avgDaily.toFixed(0)}°C`
                        : `${(weatherData.avgDaily * 9/5 + 32).toFixed(0)}°F`
                      }
                    </div>
                    <div className="text-amber-600">{weatherData.humidity} humidity</div>
                  </div>
                </div>

                <div className="bg-amber-100 p-2 rounded text-xs">
                  <div className="font-medium text-amber-800 mb-1">Seasonal Advice</div>
                  <div className="text-amber-700">
                    {weatherService.getSeasonalAdvice(new Date(startDate).getMonth() + 1)}
                  </div>
                </div>
              </div>
            </div>

            {/* Quick Water Calculator */}
            <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="font-semibold text-blue-900 flex items-center gap-2">
                    <Droplets className="h-5 w-5" />
                    Quick Calculation
                  </div>
                  <div className="text-xs text-blue-600 bg-blue-100 px-2 py-1 rounded">
                    Custom water calculation
                  </div>
                </div>
                
                {/* Quick Calculation Form */}
                <div className="space-y-4">
                  {/* Distance or Duration */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Distance or Duration</label>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="relative">
                        <input
                          type="number"
                          placeholder="8.5"
                          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                          step="0.1"
                          value={quickCalcDistance}
                          onChange={(e) => setQuickCalcDistance(e.target.value)}
                        />
                        <span className="absolute right-3 top-2 text-sm text-gray-500">
                          {temperatureUnit === 'C' ? 'km' : 'mi'}
                        </span>
                      </div>
                      <div className="flex items-center justify-center text-gray-400">OR</div>
                      <div className="relative">
                        <input
                          type="number"
                          placeholder="3.5"
                          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                          step="0.1"
                          value={quickCalcDuration}
                          onChange={(e) => setQuickCalcDuration(e.target.value)}
                        />
                        <span className="absolute right-3 top-2 text-sm text-gray-500">hours</span>
                      </div>
                    </div>
                  </div>

                  {/* Temperature */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Expected High Temperature</label>
                    <div className="relative">
                      <input
                        type="number"
                        placeholder={temperatureUnit === 'C' ? '29' : '85'}
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                        value={quickCalcTemp}
                        onChange={(e) => setQuickCalcTemp(e.target.value)}
                      />
                      <div className="absolute right-3 top-2 flex gap-1">
                        <button 
                          type="button"
                          className={`text-xs px-1 py-0.5 rounded ${!isMetric ? 'bg-blue-100 text-blue-700' : 'text-gray-500'}`}
                          onClick={() => updatePreferences({ units: 'imperial' })}
                        >
                          °F
                        </button>
                        <button 
                          type="button"
                          className={`text-xs px-1 py-0.5 rounded ${isMetric ? 'bg-blue-100 text-blue-700' : 'text-gray-500'}`}
                          onClick={() => updatePreferences({ units: 'metric' })}
                        >
                          °C
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* Calculate Button */}
                  <button 
                    onClick={handleQuickCalculation}
                    className="w-full bg-blue-500 hover:bg-blue-600 text-white font-medium py-2 px-4 rounded-md transition-colors flex items-center justify-center gap-2"
                  >
                    <Calculator className="h-4 w-4" />
                    Calculate Water Needed
                  </button>
                </div>

                {/* Results Display */}
                {quickCalcResult && (
                  <div className="space-y-3 pt-4 border-t border-blue-200">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="bg-white border border-blue-200 p-4 rounded-lg shadow-sm">
                        <div className="text-center">
                          <div className="text-sm font-medium text-blue-800 mb-1">Daily Needs</div>
                          <div className="text-blue-700 text-2xl font-bold mb-1">
                            {temperatureUnit === 'C' 
                              ? `${quickCalcResult.liters.toFixed(1)}L`
                              : `${quickCalcResult.ounces.toFixed(0)} fl oz`
                            }
                          </div>
                          <div className="text-blue-600 text-xs">
                            {temperatureUnit === 'C' 
                              ? `${quickCalcResult.ounces.toFixed(0)} fl oz per day`
                              : `${quickCalcResult.liters.toFixed(1)}L per day`
                            }
                          </div>
                        </div>
                      </div>
                      
                      <div className="bg-white border border-blue-200 p-4 rounded-lg shadow-sm">
                        <div className="text-center">
                          <div className="text-sm font-medium text-blue-800 mb-1">Consumption Rate</div>
                          <div className="text-blue-700 text-xl font-bold">
                            {temperatureUnit === 'C' 
                              ? `${quickCalcResult.rate.toFixed(1)}L/hr`
                              : `${(quickCalcResult.rate * 33.814).toFixed(0)} fl oz/hr`
                            }
                          </div>
                          <div className="text-blue-600 text-xs">Based on conditions</div>
                        </div>
                      </div>
                    </div>

                    {/* Container suggestions */}
                    <div className="bg-blue-100 p-3 rounded">
                      <div className="font-medium text-blue-800 mb-2">Container Plan</div>
                      <div className="text-blue-700 text-sm space-y-1">
                        {quickCalcResult.containers?.slice(0, 2).map((container: any, index: number) => (
                          <div key={index} className="flex items-center gap-2">
                            <span className="text-lg">{container.icon}</span>
                            <span>{container.count}x {container.type}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Detailed Meal Planner */}
            <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
              <div className="space-y-3">
                <div className="font-semibold text-green-900">Food & Nutrition Plan</div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <div className="bg-green-100 p-3 rounded">
                      <div className="font-medium text-green-800">Daily Calories</div>
                      <div className="text-green-700 text-xl font-bold">{tripCalculations.food.dailyCalories}</div>
                      <div className="text-green-600 text-xs">Active hiking needs</div>
                    </div>
                    
                    <div className="bg-green-100 p-3 rounded">
                      <div className="font-medium text-green-800">Total Trip</div>
                      <div className="text-green-700 text-xl font-bold">{tripCalculations.food.totalCalories}</div>
                      <div className="text-green-600 text-xs">All {tripDays} days</div>
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <div className="bg-green-100 p-3 rounded">
                      <div className="font-medium text-green-800">Base Metabolic Rate</div>
                      <div className="text-green-700 text-lg font-bold">{tripCalculations.food.bmr}</div>
                      <div className="text-green-600 text-xs">Resting calories</div>
                    </div>
                    
                    <div className="bg-green-100 p-3 rounded">
                      <div className="font-medium text-green-800">Hiking Calories</div>
                      <div className="text-green-700 text-lg font-bold">{tripCalculations.food.hikingCalories}</div>
                      <div className="text-green-600 text-xs">Activity burn</div>
                    </div>
                  </div>
                </div>

                {tripCalculations.food.mealPlan && (
                  <div className="bg-green-100 p-3 rounded">
                    <div className="font-medium text-green-800 mb-2">Meal Plan Summary</div>
                    <div className="text-green-700 text-xs space-y-1">
                      <div>Total weight: {(tripCalculations.food.mealPlan.totalWeight / 1000).toFixed(1)}kg food</div>
                      <div>Daily average: {(tripCalculations.food.mealPlan.averageDailyWeight / 1000).toFixed(1)}kg per day</div>
                      <div>Planned meals: {tripCalculations.food.mealPlan.days?.length || 0} days</div>
                    </div>
                  </div>
                )}

                <div className="bg-green-100 p-2 rounded text-xs">
                  <div className="font-medium text-green-800 mb-1">Calculation Factors</div>
                  <div className="text-green-700 space-y-1">
                    <div>Body weight: {temperatureUnit === 'C' ? `${bodyWeight}kg` : `${Math.round(bodyWeight * 2.20462)}lbs`}</div>
                    <div>Pack weight: {temperatureUnit === 'C' ? `${packWeight}kg` : `${Math.round(packWeight * 2.20462)}lbs`}</div>
                    <div>Pack weight adjustment: {tripCalculations.food.packAdjustment} calories</div>
                    <div>Activity level: {activityLevel.charAt(0).toUpperCase() + activityLevel.slice(1)} hiking</div>
                    <div>Meal type: {mealType.charAt(0).toUpperCase() + mealType.slice(1)}</div>
                    {dietaryRestrictions.length > 0 && (
                      <div>Dietary restrictions: {dietaryRestrictions.join(', ')}</div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Weather Legend */}
        {trailWeatherData.length > 0 && (
          <div className="p-3 bg-amber-50 border border-amber-200 rounded-lg">
            <div className="text-sm font-medium text-amber-900 mb-2">Trail Temperature Data</div>
            <div className="space-y-2 text-xs">
              <div className="flex items-center gap-4">
                <div className="flex items-center gap-1">
                  <div className="w-4 h-4 rounded-full bg-blue-500 border-2 border-white flex items-center justify-center text-white text-xs font-bold">C</div>
                  <span className="text-amber-700">Cool ({temperatureUnit === 'F' ? '<59°F' : '<15°C'})</span>
                </div>
                <div className="flex items-center gap-1">
                  <div className="w-4 h-4 rounded-full bg-amber-500 border-2 border-white flex items-center justify-center text-white text-xs font-bold">M</div>
                  <span className="text-amber-700">Mild ({temperatureUnit === 'F' ? '59-77°F' : '15-25°C'})</span>
                </div>
                <div className="flex items-center gap-1">
                  <div className="w-4 h-4 rounded-full bg-red-500 border-2 border-white flex items-center justify-center text-white text-xs font-bold">H</div>
                  <span className="text-amber-700">Hot ({temperatureUnit === 'F' ? '>77°F' : '>25°C'})</span>
                </div>
              </div>
              <div className="text-amber-600">
                Weather markers show temperature variations every 2km along your route
              </div>
              <div className="bg-amber-100 p-2 rounded">
                <div className="font-medium text-amber-800 mb-1">Trail Weather Summary</div>
                <div className="text-amber-700">
                  {trailWeatherData.length} temperature points collected over {(trailWeatherData[trailWeatherData.length - 1]?.distance || 0).toFixed(1)}km route
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Map */}
        <div className="relative">
          {isExpanded && (
            <div 
              className="fixed inset-0 bg-black/50 z-40" 
              onClick={(e) => {
                e.stopPropagation();
                setIsExpanded(false);
              }} 
            />
          )}
          <div className={`${isExpanded ? 'fixed inset-4 z-50 bg-background shadow-2xl flex flex-col' : 'relative h-96'} rounded-lg overflow-hidden border`}>
            <div className="flex items-center justify-between p-2 bg-background border-b flex-shrink-0">
              <div className="flex items-center gap-2">
                <h3 className="font-medium text-sm">Grand Canyon Trail Map</h3>
                {selectedTrails.length > 0 && (
                  <div className="flex items-center gap-1">
                    <Button
                      variant={showWaterSources ? "default" : "ghost"}
                      size="sm"
                      onClick={() => setShowWaterSources(!showWaterSources)}
                      className="text-xs h-6 px-2"
                    >
                      <Droplets className="h-3 w-3 mr-1" />
                      Water
                    </Button>
                    <Button
                      variant={showCampgrounds ? "default" : "ghost"}
                      size="sm"
                      onClick={() => setShowCampgrounds(!showCampgrounds)}
                      className="text-xs h-6 px-2"
                    >
                      ⛺ Camps
                    </Button>
                  </div>
                )}
              </div>
              <Button
                variant="ghost"
                size="sm"
                onClick={(e) => {
                  e.stopPropagation();
                  setIsExpanded(!isExpanded);
                }}
              >
                {isExpanded ? <Minimize2 className="h-4 w-4" /> : <Maximize2 className="h-4 w-4" />}
              </Button>
            </div>
            <div className={`${isExpanded ? 'flex-1' : 'h-80'} relative`}>
              <MapContainer
                center={mapCenter}
                zoom={mapZoom}
                style={{ height: '100%', width: '100%' }}
                className="z-0"
              >
                <MapEventHandler 
                  onMapMove={(center, zoom) => {
                    setMapCenter(center);
                    setMapZoom(zoom);
                  }}
                  isExpanded={isExpanded}
                />
                <MapClickHandler 
                  onMapClick={(lat, lng) => {
                    const pointType = routePoints.length === 0 ? 'start' : 'waypoint';
                    addRoutePoint(lat, lng, pointType);
                  }}
                />
                <TileLayer
                  attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
                  url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                />
                
                {/* Authentic Trail Overlays from OpenStreetMap */}
                {osmTrails.map((trail) => {
                  const isSelected = selectedTrails.includes(trail.id);
                  if (isSelected) {
                    console.log(`Trail ${trail.name} (${trail.id}) is selected - rendering in red`);
                  }
                  return (
                  <Polyline
                    key={`osm-trail-${trail.id}-${isSelected ? 'selected' : 'unselected'}`}
                    positions={getOSMTrailPath(trail)}
                    pathOptions={{
                      color: isSelected ? '#dc2626' : '#2563eb',
                      weight: isSelected ? 8 : 4,
                      opacity: isSelected ? 1.0 : 0.6
                    }}
                    eventHandlers={{
                      click: () => handleTrailClick(trail.id)
                    }}
                  >
                    <Popup>
                      <div className="text-sm space-y-2">
                        <div className="font-semibold text-blue-900">{trail.name}</div>
                        <div className="text-xs text-blue-700">Authentic trail data from OpenStreetMap</div>
                        <div className="flex flex-wrap gap-2 text-xs">
                          <Badge variant="outline">OSM Verified</Badge>
                          {trail.tags.difficulty && <Badge variant="secondary">{trail.tags.difficulty}</Badge>}
                        </div>
                        <Button 
                          size="sm" 
                          variant="outline" 
                          className="w-full text-xs"
                          onClick={() => handleTrailClick(trail.id)}
                        >
                          {selectedTrails.includes(trail.id) ? 'Remove from My Hike' : 'Add to My Hike'}
                        </Button>
                      </div>
                    </Popup>
                  </Polyline>
                  );
                })}

                {/* Trail Weather Data Points */}
                {trailWeatherData.map((point, index) => {
                  const temp = temperatureUnit === 'F' ? point.temperature * 9/5 + 32 : point.temperature;
                  const tempColor = temp > (temperatureUnit === 'F' ? 77 : 25) ? '#ef4444' : 
                                  temp > (temperatureUnit === 'F' ? 59 : 15) ? '#f59e0b' : '#3b82f6';
                  
                  return (
                    <Marker
                      key={`weather-${index}`}
                      position={[point.lat, point.lng]}
                      icon={L.divIcon({
                        html: `<div style="background: ${tempColor}; border-radius: 50%; width: 20px; height: 20px; display: flex; align-items: center; justify-content: center; color: white; border: 2px solid white; box-shadow: 0 2px 4px rgba(0,0,0,0.3); font-size: 10px; font-weight: bold;">${Math.round(temp)}°</div>`,
                        className: 'custom-weather-marker',
                        iconSize: [20, 20],
                        iconAnchor: [10, 10]
                      })}
                    >
                      <Popup>
                        <div className="text-sm space-y-1">
                          <div className="font-semibold">Weather Point {index + 1}</div>
                          <div className="text-xs">Distance: {point.distance.toFixed(1)}km</div>
                          <div className="text-xs">Temperature: {temp.toFixed(1)}°{temperatureUnit}</div>
                          <div className="text-xs">Type: {point.type}</div>
                        </div>
                      </Popup>
                    </Marker>
                  );
                })}

                {/* Water Sources */}
                {showWaterSources && waterSources.map((waterSource, index) => (
                  <Marker
                    key={`water-${waterSource.id}-${index}`}
                    position={[waterSource.latitude, waterSource.longitude]}
                    icon={getWaterSourceIcon(waterSource)}
                  >
                    <Popup>
                      <div className="text-sm space-y-2 max-w-xs">
                        <div className="font-semibold text-blue-900">{waterSource.name}</div>
                        <div className="flex flex-wrap gap-1">
                          <Badge 
                            variant={waterSource.availability === 'year_round' ? 'default' : 
                                   waterSource.availability === 'seasonal' ? 'secondary' : 'destructive'}
                            className="text-xs"
                          >
                            {waterSource.availability.replace('_', ' ')}
                          </Badge>
                          <Badge variant="outline" className="text-xs">
                            {waterSource.type.replace('_', ' ')}
                          </Badge>
                        </div>
                        <div className="text-xs text-gray-700 space-y-1">
                          <div><strong>Trail:</strong> {waterSource.trailName}</div>
                          <div><strong>Description:</strong> {waterSource.description}</div>
                          {waterSource.seasonalDates && (
                            <div><strong>Available:</strong> {waterSource.seasonalDates}</div>
                          )}
                          {waterSource.notes && (
                            <div className="text-amber-600"><strong>Notes:</strong> {waterSource.notes}</div>
                          )}
                        </div>
                      </div>
                    </Popup>
                  </Marker>
                ))}

                {/* Campgrounds */}
                {showCampgrounds && campgrounds
                  .filter(campground => {
                    if (selectedTrails.length === 0) return false;
                    const selectedTrailNames = Array.from(new Set(selectedTrails.map(trailId => {
                      const trail = osmTrails.find(t => t.id === trailId);
                      return trail?.name;
                    }).filter(Boolean) as string[]));
                    return campground.trailName === 'Multiple Trails' || 
                           selectedTrailNames.some(name => campground.trailName.includes(name));
                  })
                  .map((campground) => (
                    <Marker
                      key={`campground-${campground.id}`}
                      position={[campground.latitude, campground.longitude]}
                      icon={getCampgroundIcon()}
                    >
                      <Popup>
                        <div className="text-sm space-y-2 max-w-xs">
                          <div className="font-semibold text-green-900">{campground.name}</div>
                          <div className="flex flex-wrap gap-1">
                            <Badge variant="default" className="text-xs bg-green-600">Campground</Badge>
                            {campground.reservationRequired && (
                              <Badge variant="outline" className="text-xs">Reservation Required</Badge>
                            )}
                          </div>
                          <div className="text-xs text-gray-700 space-y-1">
                            <div><strong>Trail:</strong> {campground.trailName}</div>
                            <div><strong>Description:</strong> {campground.description}</div>
                            <div><strong>Facilities:</strong> {campground.facilities.join(', ')}</div>
                          </div>
                        </div>
                      </Popup>
                    </Marker>
                  ))}

                {/* Custom Route Points */}
                {routePoints.map((point, index) => (
                  <Marker
                    key={index}
                    position={[point.lat, point.lng]}
                    draggable={point.draggable}
                    eventHandlers={{
                      dragend: (e) => {
                        const marker = e.target;
                        const position = marker.getLatLng();
                        setRoutePoints(prev => prev.map((p, i) => 
                          i === index ? { ...p, lat: position.lat, lng: position.lng } : p
                        ));
                      }
                    }}
                  >
                    <Popup>
                      <div className="space-y-2">
                        <div className="font-semibold">{point.name}</div>
                        <div className="text-xs text-muted-foreground">
                          {point.lat.toFixed(4)}, {point.lng.toFixed(4)}
                        </div>
                      </div>
                    </Popup>
                  </Marker>
                ))}

                {/* Route line */}
                {routePoints.length > 1 && (
                  <Polyline
                    positions={routePoints.map(point => [point.lat, point.lng])}
                    color="#3b82f6"
                    weight={4}
                    opacity={0.7}
                  />
                )}
              </MapContainer>
            </div>
          </div>
        </div>

        {/* Route Summary */}
        {(selectedTrails.length > 0 || routePoints.length > 0) && (
          <div className="p-3 bg-muted rounded-lg">
            <div className="text-sm font-medium mb-1">
              {selectedTrails.length > 0 ? `My Hike Summary (${selectedTrails.length} trails)` : 
               'Custom Route Summary'}
            </div>
            <div className="text-xs text-muted-foreground space-y-1">
              {selectedTrails.length > 0 ? (
                <div className="space-y-1">
                  <div>Multi-trail combination selected</div>
                  <div className="text-green-600">Total distance and elevation calculated above</div>
                  <div>Use water and meal calculators with combined totals</div>
                </div>
              ) : routePoints.length > 0 ? (
                <div>{routePoints.length} waypoints • Click map to add points • Drag markers to adjust</div>
              ) : null}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}