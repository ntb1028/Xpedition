import { Package, Scale, Zap, Apple, Coffee, Soup, Cookie } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import type { MealPlan, FoodItem } from "@/lib/meal-calculator";

interface MealPlanDisplayProps {
  result: {
    dailyCalories: number;
    totalCalories: number;
    bmr: number;
    hikingCalories: number;
    packAdjustment: number;
    mealPlan: MealPlan;
    params: any;
    dietaryRestrictions: string[];
  } | null;
}

const getMealIcon = (mealType: string) => {
  switch (mealType) {
    case 'breakfast': return Coffee;
    case 'lunch': return Apple;
    case 'dinner': return Soup;
    case 'snacks': return Cookie;
    default: return Package;
  }
};

const formatWeight = (grams: number): string => {
  if (grams >= 1000) {
    return `${(grams / 1000).toFixed(1)}kg`;
  }
  return `${Math.round(grams)}g`;
};

export function MealPlanDisplay({ result }: MealPlanDisplayProps) {
  if (!result) return null;

  const { dailyCalories, mealPlan, dietaryRestrictions } = result;

  return (
    <div className="space-y-4">
      {/* Calorie Summary */}
      <Card>
        <CardContent className="p-6">
          <div className="text-center">
            <div className="mb-4">
              <Zap className="h-10 w-10 text-primary mx-auto mb-2" />
              <h2 className="text-lg font-semibold">Daily Calorie Target</h2>
            </div>
            
            <div className="bg-primary/5 rounded-lg p-6 mb-4">
              <div className="text-4xl font-bold text-primary mb-2">
                {dailyCalories.toLocaleString()}
              </div>
              <div className="text-lg text-muted-foreground mb-3">calories per day</div>
              
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div className="bg-background rounded-lg p-3">
                  <div className="font-medium">{mealPlan.totalCalories.toLocaleString()}</div>
                  <div className="text-muted-foreground">Total Calories</div>
                </div>
                <div className="bg-background rounded-lg p-3">
                  <div className="font-medium">{formatWeight(mealPlan.totalWeight)}</div>
                  <div className="text-muted-foreground">Total Food Weight</div>
                </div>
              </div>
            </div>

            {/* Dietary Restrictions */}
            {dietaryRestrictions.length > 0 && (
              <div className="border-t pt-4">
                <h3 className="font-medium mb-2 text-sm">Dietary Preferences</h3>
                <div className="flex flex-wrap gap-1 justify-center">
                  {dietaryRestrictions.map((restriction) => (
                    <Badge key={restriction} variant="secondary" className="text-xs">
                      {restriction.charAt(0).toUpperCase() + restriction.slice(1)}
                    </Badge>
                  ))}
                </div>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Daily Meal Plans */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Meal Plan Details</CardTitle>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="day-1" className="w-full">
            <TabsList className={`grid w-full ${mealPlan.days.length <= 3 ? 'grid-cols-3' : mealPlan.days.length <= 5 ? 'grid-cols-5' : 'grid-cols-7'}`}>
              {mealPlan.days.map((_, index) => (
                <TabsTrigger key={index} value={`day-${index + 1}`} className="text-xs">
                  Day {index + 1}
                </TabsTrigger>
              ))}
            </TabsList>
            
            {mealPlan.days.map((day, dayIndex) => (
              <TabsContent key={dayIndex} value={`day-${dayIndex + 1}`} className="space-y-4">
                
                {/* Day Summary */}
                <div className="bg-muted/50 rounded-lg p-4">
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <div className="font-medium text-primary">{day.totalCalories}</div>
                      <div className="text-muted-foreground">Total Calories</div>
                    </div>
                    <div>
                      <div className="font-medium">{formatWeight(day.totalWeight)}</div>
                      <div className="text-muted-foreground">Food Weight</div>
                    </div>
                  </div>
                </div>

                {/* Meals for this day */}
                <div className="space-y-3">
                  {Object.entries(day.meals).map(([mealType, foods]: [string, FoodItem[]]) => {
                    if (foods.length === 0) return null;
                    
                    const MealIcon = getMealIcon(mealType);
                    const mealCalories = foods.reduce((sum, food) => sum + food.calories, 0);
                    const mealWeight = foods.reduce((sum, food) => sum + food.weight, 0);
                    
                    return (
                      <div key={mealType} className="border rounded-lg p-4">
                        <div className="flex items-center justify-between mb-3">
                          <div className="flex items-center space-x-2">
                            <MealIcon className="h-4 w-4 text-primary" />
                            <h4 className="font-medium capitalize">{mealType}</h4>
                          </div>
                          <div className="text-sm text-muted-foreground">
                            {mealCalories} cal • {formatWeight(mealWeight)}
                          </div>
                        </div>
                        
                        <div className="space-y-2">
                          {foods.map((food, foodIndex) => (
                            <div key={foodIndex} className="flex items-center justify-between text-sm bg-muted/30 rounded p-2">
                              <div>
                                <div className="font-medium">{food.name}</div>
                                <div className="text-xs text-muted-foreground">
                                  {food.description}
                                </div>
                              </div>
                              <div className="text-right">
                                <div className="font-medium">{food.calories} cal</div>
                                <div className="text-xs text-muted-foreground">
                                  {formatWeight(food.weight)}
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </TabsContent>
            ))}
          </Tabs>


        </CardContent>
      </Card>

      {/* Weight Warning */}
      {mealPlan.averageDailyWeight > 750 && (
        <Card className="bg-orange-50 border-orange-200">
          <CardContent className="p-4">
            <div className="flex items-center space-x-2 text-orange-700">
              <Scale className="h-4 w-4" />
              <div className="text-sm">
                <strong>Weight Notice:</strong> Average daily food weight is {formatWeight(mealPlan.averageDailyWeight)}. 
                Consider lighter options or resupply points for longer trips.
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}