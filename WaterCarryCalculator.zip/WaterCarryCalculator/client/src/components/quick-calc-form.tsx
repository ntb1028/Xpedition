import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Calculator } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useCalculations } from "@/hooks/use-calculations";
import { usePreferences } from "@/hooks/use-preferences";
import { HydrationCalculator } from "@/lib/hydration-calculator";
import { useToast } from "@/hooks/use-toast";

const quickCalcSchema = z.object({
  distance: z.string().optional(),
  duration: z.string().optional(),
  temperature: z.string().min(1, "Temperature is required"),
  temperatureUnit: z.enum(["F", "C"]),
}).refine(
  (data) => data.distance || data.duration,
  {
    message: "Either distance or duration is required",
    path: ["distance"],
  }
);

type QuickCalcForm = z.infer<typeof quickCalcSchema>;

interface QuickCalcFormProps {
  onResult: (result: any) => void;
  advancedOptions?: {
    pace?: number;
    elevationGain?: number;
    humidity?: string;
    packWeight?: number;
  };
}

export function QuickCalcForm({ onResult, advancedOptions = {} }: QuickCalcFormProps) {
  const [tempUnit, setTempUnit] = useState<"F" | "C">("F");
  const { calculate, isCalculating } = useCalculations();
  const { preferences } = usePreferences();
  const { toast } = useToast();

  const form = useForm<QuickCalcForm>({
    resolver: zodResolver(quickCalcSchema),
    defaultValues: {
      distance: "",
      duration: "",
      temperature: "",
      temperatureUnit: "F",
    },
  });

  const onSubmit = async (data: QuickCalcForm) => {
    try {
      const distance = data.distance ? parseFloat(data.distance) : undefined;
      const duration = data.duration ? parseFloat(data.duration) : undefined;
      const temperature = parseFloat(data.temperature);

      // Validate temperature range
      const tempC = tempUnit === 'C' ? temperature : (temperature - 32) * 5/9;
      if (tempC < -40 || tempC > 60) {
        toast({
          title: "Invalid Temperature",
          description: "Please enter a realistic temperature (-40°C to 60°C)",
          variant: "destructive",
        });
        return;
      }

      const result = await calculate({
        distance,
        duration,
        temperature,
        temperatureUnit: tempUnit,
        pace: advancedOptions.pace,
        elevationGain: advancedOptions.elevationGain,
        humidity: advancedOptions.humidity as 'low' | 'moderate' | 'high' | undefined,
        packWeight: advancedOptions.packWeight,
        isMetric: preferences.units === 'metric'
      });

      onResult(result);
      
      toast({
        title: "Calculation Complete",
        description: `Recommended water: ${result.liters}L (${result.ounces} fl oz)`,
      });

    } catch (error) {
      toast({
        title: "Calculation Error",
        description: error instanceof Error ? error.message : "Failed to calculate water needs",
        variant: "destructive",
      });
    }
  };

  // Auto-convert between distance and duration
  const handleDistanceChange = (value: string) => {
    if (value && !form.getValues("duration")) {
      const distance = parseFloat(value);
      const pace = preferences.units === 'metric' ? 4.8 : 3; // km/h or mph
      const duration = distance / pace;
      form.setValue("duration", duration.toFixed(1));
    }
  };

  const handleDurationChange = (value: string) => {
    if (value && !form.getValues("distance")) {
      const duration = parseFloat(value);
      const pace = preferences.units === 'metric' ? 4.8 : 3; // km/h or mph
      const distance = duration * pace;
      form.setValue("distance", distance.toFixed(1));
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg">Quick Calculation</CardTitle>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <div>
              <Label className="text-sm font-medium">Distance or Duration</Label>
              <div className="grid grid-cols-2 gap-3 mt-2">
                <FormField
                  control={form.control}
                  name="distance"
                  render={({ field }) => (
                    <FormItem>
                      <FormControl>
                        <div className="relative">
                          <Input
                            {...field}
                            type="number"
                            placeholder="8.5"
                            step="0.1"
                            onChange={(e) => {
                              field.onChange(e);
                              handleDistanceChange(e.target.value);
                            }}
                            className="text-lg font-medium pr-12"
                          />
                          <span className="absolute right-3 top-3 text-sm text-muted-foreground">
                            {preferences.units === 'metric' ? 'km' : 'mi'}
                          </span>
                        </div>
                      </FormControl>
                    </FormItem>
                  )}
                />
                <div className="flex items-center justify-center">
                  <span className="text-muted-foreground font-medium">OR</span>
                </div>
              </div>
              <div className="mt-3">
                <FormField
                  control={form.control}
                  name="duration"
                  render={({ field }) => (
                    <FormItem>
                      <FormControl>
                        <div className="relative">
                          <Input
                            {...field}
                            type="number"
                            placeholder="3.5"
                            step="0.1"
                            onChange={(e) => {
                              field.onChange(e);
                              handleDurationChange(e.target.value);
                            }}
                            className="text-lg font-medium pr-16"
                          />
                          <span className="absolute right-3 top-3 text-sm text-muted-foreground">
                            hours
                          </span>
                        </div>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
            </div>

            <FormField
              control={form.control}
              name="temperature"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Expected High Temperature</FormLabel>
                  <FormControl>
                    <div className="relative">
                      <Input
                        {...field}
                        type="number"
                        placeholder="85"
                        className="text-lg font-medium pr-20"
                      />
                      <div className="absolute right-2 top-2">
                        <div className="flex bg-muted rounded-md p-1">
                          <button
                            type="button"
                            onClick={() => {
                              setTempUnit("F");
                              form.setValue("temperatureUnit", "F");
                            }}
                            className={`px-2 py-1 text-xs font-medium rounded transition-colors ${
                              tempUnit === "F"
                                ? "bg-background shadow text-primary"
                                : "text-muted-foreground hover:text-foreground"
                            }`}
                          >
                            °F
                          </button>
                          <button
                            type="button"
                            onClick={() => {
                              setTempUnit("C");
                              form.setValue("temperatureUnit", "C");
                            }}
                            className={`px-2 py-1 text-xs font-medium rounded transition-colors ${
                              tempUnit === "C"
                                ? "bg-background shadow text-primary"
                                : "text-muted-foreground hover:text-foreground"
                            }`}
                          >
                            °C
                          </button>
                        </div>
                      </div>
                    </div>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <Button
              type="submit"
              className="w-full py-4 text-lg font-semibold"
              disabled={isCalculating}
            >
              <Calculator className="mr-2 h-5 w-5" />
              {isCalculating ? "Calculating..." : "Calculate Water Needed"}
            </Button>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}
