import { useState } from "react";
import { ChevronDown } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent } from "@/components/ui/card";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { usePreferences } from "@/hooks/use-preferences";

interface AdvancedOptionsProps {
  values: {
    pace?: number;
    elevationGain?: number;
    humidity?: string;
    packWeight?: number;
  };
  onChange: (values: any) => void;
}

export function AdvancedOptions({ values, onChange }: AdvancedOptionsProps) {
  const [isOpen, setIsOpen] = useState(false);
  const { preferences } = usePreferences();

  const handleChange = (field: string, value: any) => {
    onChange({ ...values, [field]: value });
  };

  return (
    <Card>
      <Collapsible open={isOpen} onOpenChange={setIsOpen}>
        <CollapsibleTrigger asChild>
          <Button
            variant="ghost"
            className="w-full px-6 py-4 flex items-center justify-between text-left hover:bg-muted/50 transition-colors rounded-xl h-auto"
          >
            <div>
              <h3 className="font-medium text-foreground">Advanced Options</h3>
              <p className="text-sm text-muted-foreground">Pace, elevation, humidity, pack weight</p>
            </div>
            <ChevronDown
              className={`h-4 w-4 text-muted-foreground transition-transform ${
                isOpen ? "rotate-180" : ""
              }`}
            />
          </Button>
        </CollapsibleTrigger>
        
        <CollapsibleContent>
          <CardContent className="px-6 pb-6 pt-4 border-t">
            <div className="space-y-4">
              
              {/* Pace */}
              <div>
                <Label className="text-sm font-medium">
                  Walking Pace (default: {preferences.units === 'metric' ? '4.8 km/h' : '3 mph'})
                </Label>
                <div className="relative mt-2">
                  <Input
                    type="number"
                    placeholder={preferences.units === 'metric' ? "4.8" : "3.0"}
                    step="0.1"
                    value={values.pace || ""}
                    onChange={(e) => handleChange("pace", e.target.value ? parseFloat(e.target.value) : undefined)}
                    className="pr-16"
                  />
                  <span className="absolute right-4 top-3 text-sm text-muted-foreground">
                    {preferences.units === 'metric' ? 'km/h' : 'mph'}
                  </span>
                </div>
              </div>

              {/* Elevation Gain */}
              <div>
                <Label className="text-sm font-medium">Elevation Gain</Label>
                <div className="relative mt-2">
                  <Input
                    type="number"
                    placeholder={preferences.units === 'metric' ? "500" : "1500"}
                    step={preferences.units === 'metric' ? "10" : "50"}
                    value={values.elevationGain || ""}
                    onChange={(e) => handleChange("elevationGain", e.target.value ? parseFloat(e.target.value) : undefined)}
                    className="pr-12"
                  />
                  <span className="absolute right-4 top-3 text-sm text-muted-foreground">
                    {preferences.units === 'metric' ? 'm' : 'ft'}
                  </span>
                </div>
              </div>

              {/* Humidity */}
              <div>
                <Label className="text-sm font-medium">Humidity Level</Label>
                <Select
                  value={values.humidity || ""}
                  onValueChange={(value) => handleChange("humidity", value)}
                >
                  <SelectTrigger className="mt-2">
                    <SelectValue placeholder="Select humidity level" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="low">Low (&lt; 40%)</SelectItem>
                    <SelectItem value="moderate">Moderate (40-60%)</SelectItem>
                    <SelectItem value="high">High (&gt; 60%)</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Pack Weight */}
              <div>
                <Label className="text-sm font-medium">Pack Weight</Label>
                <div className="relative mt-2">
                  <Input
                    type="number"
                    placeholder={preferences.units === 'metric' ? "11" : "25"}
                    step={preferences.units === 'metric' ? "0.5" : "1"}
                    value={values.packWeight || ""}
                    onChange={(e) => handleChange("packWeight", e.target.value ? parseFloat(e.target.value) : undefined)}
                    className="pr-12"
                  />
                  <span className="absolute right-4 top-3 text-sm text-muted-foreground">
                    {preferences.units === 'metric' ? 'kg' : 'lbs'}
                  </span>
                </div>
              </div>
            </div>
          </CardContent>
        </CollapsibleContent>
      </Collapsible>
    </Card>
  );
}
