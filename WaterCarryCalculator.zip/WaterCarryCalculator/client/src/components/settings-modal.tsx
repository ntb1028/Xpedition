import { X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { usePreferences } from "@/hooks/use-preferences";

interface SettingsModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function SettingsModal({ open, onOpenChange }: SettingsModalProps) {
  const { preferences, updatePreferences, resetPreferences } = usePreferences();

  const handleToggle = (key: keyof typeof preferences, value: boolean) => {
    updatePreferences({ [key]: value });
  };

  const handleUnitsChange = (units: 'metric' | 'imperial') => {
    updatePreferences({ units });
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="text-xl">Settings</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-6">
          {/* Units */}
          <div>
            <h3 className="font-medium mb-3">Default Units</h3>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm">Distance & Weight</span>
                <div className="flex bg-muted rounded-lg p-1">
                  <button
                    onClick={() => handleUnitsChange('imperial')}
                    className={`px-3 py-1 text-xs font-medium rounded transition-colors ${
                      preferences.units === 'imperial'
                        ? "bg-background shadow text-primary"
                        : "text-muted-foreground hover:text-foreground"
                    }`}
                  >
                    Imperial
                  </button>
                  <button
                    onClick={() => handleUnitsChange('metric')}
                    className={`px-3 py-1 text-xs font-medium rounded transition-colors ${
                      preferences.units === 'metric'
                        ? "bg-background shadow text-primary"
                        : "text-muted-foreground hover:text-foreground"
                    }`}
                  >
                    Metric
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Accessibility */}
          <div>
            <h3 className="font-medium mb-3">Accessibility</h3>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label className="text-sm font-medium">Dyslexia-Friendly Font</Label>
                  <div className="text-xs text-muted-foreground">Use OpenDyslexic font</div>
                </div>
                <Switch
                  checked={preferences.dyslexiaFont}
                  onCheckedChange={(checked) => handleToggle('dyslexiaFont', checked)}
                />
              </div>
              
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label className="text-sm font-medium">Large Text</Label>
                  <div className="text-xs text-muted-foreground">Increase font sizes</div>
                </div>
                <Switch
                  checked={preferences.largeText}
                  onCheckedChange={(checked) => handleToggle('largeText', checked)}
                />
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label className="text-sm font-medium">High Contrast</Label>
                  <div className="text-xs text-muted-foreground">Improve color contrast</div>
                </div>
                <Switch
                  checked={preferences.highContrast}
                  onCheckedChange={(checked) => handleToggle('highContrast', checked)}
                />
              </div>
            </div>
          </div>

          {/* Safety */}
          <div>
            <h3 className="font-medium mb-3">Safety Settings</h3>
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label className="text-sm font-medium">Conservative Recommendations</Label>
                <div className="text-xs text-muted-foreground">Add 10% safety buffer</div>
              </div>
              <Switch
                checked={preferences.conservative}
                onCheckedChange={(checked) => handleToggle('conservative', checked)}
              />
            </div>
          </div>

          {/* Reset */}
          <div className="pt-4 border-t">
            <Button
              variant="outline"
              onClick={resetPreferences}
              className="w-full"
            >
              Reset to Defaults
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
