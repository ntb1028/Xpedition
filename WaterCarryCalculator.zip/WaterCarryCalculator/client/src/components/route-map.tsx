import { useEffect, useState } from 'react';
import { MapContainer, TileLayer, Marker, Polyline, Popup, useMapEvents } from 'react-leaflet';
import { Icon, LatLng } from 'leaflet';
import { MapPin, Navigation, Mountain, Droplets, Maximize2, Minimize2, Edit3, Trash2, Check, X } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';

// Fix for default markers in react-leaflet
delete (Icon.Default.prototype as any)._getIconUrl;
Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-shadow.png',
});

interface RoutePoint {
  lat: number;
  lng: number;
  name: string;
  type: 'start' | 'end' | 'waypoint' | 'water' | 'camp' | 'trailhead' | 'viewpoint';
  elevation?: number;
  draggable?: boolean;
  isEditing?: boolean;
}

interface RouteMapProps {
  onRouteChange?: (distance: number, elevationGain: number) => void;
}

// Component to handle map click events
function MapClickHandler({ onMapClick }: { onMapClick: (lat: number, lng: number) => void }) {
  useMapEvents({
    click: (e) => {
      onMapClick(e.latlng.lat, e.latlng.lng);
    },
  });
  return null;
}

export function RouteMap({ onRouteChange }: RouteMapProps) {
  const [center, setCenter] = useState<[number, number]>([36.1069, -112.1129]); // Grand Canyon South Rim
  const [zoom, setZoom] = useState(11);
  const [routePoints, setRoutePoints] = useState<RoutePoint[]>([]);
  const [searchLocation, setSearchLocation] = useState('');
  const [isSearching, setIsSearching] = useState(false);
  const [isExpanded, setIsExpanded] = useState(false);
  const [editingPointIndex, setEditingPointIndex] = useState<number | null>(null);
  const [grandCanyonFeatures, setGrandCanyonFeatures] = useState<RoutePoint[]>([]);
  const { toast } = useToast();

  // Load Grand Canyon features on component mount
  useEffect(() => {
    const loadGrandCanyonFeatures = () => {
      const features: RoutePoint[] = [
        // Major Trailheads
        { lat: 36.0544, lng: -112.1401, name: 'Bright Angel Trailhead', type: 'trailhead', elevation: 2134 },
        { lat: 36.0581, lng: -112.1408, name: 'South Kaibab Trailhead', type: 'trailhead', elevation: 2207 },
        { lat: 36.2097, lng: -112.0581, name: 'North Kaibab Trailhead', type: 'trailhead', elevation: 2515 },
        { lat: 36.0963, lng: -112.1394, name: 'Hermit Trailhead', type: 'trailhead', elevation: 1981 },
        
        // Water Sources
        { lat: 36.1058, lng: -112.1411, name: 'Indian Garden', type: 'water', elevation: 1158 },
        { lat: 36.1058, lng: -112.0947, name: 'Bright Angel Creek', type: 'water', elevation: 762 },
        { lat: 36.0544, lng: -112.0947, name: 'Colorado River', type: 'water', elevation: 720 },
        { lat: 36.1269, lng: -112.1275, name: 'Hermit Creek', type: 'water', elevation: 853 },
        
        // Campgrounds
        { lat: 36.1058, lng: -112.0947, name: 'Bright Angel Campground', type: 'camp', elevation: 762 },
        { lat: 36.1269, lng: -112.1275, name: 'Hermit Camp', type: 'camp', elevation: 853 },
        { lat: 36.2097, lng: -112.0581, name: 'North Rim Campground', type: 'camp', elevation: 2515 },
        
        // Major Viewpoints
        { lat: 36.0544, lng: -112.1401, name: 'Grand Canyon Village', type: 'viewpoint', elevation: 2134 },
        { lat: 36.0581, lng: -112.1408, name: 'Yaki Point', type: 'viewpoint', elevation: 2262 },
        { lat: 36.0963, lng: -112.1694, name: 'Hermits Rest', type: 'viewpoint', elevation: 2012 },
        { lat: 36.0469, lng: -112.1269, name: 'Desert View', type: 'viewpoint', elevation: 2268 },
      ];
      setGrandCanyonFeatures(features);
    };
    
    loadGrandCanyonFeatures();
  }, []);

  // Calculate route statistics when points change
  useEffect(() => {
    if (routePoints.length >= 2) {
      const distance = calculateTotalDistance(routePoints);
      const elevationGain = calculateElevationGain(routePoints);
      onRouteChange?.(distance, elevationGain);
    }
  }, [routePoints, onRouteChange]);

  const calculateTotalDistance = (points: RoutePoint[]): number => {
    let totalDistance = 0;
    for (let i = 1; i < points.length; i++) {
      const prev = points[i - 1];
      const curr = points[i];
      totalDistance += haversineDistance(prev.lat, prev.lng, curr.lat, curr.lng);
    }
    return totalDistance;
  };

  const calculateElevationGain = (points: RoutePoint[]): number => {
    let totalGain = 0;
    for (let i = 1; i < points.length; i++) {
      const prev = points[i - 1];
      const curr = points[i];
      if (prev.elevation && curr.elevation && curr.elevation > prev.elevation) {
        totalGain += curr.elevation - prev.elevation;
      }
    }
    return totalGain;
  };

  const haversineDistance = (lat1: number, lon1: number, lat2: number, lon2: number): number => {
    const R = 6371; // Earth's radius in kilometers
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLon = (lon2 - lon1) * Math.PI / 180;
    const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
      Math.sin(dLon / 2) * Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c;
  };

  const searchForLocation = async () => {
    if (!searchLocation.trim()) return;

    setIsSearching(true);
    try {
      // Use Nominatim API for geocoding
      const response = await fetch(
        `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(searchLocation)}&limit=1`
      );
      
      if (!response.ok) {
        throw new Error('Search failed');
      }
      
      const data = await response.json();
      
      if (data.length > 0) {
        const result = data[0];
        const lat = parseFloat(result.lat);
        const lng = parseFloat(result.lon);
        
        setCenter([lat, lng]);
        setZoom(13);
        
        toast({
          title: "Location Found",
          description: `Centered map on ${result.display_name}`,
        });
      } else {
        toast({
          title: "Location Not Found",
          description: "Try a more specific location name",
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "Search Error",
        description: "Unable to search for location. Please check your connection.",
        variant: "destructive",
      });
    } finally {
      setIsSearching(false);
    }
  };

  const addRoutePoint = (lat: number, lng: number, type: RoutePoint['type'] = 'waypoint') => {
    const name = `${type.charAt(0).toUpperCase() + type.slice(1)} ${routePoints.length + 1}`;
    const newPoint: RoutePoint = {
      lat,
      lng,
      name,
      type,
      elevation: Math.random() * 1000 + 100,
      draggable: true
    };
    
    setRoutePoints(prev => [...prev, newPoint]);
  };

  const updatePointPosition = (index: number, lat: number, lng: number) => {
    setRoutePoints(prev => prev.map((point, i) => 
      i === index ? { ...point, lat, lng } : point
    ));
  };

  const updatePointName = (index: number, name: string) => {
    setRoutePoints(prev => prev.map((point, i) => 
      i === index ? { ...point, name, isEditing: false } : point
    ));
    setEditingPointIndex(null);
  };

  const startEditing = (index: number) => {
    setEditingPointIndex(index);
    setRoutePoints(prev => prev.map((point, i) => 
      i === index ? { ...point, isEditing: true } : point
    ));
  };

  const deletePoint = (index: number) => {
    setRoutePoints(prev => prev.filter((_, i) => i !== index));
  };

  const clearRoute = () => {
    setRoutePoints([]);
    onRouteChange?.(0, 0);
  };

  const getMarkerIcon = (type: RoutePoint['type']) => {
    const iconColor = {
      start: '#22c55e',
      end: '#ef4444',
      waypoint: '#3b82f6',
      water: '#06b6d4',
      camp: '#f59e0b',
      trailhead: '#8b5cf6',
      viewpoint: '#f97316'
    }[type];

    return new Icon({
      iconUrl: `data:image/svg+xml;base64,${btoa(`
        <svg width="25" height="41" viewBox="0 0 25 41" xmlns="http://www.w3.org/2000/svg">
          <path d="M12.5 0C5.6 0 0 5.6 0 12.5C0 19.4 12.5 41 12.5 41S25 19.4 25 12.5C25 5.6 19.4 0 12.5 0Z" fill="${iconColor}"/>
          <circle cx="12.5" cy="12.5" r="8" fill="white"/>
        </svg>
      `)}`,
      iconSize: [25, 41],
      iconAnchor: [12, 41],
      popupAnchor: [1, -34],
    });
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg flex items-center space-x-2">
          <Navigation className="h-5 w-5" />
          <span>Route Planner</span>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        
        {/* Location Search */}
        <div className="space-y-2">
          <Label>Search Location</Label>
          <div className="flex space-x-2">
            <Input
              value={searchLocation}
              onChange={(e) => setSearchLocation(e.target.value)}
              placeholder="Enter trail name or location..."
              onKeyPress={(e) => e.key === 'Enter' && searchForLocation()}
            />
            <Button onClick={searchForLocation} disabled={isSearching}>
              {isSearching ? 'Searching...' : 'Search'}
            </Button>
          </div>
        </div>

        {/* Map */}
        <div className="relative">
          {isExpanded && <div className="fixed inset-0 bg-black/50 z-40" onClick={() => setIsExpanded(false)} />}
          <div className={`${isExpanded ? 'fixed inset-4 z-50 bg-background shadow-2xl flex flex-col' : 'relative h-64'} rounded-lg overflow-hidden border`}>
            <div className="flex items-center justify-between p-2 bg-background border-b flex-shrink-0">
              <h3 className="font-medium text-sm">Grand Canyon Trail Map</h3>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setIsExpanded(!isExpanded)}
              >
                {isExpanded ? <Minimize2 className="h-4 w-4" /> : <Maximize2 className="h-4 w-4" />}
              </Button>
            </div>
            <div className={`${isExpanded ? 'flex-1' : 'h-full'}`}>
              <MapContainer
                center={center}
                zoom={zoom}
                style={{ 
                  height: isExpanded ? '100%' : '240px', 
                  width: '100%',
                  minHeight: isExpanded ? 'calc(100vh - 160px)' : '240px'
                }}
                key={isExpanded ? 'expanded' : 'compact'}
              >
              <MapClickHandler 
                onMapClick={(lat, lng) => {
                  const pointType = routePoints.length === 0 ? 'start' : 'waypoint';
                  addRoutePoint(lat, lng, pointType);
                }}
              />
              <TileLayer
                attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
                url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
              />
              
              {/* Grand Canyon features */}
              {grandCanyonFeatures.map((feature, index) => (
                <Marker
                  key={`feature-${index}`}
                  position={[feature.lat, feature.lng]}
                  icon={getMarkerIcon(feature.type)}
                >
                  <Popup>
                    <div className="text-sm">
                      <strong>{feature.name}</strong>
                      <br />
                      Type: {feature.type}
                      <br />
                      Elevation: {feature.elevation?.toFixed(0)}m
                    </div>
                  </Popup>
                </Marker>
              ))}
              
              {/* User route markers */}
              {routePoints.map((point, index) => (
                <Marker
                  key={`route-${index}`}
                  position={[point.lat, point.lng]}
                  icon={getMarkerIcon(point.type)}
                  draggable={point.draggable}
                  eventHandlers={{
                    dragend: (e) => {
                      const marker = e.target;
                      const position = marker.getLatLng();
                      updatePointPosition(index, position.lat, position.lng);
                    },
                  }}
                >
                  <Popup>
                    <div className="text-sm space-y-2">
                      {point.isEditing ? (
                        <div className="flex items-center space-x-1">
                          <Input
                            defaultValue={point.name}
                            className="h-6 text-xs"
                            onKeyPress={(e) => {
                              if (e.key === 'Enter') {
                                updatePointName(index, e.currentTarget.value);
                              }
                            }}
                            autoFocus
                          />
                          <Button
                            size="sm"
                            variant="ghost"
                            className="h-6 w-6 p-0"
                            onClick={() => {
                              const input = document.querySelector('input[defaultValue="' + point.name + '"]') as HTMLInputElement;
                              if (input) updatePointName(index, input.value);
                            }}
                          >
                            <Check className="h-3 w-3" />
                          </Button>
                        </div>
                      ) : (
                        <div className="flex items-center justify-between">
                          <strong>{point.name}</strong>
                          <Button
                            size="sm"
                            variant="ghost"
                            className="h-5 w-5 p-0"
                            onClick={() => startEditing(index)}
                          >
                            <Edit3 className="h-3 w-3" />
                          </Button>
                        </div>
                      )}
                      <div>Type: {point.type}</div>
                      <div>Elevation: {point.elevation?.toFixed(0)}m</div>
                      <div className="flex items-center space-x-1">
                        <Button
                          size="sm"
                          variant="destructive"
                          className="h-6 text-xs"
                          onClick={() => deletePoint(index)}
                        >
                          <Trash2 className="h-3 w-3 mr-1" />
                          Delete
                        </Button>
                      </div>
                    </div>
                  </Popup>
                </Marker>
              ))}
              
              {/* Route line */}
              {routePoints.length > 1 && (
                <Polyline
                  positions={routePoints.map(p => [p.lat, p.lng] as [number, number])}
                  color="#3b82f6"
                  weight={4}
                  opacity={0.7}
                />
              )}
            </MapContainer>
            </div>
          </div>
        </div>

        {/* Route Controls */}
        <div className="flex space-x-2">
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => {
              if (routePoints.length > 0) {
                const lastPoint = routePoints[routePoints.length - 1];
                addRoutePoint(lastPoint.lat + 0.01, lastPoint.lng + 0.01, 'water');
              }
            }}
          >
            <Droplets className="h-4 w-4 mr-1" />
            Add Water
          </Button>
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => {
              if (routePoints.length > 0) {
                const lastPoint = routePoints[routePoints.length - 1];
                addRoutePoint(lastPoint.lat + 0.01, lastPoint.lng + 0.01, 'camp');
              }
            }}
          >
            <Mountain className="h-4 w-4 mr-1" />
            Add Camp
          </Button>
          <Button 
            variant="outline" 
            size="sm"
            onClick={clearRoute}
            disabled={routePoints.length === 0}
          >
            Clear Route
          </Button>
        </div>

        {/* Route Stats */}
        {routePoints.length >= 2 && (
          <div className="bg-muted/50 rounded-lg p-3">
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <div className="font-medium text-primary">
                  {calculateTotalDistance(routePoints).toFixed(1)} km
                </div>
                <div className="text-muted-foreground">Total Distance</div>
              </div>
              <div>
                <div className="font-medium">
                  {calculateElevationGain(routePoints).toFixed(0)} m
                </div>
                <div className="text-muted-foreground">Elevation Gain</div>
              </div>
            </div>
          </div>
        )}

        <div className="text-xs text-muted-foreground">
          Click on the map to add waypoints. Start with your trailhead location.
        </div>
      </CardContent>
    </Card>
  );
}