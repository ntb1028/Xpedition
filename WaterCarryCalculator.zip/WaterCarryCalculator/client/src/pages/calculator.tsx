import { useState } from "react";
import { Settings, Plus, Droplets, ChefHat, Map } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { SafetyDisclaimer } from "@/components/safety-disclaimer";
import { QuickCalcForm } from "@/components/quick-calc-form";
import { AdvancedOptions } from "@/components/advanced-options";
import { ResultsDisplay } from "@/components/results-display";
import { TripHistory } from "@/components/trip-history";
import { SettingsModal } from "@/components/settings-modal";
import { useCalculations } from "@/hooks/use-calculations";
import type { CalculationResult } from "@/lib/hydration-calculator";

export default function Calculator() {
  const [showSettings, setShowSettings] = useState(false);
  const [advancedOptions, setAdvancedOptions] = useState({});
  const { currentResult, setCurrentResult } = useCalculations();

  const handleResult = (result: CalculationResult) => {
    setCurrentResult(result);
    // Scroll to results
    setTimeout(() => {
      const resultsElement = document.getElementById('results-section');
      if (resultsElement) {
        resultsElement.scrollIntoView({ behavior: 'smooth' });
      }
    }, 100);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-emerald-50">
      {/* Header */}
      <header className="bg-background shadow-sm border-b">
        <div className="max-w-6xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Link href="/">
                <Button variant="ghost" size="sm" className="text-muted-foreground hover:text-foreground">
                  <Map className="h-4 w-4" />
                </Button>
              </Link>
              <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
                <Droplets className="text-primary-foreground h-5 w-5" />
              </div>
              <div>
                <h1 className="text-lg font-bold">Water Calculator</h1>
                <p className="text-xs text-muted-foreground">Evidence-based hydration planning</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Link href="/meal-planner">
                <Button variant="outline" size="sm">
                  <ChefHat className="h-4 w-4 mr-1" />
                  Meal Planner
                </Button>
              </Link>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setShowSettings(true)}
                className="text-muted-foreground hover:text-foreground"
              >
                <Settings className="h-5 w-5" />
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-6xl mx-auto px-4 py-6 space-y-6">
        
        {/* Safety Disclaimer */}
        <SafetyDisclaimer />

        {/* Quick Calculation Form */}
        <QuickCalcForm onResult={handleResult} advancedOptions={advancedOptions} />

        {/* Advanced Options */}
        <AdvancedOptions
          values={advancedOptions}
          onChange={setAdvancedOptions}
        />

        {/* Results Display */}
        <div id="results-section">
          <ResultsDisplay result={currentResult} />
        </div>

        {/* Trip History */}
        <TripHistory />

        {/* Additional Tools */}
        <div className="space-y-4">
          {/* Route Planner CTA */}
          <div className="bg-gradient-to-r from-blue-50 to-green-50 rounded-xl p-6 border border-blue-200">
            <div className="text-center">
              <Map className="h-8 w-8 text-blue-600 mx-auto mb-3" />
              <h3 className="font-semibold mb-2">Plan Your Route</h3>
              <p className="text-sm text-muted-foreground mb-4">
                Explore Grand Canyon trails, mark water sources, and plan your hiking route with interactive maps.
              </p>
              <Link href="/route-planner">
                <Button className="w-full bg-blue-600 hover:bg-blue-700 text-white">
                  Open Route Planner
                </Button>
              </Link>
            </div>
          </div>

          {/* Meal Planning CTA */}
          <div className="bg-gradient-to-r from-secondary/20 to-primary/20 rounded-xl p-6 border border-secondary/30">
            <div className="text-center">
              <ChefHat className="h-8 w-8 text-secondary mx-auto mb-3" />
              <h3 className="font-semibold mb-2">Plan Your Meals Too</h3>
              <p className="text-sm text-muted-foreground mb-4">
                Calculate daily calories and get meal suggestions for your outdoor adventures.
              </p>
              <Link href="/meal-planner">
                <Button className="w-full bg-secondary hover:bg-secondary/90 text-secondary-foreground">
                  Open Meal Planner
                </Button>
              </Link>
            </div>
          </div>
        </div>

      </main>

      {/* Settings Modal */}
      <SettingsModal
        open={showSettings}
        onOpenChange={setShowSettings}
      />

      {/* Floating Action Button */}
      <div className="fixed bottom-6 right-6">
        <Button
          size="icon"
          className="w-14 h-14 rounded-full shadow-lg hover:shadow-xl transition-shadow bg-secondary hover:bg-secondary/90"
          onClick={() => {
            // Quick scroll to top for easy access
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
        >
          <Plus className="h-6 w-6" />
        </Button>
      </div>
    </div>
  );
}
