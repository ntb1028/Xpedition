import { useState } from "react";
import { ChefHat, ArrowLeft } from "lucide-react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { SafetyDisclaimer } from "@/components/safety-disclaimer";
import { MealCalcForm } from "@/components/meal-calc-form";
import { MealPlanDisplay } from "@/components/meal-plan-display";

export default function MealPlanner() {
  const [currentResult, setCurrentResult] = useState<any>(null);

  const handleResult = (result: any) => {
    setCurrentResult(result);
    // Scroll to results
    setTimeout(() => {
      const resultsElement = document.getElementById('meal-results-section');
      if (resultsElement) {
        resultsElement.scrollIntoView({ behavior: 'smooth' });
      }
    }, 100);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-orange-50">
      {/* Header */}
      <header className="bg-background shadow-sm border-b">
        <div className="max-w-6xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Link href="/">
                <Button variant="ghost" size="sm" className="text-muted-foreground hover:text-foreground">
                  <ArrowLeft className="h-4 w-4" />
                </Button>
              </Link>
              <div className="w-10 h-10 bg-secondary rounded-lg flex items-center justify-center">
                <ChefHat className="text-secondary-foreground h-5 w-5" />
              </div>
              <div>
                <h1 className="text-lg font-bold">Meal Planner</h1>
                <p className="text-xs text-muted-foreground">Evidence-based nutrition planning</p>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-6xl mx-auto px-4 py-6 space-y-6">
        
        {/* Safety Disclaimer */}
        <SafetyDisclaimer />

        {/* Meal Calculation Form */}
        <MealCalcForm onResult={handleResult} />

        {/* Results Display */}
        <div id="meal-results-section">
          <MealPlanDisplay result={currentResult} />
        </div>

      </main>
    </div>
  );
}