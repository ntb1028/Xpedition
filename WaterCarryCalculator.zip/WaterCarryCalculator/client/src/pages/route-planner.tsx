import { useState } from "react";
import { Map, ArrowLeft, Calculator, ChefHat } from "lucide-react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { RouteMapFixed as RouteMap } from "@/components/route-map-working";
import { usePreferences } from "@/hooks/use-preferences";

export default function RoutePlanner() {
  const [routeDistance, setRouteDistance] = useState(0);
  const [routeElevation, setRouteElevation] = useState(0);
  const { preferences } = usePreferences();

  const handleRouteChange = (distance: number, elevationGain: number) => {
    setRouteDistance(distance);
    setRouteElevation(elevationGain);
  };

  const formatDistance = (km: number) => {
    if (preferences.units === 'metric') {
      return `${km.toFixed(1)} km`;
    } else {
      return `${(km * 0.621371).toFixed(1)} mi`;
    }
  };

  const formatElevation = (meters: number) => {
    if (preferences.units === 'metric') {
      return `${meters.toFixed(0)} m`;
    } else {
      return `${(meters * 3.28084).toFixed(0)} ft`;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-green-50">
      {/* Header */}
      <header className="bg-background shadow-sm border-b">
        <div className="max-w-6xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-blue-500 rounded-lg flex items-center justify-center">
                <Map className="text-white h-5 w-5" />
              </div>
              <div>
                <h1 className="text-lg font-bold">Grand Canyon Trip Planner</h1>
                <p className="text-xs text-muted-foreground">Plan your route, then calculate water and food needs</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Link href="/calculator">
                <Button variant="outline" size="sm">
                  <Calculator className="h-4 w-4 mr-1" />
                  Water Calculator
                </Button>
              </Link>
              <Link href="/meal-planner">
                <Button variant="outline" size="sm">
                  <ChefHat className="h-4 w-4 mr-1" />
                  Meal Planner
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-6xl mx-auto px-4 py-6 space-y-6">
        
        {/* Route Map */}
        <RouteMap onRouteChange={handleRouteChange} />

        {/* Route Summary */}
        {(routeDistance > 0 || routeElevation > 0) && (
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Route Summary</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-4">
                <div className="text-center">
                  <div className="text-2xl font-bold text-primary">
                    {formatDistance(routeDistance)}
                  </div>
                  <div className="text-sm text-muted-foreground">Total Distance</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-orange-600">
                    {formatElevation(routeElevation)}
                  </div>
                  <div className="text-sm text-muted-foreground">Elevation Gain</div>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Trip Planning Workflow Guide */}
        {!routeDistance && (
          <Card className="bg-blue-50 border-blue-200">
            <CardContent className="p-4">
              <h4 className="font-medium mb-2">Trip Planning Workflow</h4>
              <ol className="text-sm text-muted-foreground space-y-2">
                <li className="flex items-start gap-2">
                  <span className="bg-blue-500 text-white rounded-full w-5 h-5 flex items-center justify-center text-xs font-bold mt-0.5">1</span>
                  <span>Select trails from the dropdown to build "My Hike" with authentic Grand Canyon routes</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="bg-blue-500 text-white rounded-full w-5 h-5 flex items-center justify-center text-xs font-bold mt-0.5">2</span>
                  <span>Choose trip dates and duration, then click "Plan My Trip" for detailed planning</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="bg-blue-500 text-white rounded-full w-5 h-5 flex items-center justify-center text-xs font-bold mt-0.5">3</span>
                  <span>Get personalized water and food calculations based on weather and your settings</span>
                </li>
              </ol>
            </CardContent>
          </Card>
        )}

        {/* Next Steps - After Route Planning */}
        {routeDistance > 0 && (
          <Card className="bg-green-50 border-green-200">
            <CardContent className="p-4">
              <h4 className="font-medium mb-3 text-green-900">Your Route is Ready!</h4>
              <p className="text-sm text-green-700 mb-4">
                You've planned a {formatDistance(routeDistance)} route with {formatElevation(routeElevation)} elevation gain. 
                Now you can get detailed calculations for your specific trip.
              </p>
              
              <div className="space-y-3">
                {/* Water Calculator Link */}
                <Link href={`/calculator?distance=${routeDistance}&elevation=${routeElevation}`}>
                  <Card className="cursor-pointer hover:bg-green-100 transition-colors border-green-300">
                    <CardContent className="p-4">
                      <div className="flex items-center space-x-3">
                        <div className="w-10 h-10 bg-blue-500 rounded-lg flex items-center justify-center">
                          <Calculator className="text-white h-5 w-5" />
                        </div>
                        <div className="flex-1">
                          <h4 className="font-medium text-green-900">Calculate Water Needs</h4>
                          <p className="text-sm text-green-700">
                            Get precise hydration requirements for your {formatDistance(routeDistance)} route
                          </p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </Link>

                {/* Meal Planner Link */}
                <Link href={`/meal-planner?distance=${routeDistance}&elevation=${routeElevation}`}>
                  <Card className="cursor-pointer hover:bg-green-100 transition-colors border-green-300">
                    <CardContent className="p-4">
                      <div className="flex items-center space-x-3">
                        <div className="w-10 h-10 bg-orange-500 rounded-lg flex items-center justify-center">
                          <ChefHat className="text-white h-5 w-5" />
                        </div>
                        <div className="flex-1">
                          <h4 className="font-medium text-green-900">Plan Your Meals</h4>
                          <p className="text-sm text-green-700">
                            Calculate calorie needs and meal planning for your trip
                          </p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </Link>
              </div>
            </CardContent>
          </Card>
        )}

      </main>
    </div>
  );
}