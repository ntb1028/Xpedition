import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import Calculator from "@/pages/calculator";
import MealPlanner from "@/pages/meal-planner";
import RoutePlanner from "@/pages/route-planner";
import NotFound from "@/pages/not-found";
import { usePreferences } from "@/hooks/use-preferences";
import { useEffect } from "react";

function Router() {
  return (
    <Switch>
      <Route path="/" component={RoutePlanner} />
      <Route path="/calculator" component={Calculator} />
      <Route path="/meal-planner" component={MealPlanner} />
      <Route component={NotFound} />
    </Switch>
  );
}

function AppContent() {
  const { preferences } = usePreferences();

  useEffect(() => {
    const root = document.documentElement;
    
    // Apply accessibility preferences
    if (preferences.dyslexiaFont) {
      root.classList.add('dyslexia-font');
    } else {
      root.classList.remove('dyslexia-font');
    }

    if (preferences.largeText) {
      root.classList.add('large-text');
    } else {
      root.classList.remove('large-text');
    }

    if (preferences.highContrast) {
      root.classList.add('high-contrast');
    } else {
      root.classList.remove('high-contrast');
    }
  }, [preferences]);

  return <Router />;
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <AppContent />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
