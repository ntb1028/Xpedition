import { pgTable, text, serial, integer, boolean, real, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const calculations = pgTable("calculations", {
  id: serial("id").primaryKey(),
  name: text("name"),
  distance: real("distance"),
  duration: real("duration"),
  temperature: real("temperature").notNull(),
  temperatureUnit: text("temperature_unit").notNull().default("F"),
  pace: real("pace"),
  elevationGain: real("elevation_gain"),
  humidity: text("humidity"),
  packWeight: real("pack_weight"),
  resultLiters: real("result_liters").notNull(),
  resultOunces: real("result_ounces").notNull(),
  isMetric: boolean("is_metric").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const userPreferences = pgTable("user_preferences", {
  id: serial("id").primaryKey(),
  units: text("units").notNull().default("imperial"), // "metric" or "imperial"
  dyslexiaFont: boolean("dyslexia_font").default(false),
  largeText: boolean("large_text").default(false),
  highContrast: boolean("high_contrast").default(false),
  conservative: boolean("conservative").default(true),
});

export const mealPlans = pgTable("meal_plans", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  dailyDistance: real("daily_distance").notNull(),
  elevationGain: real("elevation_gain"),
  bodyWeight: real("body_weight").notNull(),
  packWeight: real("pack_weight"),
  dietaryRestrictions: text("dietary_restrictions").array(),
  targetCalories: real("target_calories").notNull(),
  totalDays: integer("total_days").notNull().default(1),
  totalFoodWeight: real("total_food_weight"),
  isMetric: boolean("is_metric").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const mealPlanItems = pgTable("meal_plan_items", {
  id: serial("id").primaryKey(),
  mealPlanId: integer("meal_plan_id").references(() => mealPlans.id),
  day: integer("day").notNull(),
  mealType: text("meal_type").notNull(), // "breakfast", "lunch", "dinner", "snack"
  foodItemId: text("food_item_id").notNull(),
  quantity: real("quantity").notNull(),
  calories: real("calories").notNull(),
  weight: real("weight").notNull(),
});

export const insertCalculationSchema = createInsertSchema(calculations).omit({
  id: true,
  createdAt: true,
});

export const insertUserPreferencesSchema = createInsertSchema(userPreferences).omit({
  id: true,
});

export const insertMealPlanSchema = createInsertSchema(mealPlans).omit({
  id: true,
  createdAt: true,
});

export const insertMealPlanItemSchema = createInsertSchema(mealPlanItems).omit({
  id: true,
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertCalculation = z.infer<typeof insertCalculationSchema>;
export type Calculation = typeof calculations.$inferSelect;
export type InsertUserPreferences = z.infer<typeof insertUserPreferencesSchema>;
export type UserPreferences = typeof userPreferences.$inferSelect;
export type InsertMealPlan = z.infer<typeof insertMealPlanSchema>;
export type MealPlan = typeof mealPlans.$inferSelect;
export type InsertMealPlanItem = z.infer<typeof insertMealPlanItemSchema>;
export type MealPlanItem = typeof mealPlanItems.$inferSelect;
